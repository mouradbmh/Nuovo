# AI4-WP-App

## How to Build Your Project

- [ ] Run ```yarn build``` to build the project. You'll find the build in the ```dist``` folder.

## How to Start the Development Server

- [ ] Run ```yarn dev``` and open ```localhost:3000``` in your browser.

## Configuration File

In the ```public``` folder, you can find a ```config.json``` file. This file contains all the static configurations for the app.

## AR Contents

For the AR contents, we have created the custom hook ```useStartAR```. You can populate the body of the function ```startAr``` with all the code needed to start the AR experience.
