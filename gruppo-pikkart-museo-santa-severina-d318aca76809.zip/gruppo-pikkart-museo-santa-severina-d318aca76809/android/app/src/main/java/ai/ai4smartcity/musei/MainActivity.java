package ai.ai4smartcity.musei;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
