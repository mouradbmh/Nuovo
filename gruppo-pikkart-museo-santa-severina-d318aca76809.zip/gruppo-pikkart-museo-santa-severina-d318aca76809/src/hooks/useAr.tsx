import { ArContext, ArContextType } from "@/components/ArProvider";

import { useContext } from "react";

export const useAr = (): ArContextType => useContext(ArContext);