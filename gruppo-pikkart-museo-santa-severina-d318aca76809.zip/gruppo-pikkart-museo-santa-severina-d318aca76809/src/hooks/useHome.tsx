import { HomeContext, HomeContextType } from "@/components/HomeProvider";
import { useContext } from "react";

export const useHome = (): HomeContextType => useContext(HomeContext);