import { CarouselCardProps } from "@/components/CarouselCard";

export type ARLayoutTypes = 'GRIGLIA_PICCOLA' | 'GRIGLIA_MEDIA' | 'GRIGLIA_MEDIA_LARGA' | 'GRIGLIA_GRANDE' | 'GRIGLIA_GRANDE_ALTA';

export const useLayouts = (): Map<ARLayoutTypes, CarouselCardProps["cardType"]> => new Map<ARLayoutTypes, CarouselCardProps["cardType"]>([
    ["GRIGLIA_PICCOLA", "mini"],
    ["GRIGLIA_MEDIA", "small"],
    ["GRIGLIA_MEDIA_LARGA", "medium"],
    ["GRIGLIA_GRANDE", "large"],
    ["GRIGLIA_GRANDE_ALTA", "largetall"]
]);
