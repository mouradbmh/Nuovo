import { DetailsContext, DetailsContextType } from "@/components/DetailsProvider";
import { useContext } from "react";

export const useDetails = (): DetailsContextType => useContext(DetailsContext);