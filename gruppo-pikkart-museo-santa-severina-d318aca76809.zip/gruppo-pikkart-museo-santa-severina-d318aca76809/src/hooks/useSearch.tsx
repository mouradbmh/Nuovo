import { DiscoverContext, DiscoverContextType } from "@/components/DiscoverProvider";
import { useContext } from "react";

export const useSearch = (): DiscoverContextType => useContext(DiscoverContext);