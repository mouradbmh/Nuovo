import { ReportsContext, ReportsContextType } from "@/components/Reports/ReportsProvider";
import { useContext } from "react";

export const useReports = (): ReportsContextType => useContext(ReportsContext);
