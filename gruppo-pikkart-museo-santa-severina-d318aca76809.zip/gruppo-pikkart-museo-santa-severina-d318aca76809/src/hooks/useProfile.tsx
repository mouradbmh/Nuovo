import { ProfileContextType, ProfileContext } from "@/components/ProfileProvider";
import { useContext } from "react";

export const useProfile = (): ProfileContextType => useContext(ProfileContext);
