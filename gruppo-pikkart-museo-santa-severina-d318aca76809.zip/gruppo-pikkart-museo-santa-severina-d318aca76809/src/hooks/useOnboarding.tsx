import { OnboardingContext, OnboardingContextType } from "@/components/OnboardingProvider";
import { useContext } from "react";

export const useOnboarding = (): OnboardingContextType => useContext(OnboardingContext);
