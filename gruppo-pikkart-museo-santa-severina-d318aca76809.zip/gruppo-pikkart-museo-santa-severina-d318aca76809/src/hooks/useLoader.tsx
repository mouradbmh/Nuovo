import { LoaderContext, LoaderContextType } from "@/components/LoaderProvider";
import { useContext } from "react";

export const useLoader = (): LoaderContextType => useContext(LoaderContext);