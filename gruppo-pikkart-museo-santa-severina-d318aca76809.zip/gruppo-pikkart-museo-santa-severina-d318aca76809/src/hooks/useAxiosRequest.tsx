import axios from "axios";
import { useCallback, useState } from "react";
import { useKey } from "./useKeyContext";
import { useAuthToken } from "@ai4/data-request";

const useAxiosRequest = () => {

    const { key } = useKey();
    const { get } = useAuthToken();
    const [loading, setLoading] = useState<boolean>(false)

    const axiosPostFormData = useCallback(async({path,file}:{path: string, file: File}) => {


        const accessToken = `Bearer ${get()!.token}`;
        const formData = new FormData();
        formData.append('formFile', file);
        const config = {
            headers: {
                'Content-Type': 'multipart/form-data; boundary=X-TURISMO-BOUNDARY',
                'accept': '*',
                'x-api-key': key,
                'Authorization': accessToken,
            },
        };

        
        setLoading(true);
        return await axios.post(path, formData, config)
            .then((response) => {
                console.log('Risposta dal server:', response.data);
                setLoading(false);
                return { data: response?.data as { fileUniqueId: string; }, error: undefined,loading};

            })
            .catch((error: string) => {
                console.error('Errore durante la chiamata:', error);
                setLoading(false);
                return { data: undefined, error: error, loading };
            });
    }, [key,loading, get])

    return { axiosPostFormData }
}
export default useAxiosRequest;