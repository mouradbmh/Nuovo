import { useContext } from "react";
import { KeyContext, KeyContextType } from "@/components/KeyProvider";

export const useKey = (): KeyContextType => {return useContext(KeyContext)};