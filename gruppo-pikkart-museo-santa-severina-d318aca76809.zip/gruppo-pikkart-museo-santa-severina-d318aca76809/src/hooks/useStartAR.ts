declare let window: any;

import axios from "axios";
import { useState, useEffect } from "react";

const useStartAR = () => {

  const [cmsApiUrl] = useState("https://ar-13.ws.pikkart.com");
  const [arInfo, setArInfo] = useState(
    {
      apiKey: "",
      tecnologiaAr: "",
      arCmsElementId: "",
      uid: "",
      loading: <(loaded: boolean) => void>(() => { }),
    });
  // const [loadingFunction, setLoadingFunction] = useState<(loaded: boolean) => void>(loaded => {}); // Funzione di default vuota

  // #region API REQUEST
  interface ArCmsResponse {
    result: {
      code: number;
    };
    data: any;
  }

  const formatDateToISOString = (date: Date) => {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    const hours = String(date.getHours()).padStart(2, '0');
    const minutes = String(date.getMinutes()).padStart(2, '0');
    const seconds = String(date.getSeconds()).padStart(2, '0');

    const formattedDate = `${year}-${month}-${day}T${hours}:${minutes}:${seconds}`;
    return formattedDate;
  }

  const getAuthHeaderParams = () => {
    const authString = arInfo.apiKey + ":" + 'browserweb';

    return {
      Authorization: authString,
      PkDate: formatDateToISOString(new Date)
    };
  }

  const callApi = (axiosParams:
    {
      data?: any;
      headers: any;
      method: string;
      url: string;
      config:
      {
        headers:
        {
          'Content-Type': string;
        };
      };
    }) => {
    return new Promise<ArCmsResponse>((resolve, reject) => {
      console.log("call api - " + axiosParams.method, axiosParams.url);
      axiosParams.headers = getAuthHeaderParams();

      axios(axiosParams)
        .then(function (response) {
          resolve(response != null ? response.data : null);
        })
        .catch(function (response) {
          reject(new Error(response != null ? response.message : null));
        });
    });
  }

  const getInfoContentData = (arCmsElementId: string) => {
    return new Promise<ArCmsResponse>((resolve, reject) => {

      callApi({
        data: null,
        headers: null,
        method: 'get',
        url: cmsApiUrl + '/api/infocontents/' + arCmsElementId + '?l=' + 'it',
        config: {
          headers: {
            'Content-Type': 'multipart/form-data',
          }
        }
      })
        .then((response: ArCmsResponse) => {
          resolve(response);
        })
        .catch(function (error: Error) {
          reject(error);
        });
    });

  }

  const getKeypointContentsArray = (modelId: string, ownerId: number) => {
    return new Promise<ArCmsResponse>((resolve, reject) => {
      callApi({
        data: null,
        headers: null,
        method: 'get',
        url: cmsApiUrl + '/api/discover/keypoint?mvId=&mId=' + modelId + '&ow=' + ownerId,
        config: {
          headers: {
            'Content-Type': 'multipart/form-data',
          }
        }
      })
        .then((response: ArCmsResponse) => {
          resolve(response);
        })
        .catch(function (error: Error) {
          reject(error);
        });
    });
  }
  // #endregion

  // #region CORDOVA REQUEST
  const downloadDiscoverModel = (
    apiUrl: string,
    modelId: string,
    downloadMarkersToo: boolean,
    finished: () => void,
    error: (errorMsg: string) => void,
    progress: (progressValue: number) => void
  ) => {
    return new Promise(() => {
      if (window.cordova && window.cordova.plugins.pikkart) {
        window.cordova.plugins.pikkart.downloadDiscoverModel(
          [
            apiUrl, modelId, downloadMarkersToo
          ],
          success,
          errorFn
        );
        console.log('cordova');
      } else {
        errorFn("cordova.plugins.pikkart - plugin not found");
      }

      function errorFn(msg: string) {
        error(msg);
      }

      function success(progressValue: number) {
        if (progressValue == 100) {
          finished();
        } else {
          progress(progressValue);
        }
      }
    });
  }

  const startNativeDiscover = (modelId: string, contentKeypointDictionary: Array<any>) => {
    const startDiscoverFragment = (modelId: string, contentKeypointDictionary: Array<any>) => {
      const showMaskOverCamera = false;
      const useCustomTabs = true;

      if (window.cordova && window.cordova.plugins.pikkart) {
        window.cordova.plugins.pikkart.startDiscover(
          [
            cmsApiUrl,
            modelId,
            '?contentid=',
            "?keypointid=",
            contentKeypointDictionary,
            "#3EB0F7",
            showMaskOverCamera,
            useCustomTabs
          ],
          success,
          error
        );
        console.log('cordova');
      } else {
        error("cordova.plugins.pikkart - plugin not found");
      }
      function error(msg: string) {
        console.log('error', msg);

      }
      function success(status: any) {
        console.log('success', status);
      }
    }

    const finished = () => {
      console.log('download models finished');

      arInfo.loading(true);

      startDiscoverFragment(modelId, contentKeypointDictionary);
    };
    const progress = (progressValue: number) => {
      console.log('download model progress ' + progressValue);
    };

    const error = (errorMsg: string) => {
      console.log('error', errorMsg);
    };

    downloadDiscoverModel(cmsApiUrl, modelId, true, finished, error, progress);
  }
  // #endregion

  const startDiscover = (arCmsElementId: string) => {
    arInfo.loading(false);
    getInfoContentData(arCmsElementId)
      .then((response: ArCmsResponse) => {
        if (response.result.code === 200) {
          const modelId = response.data.content.extlId;
          const ownerId = response.data.content.ownerId
          getKeypointContentsArray(modelId, ownerId)
            .then((response: ArCmsResponse) => {
              if (response.result.code === 200) {
                if (response.data && Array.isArray(response.data)) {
                  const contentKeypointDictionary = response.data.reverse();

                  //anche se è un array vuoto finisce qua
                  startNativeDiscover(modelId, contentKeypointDictionary);
                }
                else {
                  throw new Error('Errore nella risposta della richiesta');
                }
              }
              else {
                throw new Error('Errore nella risposta della richiesta');
              }
            })
            .catch(function (error: Error) {
              console.log('error', error);
              throw error;
            });
        } else {
          throw new Error('Errore nella risposta della richiesta');
        }
      })
      .catch(function (error: Error) {
        console.log('error', error);
        throw error;
      });
  };

  useEffect(() => {
    if (arInfo.tecnologiaAr == "AR_DISCOVER") {
      startDiscover(arInfo.arCmsElementId);
      // startDiscover('19738')
    }
  }, [arInfo]);

  const startAR = (apiKey: string, uid: string, tecnologiaAr: string, arCmsElementId: string, loading: (loaded: boolean) => void,) => {
    setArInfo({ apiKey, tecnologiaAr, arCmsElementId, uid, loading });
  }

  return { startAR }
}

export default useStartAR;