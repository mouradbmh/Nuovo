import { useContext } from "react";
import { NavigationContext, NavigationContextType } from "../components/NavigationProvider";

export const useNavigation = (): NavigationContextType => useContext(NavigationContext);