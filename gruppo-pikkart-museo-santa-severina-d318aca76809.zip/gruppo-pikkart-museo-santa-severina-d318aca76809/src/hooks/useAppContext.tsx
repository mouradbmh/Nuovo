import { useContext } from "react";
import { AppContext, AppContextType } from "@/components/AppProvider";

export const useAppContext = (): AppContextType => useContext(AppContext);
