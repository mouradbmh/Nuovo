import { useContext } from "react";
import { AuthContextType, AuthContext } from "../components/AuthProvider";

export const useAuth = (): AuthContextType => useContext(AuthContext);