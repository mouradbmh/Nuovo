import { ProfileContentContextType, ProfileContentContext } from "@/components/ProfileContentProvider";
import { useContext } from "react";

export const useProfileContent = (): ProfileContentContextType => useContext(ProfileContentContext);
