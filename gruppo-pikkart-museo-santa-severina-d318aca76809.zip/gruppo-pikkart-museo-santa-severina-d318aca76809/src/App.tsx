import '@/App.css'
// import Routing from '@/components/Routing'
// import { AuthProvider } from '@/components/AuthProvider'
// import { BrowserRouter as Router } from 'react-router-dom'
// import { NavigationProvider } from '@/components/NavigationProvider'
// import { DataProvider } from '@ai4/data-request'
// import AppProvider from '@/components/AppProvider/AppProvider'
// import GlobalLayout from '@/components/GlobalLayout'
// import { ProfileProvider } from '@/components/ProfileProvider'
// import { Dispatch, SetStateAction, createContext, useEffect, useMemo, useState } from 'react'
// import { useKey } from './hooks/useKeyContext'
import { KeyProvider } from './components/KeyProvider'
import AppWithData from './AppWithData'
import { LoaderProvider } from './components/LoaderProvider';
import { useLayoutEffect } from 'react';
import { addListeners, getDeliveredNotifications, registerNotifications } from './utils/notificationUtils';
import { Capacitor } from '@capacitor/core';

function App() {
  // const { key } = useKey()
  // const dom = 'dom';

  // useEffect(() => {
  //   if(localStorage.getItem('xApiKey')){
  //     setKey(localStorage.getItem('xApiKey') ?? '');
  //   }
  // }, [])

  // const record = {
  //   'dom': {
  //     base: 'https://ai4-api-wppa.pikkart.com/',
  //     xAPIKey: localStorage.getItem('xApiKey') ?? ''
  //   },
  //   'auth': {
  //     base: import.meta.env.VITE_URL_WP_ENDPOINT,
  //   }
  // };

  // useEffect(() => {
  //   console.log('key changed', key)
  // },[key])

  // const record = useMemo(() => {
  //   return {
  //     'dom': {
  //       base: 'https://ai4-api-wppa.pikkart.com/',
  //       xAPIKey: key
  //     },
  //     'auth': {
  //       base: import.meta.env.VITE_URL_WP_ENDPOINT,
  //     }
  //   }
  // }, [key])

  // useEffect(() => {
  //   console.log('record', record)
  // }, [record])

  useLayoutEffect(() => {
    if (!localStorage.getItem('i18nextLng')) {
      localStorage.setItem('i18nextLng', 'it-IT');
    }
  }, []);

  useLayoutEffect(() => {
    if (Capacitor.isNativePlatform()) {
      void registerNotifications();
      void addListeners();
      void getDeliveredNotifications();
    }
  }, []);

  return (
    <KeyProvider>
      <LoaderProvider>
        <AppWithData />
      </LoaderProvider>
    </KeyProvider>
  );
}

export default App;
