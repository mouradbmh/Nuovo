import ArContent from './ArContent';
import { useAr } from "@/hooks/useAr";
import { useMemo } from "react";
import Loader from "@/components/Loader";



const ArExperienceContent = () => {
    const { data, loading } = useAr();

    const status = useMemo(() => {
        if (loading) {
            return (
                <Loader />
                // <div className={classes.loading_overlay}>
                    // {/* <Icon.Loader className={classes.icon_overlay} width={80} height={80} /> */}
                    
                // {/* </div> */}
            )
        } else {
            return (
                <ArContent loading={loading} contents={data} />
            )
        }
    }, [loading, data])


    return status;

    // return (
    //     <>
    //         {
    //             loading ? (
    //                 <div className={classes.loading_overlay}>
    //                     <Icon.Loader className={classes.icon_overlay} width={80} height={80} />
    //                 </div>) : (
    //                 <>
    //                     <ArContent loading={loading} contents={data} />
    //                 </>
    //             )
    //         }
    //     </>
    // );
};

export default ArExperienceContent;