import ArScreen from "@/screens/AR/ArScreen";
import ArContent from "@/screens/AR/ArContent";

export default ArScreen;
export { ArContent };
