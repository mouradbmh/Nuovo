import classes from "@/screens/AR/ArContent.module.css";

import { useAr } from "@/hooks/useAr";
import { useTranslation } from "react-i18next";
import { useAppContext } from "@/hooks/useAppContext";
import { styled } from "styled-components";
import TextComponent from "@/components/TextComponent";
import IconTextButton from "@/components/IconTextButton";
import NavigationTopBar from "@/components/NavigationTopBar";
import { ChevronLeft, MapPin } from "react-feather";
import { useNavigation } from "@/hooks/useNavigation";
import ButtonBar from "@/components/ButtonBar";

import TextSubtext from "@/components/TextSubtext";

import { useEffect, useMemo, useState } from "react";
import { ArExperience } from "@/components/ArProvider/ArTypes";
import ArSection from "@/components/ArSection";


export interface ArContentProps {
  loading: boolean;
  contents?: ArExperience;
}

const StyledArContent = styled.div<{ backgroundcolor: string, color: string }>`
    background-color: ${props => props.backgroundcolor};
    color: ${props => props.color};
    height: 100vh;
`;


const ArContent = ({ loading, contents }: ArContentProps) => {
  const { data, experienceType, types } = useAr();
  const { t } = useTranslation();
  const { theme } = useAppContext();
  const { goBack } = useNavigation();

  const [showAlert, setShowAlert] = useState<boolean>(false);

  // const experienceTypes = ['AR_INVOKVE', 'AR_DISCOVER', 'MAKER', 'AR_LOGO']


  const selectionSort = (inputArr: {
    uid?: string,
    name?: string,
    rilevanza?: number,
  }[]) => {
    const n = inputArr.length;

    for (let i = 0; i < n; i++) {
      // Finding the smallest number in the subarray
      let min = i;
      for (let j = i + 1; j < n; j++) {
        // console.log(inputArr[j].rilevanza)
        if ((inputArr[j].rilevanza ?? 0) < (inputArr[min].rilevanza ?? 0)) {
          min = j;
        }
      }
      if (min != i) {
        // Swapping the elements
        let tmp = inputArr[i];
        inputArr[i] = inputArr[min];
        inputArr[min] = tmp;
      }
    }
    return inputArr;
  }

  const style = {
    backColorPrimario: "#27272A",//TODO: FIX CON OGGETTO THEME
    backColorSecondario: "#E4E4E7",
    textColorPrimario: "#FFFFFF",  //TODO: FIX CON OGGETTO THEME
    textColorSecondario: "#18181B",//TODO: FIX CON OGGETTO THEME
    buttonColor: "#DC2626",//TODO: FIX CON OGGETTO THEME
    buttonTextColor: "#FAFAFA",//TODO: FIX CON OGGETTO THEME
    textTitle: classes.title,
    textTitleDesc: classes.titleDesc,
    cardBackColor: "var(--zinc-700, #3F3F46)",
    cardDescColor: "var(--white, #FFF)"
  }

  const recommended: ArExperience = useMemo(() => {
    return {
      esperienzeArQuery: {
        esperienzeAR: {
          lista: data?.esperienzeArQuery?.esperienzeAR?.lista.filter(record => record.consigliata) ?? []
        }
      }
    }
  }, [data]);

  // const experienceTypes = useMemo(() => { //Tipologia contenuto => esperienza.tipologiaContenutoApp.nomeEntità ???
  //   const types: string[] = [];
  //   if (data && data?.esperienzeArQuery?.esperienzeAR?.lista.length > 0) {
  //     data.esperienzeArQuery.esperienzeAR.lista.map(element => {
  //       if (!types.includes(element.tipologiaContenutoApp.nomeEntita)) {
  //         types.push(element.tipologiaContenutoApp.nomeEntita)
  //       } else return;
  //     })
  //   }
  //   return types;
  // }, [data])

  useEffect(() => {
    console.log(experienceType)
  }, [experienceType])

  if (!loading && !contents) {
    return (
      <TextComponent text_key={t('unable_to_load')} />
    );
  }

  return (
    <StyledArContent backgroundcolor={style.backColorPrimario}
      color={theme?.stile?.coloreFronte ? theme.stile.coloreFronte : 'black'}>
      <NavigationTopBar className={classes.overlapping_topbar}
        button_left={
          <IconTextButton
            backColor="transparent"
            contentsColor="white"
            buttonMode="outline_borderless"
            icon={<ChevronLeft height="24" strokeWidth={1.5} width="24" onClick={() => goBack()} />} />
        }
        title_key={t('ar')}
        textColor={style.textColorPrimario}
        backColor={style.backColorPrimario}
      />

      { }
      <div className={[classes.alertContainer, classes.payoff_container].join(' ')} style={showAlert ? { backgroundColor: "#E4E4E7" } : { display: "none" }}>
        <ButtonBar
          text_color={style.textColorSecondario}
          backColor={style.buttonColor}
          text_key={t('ar_func_description')}
          text_subtext_key={""}
          button_text_key={t('activate')}
          button_text_color={style.buttonTextColor}
          showArrow={false}
          icon={<MapPin height="24" strokeWidth={1.5} width="24" />}
          onClick={() => { setShowAlert(!showAlert) }}
        />
      </div>

      <TextSubtext className={classes.padded}
        textProps={{
          className: style.textTitle,
          text_key: t('ar_content'),
          text_line: 'tight',
          text_weight: 'semibold',
        }}
        backColor={style.backColorPrimario}
        gap={16}
        subtextProps={{
          className: style.textTitleDesc,
          text_key: t('ar_content_desc')

        }}
      />
      {
        data && data?.esperienzeArQuery?.esperienzeAR?.lista.length > 0 &&
        <ArSection
          content={{
            content: recommended.esperienzeArQuery.esperienzeAR.lista,
            // nomeEntita:
            tipologiaLayout: "GRIGLIA_GRANDE_ALTA",
            nome: t('recommended'),
          }}
          cardStyled={true} vediTuttiText={t("view_all_f")} style={style}
        />
      }

      {/* {
        data && data?.esperienzeArQuery?.esperienzeAR?.lista.filter(t => t.tecnologiaAr === "AR_DISCOVER").length > 0 && <ArSection content={{
          content: data.esperienzeArQuery.esperienzeAR.lista.filter(t => t.tecnologiaAr === "AR_DISCOVER"),
          tipologiaLayout: "GRIGLIA_MEDIA",
          nome: t('all_ar'),
        }} cardStyled={false} vediTuttiText={t("view_all_f")} style={style} />

      } */}
      {selectionSort(types).map(type => {
        return <ArSection content={{
          content: data?.esperienzeArQuery.esperienzeAR.lista.filter(t => t.tipologiaContenutoApp.uniqueId === type.uid),
          tipologiaLayout: "GRIGLIA_MEDIA",
          nome: type.name,
        }} cardStyled={false} vediTuttiText={t("view_all_f")} style={style} />
      }
      )}
    </StyledArContent>
  );
};

export default ArContent;