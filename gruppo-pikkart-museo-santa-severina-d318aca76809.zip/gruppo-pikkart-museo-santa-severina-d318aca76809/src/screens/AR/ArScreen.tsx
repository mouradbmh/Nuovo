import ScreenLayout from "@/components/ScreenLayout";
import { ArProvider } from "@/components/ArProvider";
import ArExperienceContent from "./ArExperienceContent";

const DetailsScreen = () => {
    return (
        <ScreenLayout showBottomBar={false}>
            <ArProvider>
                <ArExperienceContent />
            </ArProvider>
        </ScreenLayout>
    );
};

export default DetailsScreen;