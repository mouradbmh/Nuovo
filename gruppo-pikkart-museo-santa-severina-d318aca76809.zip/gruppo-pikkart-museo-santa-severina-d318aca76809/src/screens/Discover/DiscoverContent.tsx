import { Dispatch, SetStateAction, useMemo, useState } from "react";
import MapContent from "./MapContent";
import ListContent from "./ListContent";

type Props = {
  setBarVisibility: Dispatch<SetStateAction<boolean>>;
}


const DiscoverContent = ({ setBarVisibility }: Props) => {
  const [map, setMap] = useState(false);


  const status = useMemo(() => {
    if (map) {
      return <MapContent setBarVisibility={setBarVisibility} setMap={setMap} showMap={map} />
    } else {
      return <ListContent setBarVisibility={setBarVisibility} setMap={setMap} showMap={map} />
    }
  }, [map, setBarVisibility])

  return status;
};

export default DiscoverContent;