import FiltersList from "@/components/FiltersList";
import InputComponent from "@/components/InputComponent";
import SearchResultsList from "@/components/SearchResultsList";
import Separator from "@/components/Separator";
import { useSearch } from "@/hooks/useSearch";

import classes from "@/screens/Discover/discoverContent.module.css";
import { Dispatch, SetStateAction } from "react";
import * as Icon from "react-feather";
import { useTranslation } from "react-i18next";
import 'leaflet/dist/leaflet.css'
import { useAppContext } from "@/hooks/useAppContext";
import { useKey } from "@/hooks/useKeyContext";

type Props = {
  setBarVisibility: Dispatch<SetStateAction<boolean>>;
  setMap: Dispatch<SetStateAction<boolean>>;
  showMap: boolean;
}


const ListContent = ({ setBarVisibility, setMap, showMap }: Props) => {
  const { searchResults, setSearchString, selectedFilter, filterType, loading, recentLoading } = useSearch();
  const { t } = useTranslation();
  const { theme } = useAppContext();
  const { configs } = useKey()

  const handleScreen = () => {
    const mp = showMap;
    setMap(!mp);
    setBarVisibility(mp)
  }

  return (
    <div className={classes.discover_container}>
      <Separator />

      <div className={classes.input}>
        <InputComponent
          inputName={t('search')}
          inputType='text'
          inputProps={{
            text_key: '',
            text_size: 'regular',
          }}
          placeholderText_key={t('search')}
          icon={<Icon.Search width={16} height={16} />}
          onEnter={e => setSearchString(e.trim())}
          enterKeyHint="search"
        />
      </div>
      <div className={classes.filters_container}>
        <FiltersList className={classes.filters} collapsed={showMap} />
      </div>

      <SearchResultsList searchResults={searchResults} loading={loading} recentLoading={recentLoading} />
      {(configs?.AppTerritoriale === "true" && (filterType.find(el => el.uniqueId === selectedFilter)?.nomeEntita === 'AttivitaCommerciale' || filterType.find(el => el.uniqueId === selectedFilter)?.nomeEntita === 'PuntoDiInteresse')) &&
        <div style={{
          background: theme?.bottonePrimario?.coloreSfondo ?? 'grey',
          border: '1px solid #047857',
          width: 250,
          height: 48,
          borderRadius: 48,
          bottom: 90,
          right: 10,
          position: "absolute",
          alignItems: "center",
          justifyContent: "center",
          display: "flex",
          color: "white",
          boxShadow: '0px 0px 3px 3px rgba(65, 65, 65, 0.29)',
        }} onClick={() => { handleScreen() }}><Icon.MapPin style={{ marginRight: 30 }} />Visualizza in mappa</div>
      }

    </div>
  );
};

export default ListContent;