import DiscoverScreen from "@/screens/Discover/DiscoverScreen";
import DiscoverContent from "@/screens/Discover/DiscoverContent";

export default DiscoverScreen;
export { DiscoverContent };
