import ScreenLayout from "@/components/ScreenLayout";
import { DiscoverContent } from "@/screens/Discover";
import DiscoverProvider from "@/components/DiscoverProvider/DiscoverProvider";
import { useState } from "react";

const DiscoverScreen = () => {
    const [barVisible, setVisible] = useState(true);
    return (
        <ScreenLayout currentScreen='discover' showBottomBar={barVisible}>
            <DiscoverProvider>
                <DiscoverContent setBarVisibility={setVisible} />
                {/* <MapContent /> */}
            </DiscoverProvider>
        </ScreenLayout>
    );
};

export default DiscoverScreen;