import Carousel from "@/components/Carousel";
import { CarouselCardProps } from "@/components/CarouselCard";
import FiltersList from "@/components/FiltersList";
import IconTextButton from "@/components/IconTextButton";
import NavigationTopBar from "@/components/NavigationTopBar";
import { useSearch } from "@/hooks/useSearch";
import classes from "@/screens/Discover/discoverContent.module.css";
import { Dispatch, SetStateAction, useMemo, useState } from "react";
import * as Icon from "react-feather";
import { useTranslation } from "react-i18next";
import { MapContainer, Marker } from "react-leaflet";
import 'leaflet/dist/leaflet.css'
import ReactLeafletGoogleLayer from 'react-leaflet-google-layer';
import L from "leaflet";
import { useAppContext } from "@/hooks/useAppContext";
import { renderToStaticMarkup } from "react-dom/server";
import { useKey } from "@/hooks/useKeyContext";

type Props = {
    setBarVisibility: Dispatch<SetStateAction<boolean>>;
    setMap: Dispatch<SetStateAction<boolean>>;
    showMap: boolean;
}


const MapContent = ({ setBarVisibility, setMap, showMap }: Props) => {
    const { configs } = useKey();
    const { searchResults } = useSearch();
    const { t } = useTranslation();
    const { theme } = useAppContext()
    const [selected, setSelected] = useState<string>('');

    const customMarkerNode = (
        <div style={{
            background: theme?.bottonePrimario?.coloreFronte ?? 'white',
            width: 45,
            height: 35,
            borderRadius: 15,
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            boxShadow: 'rgba(0, 0, 0, 0.35) 0px 5px 15px',
            borderWidth: 1,
            borderStyle: 'solid',
            borderColor: theme?.bottonePrimario?.coloreFronte ?? 'white'
        }}>
            <Icon.MapPin color={theme?.bottonePrimario?.coloreSfondo ?? 'black'} />
        </div>
    )

    const customMarker = L.divIcon({
        html: renderToStaticMarkup(customMarkerNode),
        iconSize: undefined,
        className: classes.invisible,
        popupAnchor: [23.5, 0]
    })

    const customHighlightedMarkerNode = (
        <div style={{
            background: theme?.bottonePrimario?.coloreFronte ?? 'white',
            width: 45,
            height: 35,
            borderRadius: 15,
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            boxShadow: 'rgba(0, 0, 0, 0.35) 0px 5px 15px',
            borderWidth: 1,
            borderStyle: 'solid',
            borderColor: theme?.bottonePrimario?.coloreSfondo ?? 'black'
        }}>
            <Icon.MapPin color={theme?.bottonePrimario?.coloreSfondo ?? 'black'} />
        </div>
    )

    const customHighlightedMarker = L.divIcon({
        html: renderToStaticMarkup(customHighlightedMarkerNode),
        iconSize: undefined,
        className: classes.invisible,
        popupAnchor: [23.5, 0]
    })


    const cordCenter: [number, number] = useMemo(() => {
        if (searchResults?.length === 1 && searchResults[0].contenuti) {
            const conts = searchResults[0].contenuti.length;
            const x = searchResults[0].contenuti.reduce((acc, el) => {
                const lat = el.lat ?? 0
                return acc + lat
            }, 0)
            const y = searchResults[0].contenuti.reduce((acc, el) => {
                const lng = el.lng ?? 0
                return acc + lng
            }, 0)
            const evaluatedCord: [number, number] = [x / conts, y / conts]
            if (evaluatedCord[0] === 0 && evaluatedCord[1] === 0) {
                return [42.86, 12.61]
            }
            return evaluatedCord;
        }
        return [42.86, 12.61]
    }, [searchResults])

    const handleScreen = () => {
        const mp = showMap;
        setMap(!mp);
        setBarVisibility(mp)
    }

    return (
        <div className={classes.discover_container}>
            <NavigationTopBar className={classes.overlapping_topbar}
                button_left={
                    <IconTextButton
                        backColor="transparent"
                        contentsColor="black"
                        buttonMode="outline_borderless"
                        icon={<Icon.ChevronLeft height="24" strokeWidth={1.5} width="24" onClick={handleScreen} />} />
                }
                title_key={searchResults?.length === 1 ? t(searchResults[0].nomeEntita!) : t('Map')}
                textColor="black"
                button_right={
                    <IconTextButton
                        backColor="transparent"
                        contentsColor="black"
                        buttonMode="outline_borderless"
                        icon={<Icon.X height="24" strokeWidth={1.5} width="24" />} />
                } />

            <div className={classes.filters_container}>
                <FiltersList className={classes.filters} collapsed={showMap} />
            </div>

            <div style={{
                height: '100vh',
            }}
            >
                <MapContainer center={cordCenter} zoom={10} scrollWheelZoom={false} style={{ height: '100%' }}>
                    <ReactLeafletGoogleLayer apiKey={configs?.GOOGLE_API_KEY} type="roadmap" />
                    <ReactLeafletGoogleLayer apiKey={configs?.GOOGLE_API_KEY} type="roadmap" />
                    {searchResults?.length === 1 && searchResults[0].contenuti?.map(el => {
                        if (el.lat && el.lng) {
                            return (
                                <Marker
                                    position={[el.lat ?? 0, el.lng ?? 0]}
                                    icon={el.uniqueId === selected ? customHighlightedMarker : customMarker}
                                    eventHandlers={{
                                        click: () => {
                                            console.log('selected', el.titolo, el.uniqueId)
                                            setSelected(el.uniqueId ?? '')
                                        }
                                    }}
                                >
                                </Marker>
                            )
                        }
                    })}
                </MapContainer>
            </div>
            <Carousel
                slides={searchResults?.flatMap(el => el.contenuti).map(cc => {
                    return {
                        cardType: 'medium',
                        id: cc?.uniqueId ?? '',
                        imgUrl: cc?.urlImmagine ?? '',
                        title: cc?.titolo ?? '',
                        //eventText: cc?.nomeEntita ?? '',
                        titleColor: 'black',
                        contentType: cc?.nomeEntita ?? '',
                    } as CarouselCardProps & { id: string, contentType: string }
                })}
                selectedSlide={selected}
            />

        </div>
    );
};

export default MapContent;