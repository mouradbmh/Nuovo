import IconTextButton from "@/components/IconTextButton";
import InputComponent from "@/components/InputComponent";
import Loader from "@/components/Loader";
import LoginButtonsComponent from "@/components/LoginButtonsComponent";
import NavigationTopBar from "@/components/NavigationTopBar";
import TextComponent from "@/components/TextComponent";
import TextSubtext from "@/components/TextSubtext";
import { useAuth } from "@/hooks/useAuth";
import classes from "@/screens/Login/loginContent.module.css";
import { t } from "i18next";
import { Dispatch, SetStateAction, useEffect, useState } from "react";
import { ChevronLeft } from "react-feather";

const SignupContent = ({ setIsSignUp }: { setIsSignUp: Dispatch<SetStateAction<boolean>> }) => {
    const [email, setEmail] = useState<string>('');
    const [password, setPassword] = useState<string>('');
    const [confPassword, setConfpassword] = useState<string>('');
    const [name, setName] = useState<string>('')
    const [surname, setSurname] = useState<string>('')
    const [phone, setPhone] = useState<string>('')
    const { register, registerError, registerLoading, regMsg, resetLoginMessages, setRegErr } = useAuth();

    const timeout = (delay: number) => {
        return new Promise(res => setTimeout(res, delay))
    }

    const onLogin = () => {
        // TODO: input validation
        if (email === '' || password === '' || email.search('@') === -1 || phone === '') {
            return;
        }

        if (password !== confPassword) {
            setRegErr(t('pwrd_mis'))
            return
        }

        console.log('registering')
        void register(name, surname, email, email, password, confPassword, phone).then(async res => {
            if (res) {
                await timeout(2000)
                setIsSignUp(false)
            }
        })
    }

    useEffect(() => {
        console.log(registerError, registerLoading)
    }, [registerError, registerLoading])

    return (
        <>
            {registerLoading &&
                <div style={{
                    position: 'absolute',
                    height: '100vh',
                    width: '100%',
                    backgroundColor: 'rgba(63,63,70,0.7)',
                    zIndex: 10
                }}>
                    <Loader />
                </div>
            }

            <NavigationTopBar
                button_left={
                    <IconTextButton
                        backColor="transparent"
                        buttonMode="outline_borderless"
                        icon={<ChevronLeft height="24" strokeWidth={1.5} width="24" />}
                        onClick={() => {
                            setIsSignUp(false)
                            resetLoginMessages()
                        }}
                    />
                }
                title_key={t("Create_account")}
            />
            <div className={classes.login_container}>
                <div className={classes.welcome_container}>
                    <TextComponent
                        text_key={t('Create_acc')}
                        text_size="title2"
                        text_weight="bold"
                    />
                    <TextComponent
                        text_key={t('Create_acc_desc')} // "Se crei un account puoi effettuare prenotazioni ed avere informazioni per te!" "We do not ask to much and will keep your information safety!"
                        text_size="small"
                    />

                    {registerError !== undefined && <TextComponent text_key={registerError} color="red" />}
                    {regMsg !== undefined && <TextComponent text_key={regMsg} color="green" />}
                </div>

                <div className={classes.login_fields_container}>

                    <div className={classes.texts_container}>
                        <InputComponent
                            inputName='name'
                            inputType='text'
                            inputProps={{
                                text_key: '',
                                text_size: 'regular',
                            }}
                            placeholderProps={{
                                text_key: t('Name'),
                                text_size: 'tiny',
                                text_weight: 'regular'
                            }}
                            setOnChange={setName}
                        />
                        <InputComponent
                            inputName='surname'
                            inputType='text'
                            inputProps={{
                                text_key: '',
                                text_size: 'regular',
                            }}
                            placeholderProps={{
                                text_key: t("Surname"),
                                text_size: 'tiny',
                                text_weight: 'regular'
                            }}
                            setOnChange={setSurname}
                        />
                        <InputComponent
                            inputName='phone number'
                            inputType='number'
                            inputProps={{
                                text_key: '',
                                text_size: 'regular',
                            }}
                            placeholderProps={{
                                text_key: t("Phone_number"),
                                text_size: 'tiny',
                                text_weight: 'regular'
                            }}
                            setOnChange={setPhone}
                        />
                        <div className={classes.email_password_container}>
                            <InputComponent
                                inputName='email'
                                inputType='email'
                                inputProps={{
                                    text_key: '',
                                    text_size: 'regular',
                                }}
                                placeholderProps={{
                                    text_key: "Email",
                                    text_size: 'tiny',
                                    text_weight: 'regular'
                                }}
                                setOnChange={setEmail}
                            />
                            <InputComponent
                                inputName='password'
                                inputType='password'
                                inputProps={{
                                    text_key: '',
                                    text_size: 'regular',
                                }}
                                placeholderProps={{
                                    text_key: "Password",
                                    text_size: 'tiny',
                                    text_weight: 'regular'
                                }}
                                showViewPasswordButton
                                setOnChange={setPassword}
                            />
                            <InputComponent
                                inputName='Confirm password'
                                inputType='password'
                                inputProps={{
                                    text_key: '',
                                    text_size: 'regular',
                                }}
                                placeholderProps={{
                                    text_key: t("Confirm_pass"),
                                    text_size: 'tiny',
                                    text_weight: 'regular'
                                }}
                                showViewPasswordButton
                                setOnChange={setConfpassword}
                            />
                            <TextSubtext
                                textProps={{
                                    text_key: "Crea una password di almeno 8 caratteri con numeri e simboli",
                                    text_size: 'small',
                                    color: 'var(--zinc-500)',
                                    text_weight: 'regular'
                                }}
                                className={classes.password_subtext}
                            />
                        </div>
                    </div>
                </div>
                <div className={classes.login_button_container}>
                    <LoginButtonsComponent onLogIn={onLogin} showAnonymousLogin={false} register />
                </div>
            </div>
        </>
    )
};

export default SignupContent;
