import ScreenLayout from "@/components/ScreenLayout";
import LoginContent from "@/screens/Login/LoginContent";
import { useAuth } from "@/hooks/useAuth";
import { Navigate } from "react-router-dom";
import { useState } from "react";
import SignupContent from "./SignupContent";

const LoginScreen = () => {
    const { isLoggedIn } = useAuth();
    const [isSignUp, setIsSignUp] = useState<boolean>(false);

    return (
        <ScreenLayout currentScreen="profile" showBottomBar={false}>
            {isLoggedIn ? (
                <Navigate to="/profile" />
            ) : (
                isSignUp ? (
                    <SignupContent setIsSignUp={setIsSignUp} />
                ) : (
                    <LoginContent setIsSignUp={setIsSignUp} />
                )
            )}
        </ScreenLayout>
    );
};

export default LoginScreen;
