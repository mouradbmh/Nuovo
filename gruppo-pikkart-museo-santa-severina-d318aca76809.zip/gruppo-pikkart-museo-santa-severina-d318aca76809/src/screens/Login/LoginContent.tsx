import IconTextButton from "@/components/IconTextButton";
import LoginButtonsComponent from "@/components/LoginButtonsComponent";
import LoginFieldsComponent from "@/components/LoginFieldsComponent";
import NavigationTopBar from "@/components/NavigationTopBar";
import TextComponent from "@/components/TextComponent";
import { ChevronLeft } from "react-feather";
import classes from "@/screens/Login/loginContent.module.css";
import { Dispatch, SetStateAction, useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useTranslation } from "react-i18next";
import { useNavigation } from "@/hooks/useNavigation";
import Loader from "@/components/Loader";
import { useAppContext } from "@/hooks/useAppContext";
import CmsBlockParser from "@/components/UtilsComponent/CmsBlockParser/CmsBlockParser";

const LoginContent = ({ setIsSignUp }: { setIsSignUp: Dispatch<SetStateAction<boolean>> }) => {
    const [email, setEmail] = useState<string>('');
    const [password, setPassword] = useState<string>('');
    const { login } = useAuth();
    const { t } = useTranslation();
    const { goBack } = useNavigation();
    const { loginLoading, loginData } = useAuth()
    const {config} = useAppContext()

    const onLogin = () => {
        // TODO: input validation
        if (email === '' || password === '') {
            return;
        }
        login(email, password);
    }

    return (
        <>
            {loginLoading &&
                <div style={{
                    position: 'absolute',
                    height: '100vh',
                    width: '100%',
                    backgroundColor: 'rgba(63,63,70,0.7)',
                    zIndex: 10
                }}>
                    <Loader />
                </div>
            }
            <NavigationTopBar
                button_left={<IconTextButton backColor="transparent" buttonMode="outline_borderless" icon={<ChevronLeft height="24" strokeWidth={1.5} width="24" onClick={goBack} />} />}
                title_key={t("login")}
                
            />
            <div className={classes.login_container}>
                <div className={classes.welcome_container}>
                    <TextComponent
                        text_key={t("welcome")}
                        text_size="title2"
                        text_weight="bold"
                    />
                    <TextComponent
                        text_key={t("create_acc_invite")} // "Se crei un account puoi effettuare prenotazioni ed avere informazioni per te!"
                        text_size="small"
                    />
                </div>
                {loginData && loginData.success === false ?
                    <div className={classes.error_container}>
                        {/* <TextComponent
                            text_key={loginData.message}
                            text_size="regular"
                            color="red"
                        /> */}
                       <CmsBlockParser content={loginData.message}/> 
                    </div>
                    :
                    <></>
                }
                <div className={classes.login_fields_container}>
                    <LoginFieldsComponent setEmail={setEmail} setPassword={setPassword} />
                </div>
                {config?.registrazioneUtente ? <div className={classes.create_account_button_container}>
                    <IconTextButton
                        textProps={{
                            text_key: t('or_create_acc')
                        }}
                        buttonMode='outline_borderless'
                        no_rounded_borders
                        onClick={() => setIsSignUp(true)}
                    />
                </div> : <></>                
                }
                <div className={classes.login_button_container}>
                    <LoginButtonsComponent onLogIn={onLogin} />
                </div>
            </div>
        </>
    )
}

export default LoginContent;