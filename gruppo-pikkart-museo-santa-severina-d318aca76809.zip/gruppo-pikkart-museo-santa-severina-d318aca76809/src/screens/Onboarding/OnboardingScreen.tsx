import { useOnboarding } from "@/hooks/useOnboarding";
import { OnboardingContent } from "@/screens/Onboarding";
import { Navigate } from "react-router-dom";

const OnboardingScreen = () => {
    const { showOnboarding } = useOnboarding();

    return (
        <>
            {showOnboarding ? (
                <OnboardingContent />
            ) : (
                <Navigate to="/" />
            )}
        </>
    );
};

export default OnboardingScreen;
