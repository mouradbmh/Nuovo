import OnboardingScreen from "@/screens/Onboarding/OnboardingScreen";
import OnboardingContent from "@/screens/Onboarding/OnboardingContent";

export { OnboardingScreen, OnboardingContent };
