import Carousel from "@/components/Carousel";
import IconTextButton from "@/components/IconTextButton";
import NavigationTopBar from "@/components/NavigationTopBar";
import { useAppContext } from "@/hooks/useAppContext";
import { useOnboarding } from "@/hooks/useOnboarding";
import { useProfile } from "@/hooks/useProfile";
import { useState } from "react";
import { ChevronLeft } from "react-feather";
import { useTranslation } from "react-i18next";

const OnboardingContent = () => {
  const { onViewOnboarding } = useOnboarding();
  const { location, prevScreen, saveProfile } = useProfile();
  const { config } = useAppContext();

  const [end, setEnd] = useState(false);
  const { t } = useTranslation();

  if (!config?.messaggiOnBoarding || (config?.messaggiOnBoarding && config.messaggiOnBoarding.length === 0)) {
    return <></>
  }

  return (
    <>
      <NavigationTopBar
        button_left={ (config?.profiliUtente && config?.profiliUtente.length > 1 ) ?
          <IconTextButton
            backColor="transparent"
            buttonMode="outline_borderless"
            icon={<ChevronLeft height="24" strokeWidth={1.5} width="24" onClick={prevScreen} />} />
          : <></>
          }
        button_right={
          <IconTextButton
            onClick={() => {
              onViewOnboarding?.();
              saveProfile();
            }}
            buttonMode='outline_borderless'
            textProps={{
              text_key: t(end ? 'proceed' : 'skip'),
              text_weight: 'semibold',
            }} />}
        title_key=""
      />
      
      <Carousel
        titleBar={{
          title: {
            text_key: location ?? '',
            text_size: 'title3',
            text_weight: 'bold',
          },
          centerTitle: true,
        }}
        showButtons
        slidesPerView={1}
        slides={
          config?.messaggiOnBoarding?.map(msg => {
            return {
              cardType: 'largesquare',
              title: msg.messaggio ?? '',
              imgUrl: msg.urlImmagine ?? '',
            }
          })
        } 
        onSlideChange={(swiper) => {
          setEnd(swiper.isEnd);
        }}/>

    </>
  );
};

export default OnboardingContent;
