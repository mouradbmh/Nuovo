import IconTextButton from "@/components/IconTextButton";
import NavigationTopBar from "@/components/NavigationTopBar";
import OnboardingButton from "@/components/OnboardingButton";
import ProgressBar from "@/components/ProgressBar";
import TextComponent from "@/components/TextComponent";
import { useAppContext } from "@/hooks/useAppContext";
import { useProfile } from "@/hooks/useProfile";
import classes from "@/screens/ProfileSetup/profileSetup.module.css";
import { ChevronLeft, HelpCircle } from "react-feather";
import { useTranslation } from "react-i18next";
import { useKey } from "@/hooks/useKeyContext.tsx";
import { useEffect } from "react";

const ProfileSetupContent = () => {
  const { config } = useAppContext();
  const { location, profileId, chooseProfile, prevScreen, nextScreen } = useProfile();
  const { t } = useTranslation();
  const { configs } = useKey();

  useEffect(() => {
    if (config?.profiliUtente && config.profiliUtente?.length === 1) {
      chooseProfile(config.profiliUtente[0].id!)
      nextScreen()
    }
  }, [chooseProfile, config?.profiliUtente, nextScreen])

  if (config?.profiliUtente && config.profiliUtente?.length === 1) {
    return <></>
  }

  return (
    <div className={classes.loading_wrapper}>
      <span className={classes.loader}></span>
    </div>
  );

  return (
    <>
      <div className={classes.progress_bar_container}>
        <ProgressBar progress={50} />
      </div>
      {
        configs?.MULTITENANT === 'true' &&
        <NavigationTopBar
          button_left={<IconTextButton backColor="transparent" buttonMode="outline_borderless" icon={<ChevronLeft height="24" strokeWidth={1.5} width="24" onClick={prevScreen} />} />}
          title_key=""
        />
      }
      <div className={classes.profile_title_container}>
        <TextComponent
          text_key={t("welcome")}
          text_size="title2"
          text_weight="bold"
        />
        <TextComponent
          text_key={`${t('setup_text_1')} ${location}. ${t('setup_text_2')}`} //È bello vederti a - Dicci di più su cosa fai qui
          text_size="small"
        />
      </div>
      <div className={classes.profiles_container}>
        {config?.profiliUtente !== undefined && (
          config?.profiliUtente?.map((profile, index) => (
            <OnboardingButton
              key={index}
              ButtonIcon={HelpCircle}
              pressed={profileId === profile.id}
              onClick={() => {
                chooseProfile(profile.id as string);
              }}
              subtext_key={profile.descrizione as string}
              text_key={profile.nome as string}
            />
          ))
        )}
      </div>
      <div className={classes.continue_button_container}>
        <IconTextButton className={classes.button}
          textProps={{
            text_key: t('continue'),
            text_weight: 'regular',
            color: 'var(--outline-bg)',
          }}
          backColor="var(--emerald-700)"
          padding={{ vertical: 16 }}
          expanded
          onClick={nextScreen}
        />
      </div>
    </>
  )
}

export default ProfileSetupContent;
