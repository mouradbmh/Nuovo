import ProfileSetupScreen from "@/screens/ProfileSetup/ProfileSetupScreen";
import LocationSetup from "@/screens/ProfileSetup/LocationSetup";
import ProfileSetupContent from "@/screens/ProfileSetup/ProfileSetupContent";

export { ProfileSetupScreen, LocationSetup, ProfileSetupContent};