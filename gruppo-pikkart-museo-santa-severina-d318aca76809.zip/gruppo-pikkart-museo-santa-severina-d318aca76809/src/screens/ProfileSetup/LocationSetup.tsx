import { LocationComponentProps } from "@/components/LocationComponent";
import ProgressBar from "@/components/ProgressBar";
import SearchLocation from "@/components/SearchLocation";
import TextComponent from "@/components/TextComponent";
// import { useAppContext } from "@/hooks/useAppContext";
import { useProfile } from "@/hooks/useProfile";
import classes from "@/screens/ProfileSetup/profileSetup.module.css";
import { useTranslation } from "react-i18next";

const LocationSetup = () => {
    const { locations } = useProfile();
    const { t } = useTranslation();
    
    return (
        <>
            <div className={classes.progress_bar_container}>
                <ProgressBar progress={10} />
            </div>
            <div className={classes.profile_setup_container}>
                <div className={classes.title_container}>
                    <TextComponent
                        text_key={t("choose_town")}
                        text_size="title2"
                        text_weight="bold"
                    />
                    <TextComponent
                        text_key={t("choose_town_info")} // "Search and select a Town. You will see all the information related."
                        text_size="small"
                    />
                </div>
                <SearchLocation locations={locations ? locations : {} as LocationComponentProps[]} />
            </div>
        </>
    );
};

export default LocationSetup;
