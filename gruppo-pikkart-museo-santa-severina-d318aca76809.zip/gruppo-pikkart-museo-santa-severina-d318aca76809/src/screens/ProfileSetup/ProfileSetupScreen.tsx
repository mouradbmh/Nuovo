import { useProfile } from "@/hooks/useProfile";
import { OnboardingScreen } from "@/screens/Onboarding";
import OnboardingProvider from "@/components/OnboardingProvider";
import ScreenLayout from "@/components/ScreenLayout";
import { LocationSetup, ProfileSetupContent } from "@/screens/ProfileSetup";
import { ScreenType } from "@/components/ProfileProvider";

const ProfileSetupScreen = () => {
  const { screen } = useProfile();

  const renderComponent = (screen: ScreenType) => {
    switch (screen) {
      case 'location': return <LocationSetup />;
      case 'profile': return <ProfileSetupContent />;
      case 'onboarding': return (
        <OnboardingProvider>
          <OnboardingScreen />
        </OnboardingProvider>
      );
      default:
        <LocationSetup />
    }
  }

  return (
    <ScreenLayout currentScreen="profile" showBottomBar={false}>
      {renderComponent(screen)}
    </ScreenLayout>
  );
};

export default ProfileSetupScreen;
