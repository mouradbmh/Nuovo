import Carousel from "@/components/Carousel";
// import { CarouselCardProps } from "@/components/CarouselCard";
import { ArElementDetails } from "@/components/DetailsProvider/DetailsTypes";
// import ExpandButton from "@/components/ExpandButton";
import IconTextButton from "@/components/IconTextButton";
import NavigationTopBar from "@/components/NavigationTopBar";
// import Separator from "@/components/Separator";
import TextSubtext from "@/components/TextSubtext";
import { useAppContext } from "@/hooks/useAppContext";
import { useNavigation } from "@/hooks/useNavigation";
import { ChevronLeft, Download, Heart } from "react-feather";
import { useTranslation } from "react-i18next";
import classes from "@/screens/Details/DetailsContent.module.css"
import TextComponent from "@/components/TextComponent";
import useStartAR from '@/hooks/useStartAR';
import { useDetails } from "@/hooks/useDetails";
import { useAuth } from "@/hooks/useAuth";
import { toast } from "react-toastify";

import { useKey } from '../../hooks/useKeyContext'

// import TextSubtextHTML from "@/components/TextSubtextHTML";
// import Spacer from "@/components/Spacer";

export interface ArElementContentProps {
  loading: boolean;
  contents: ArElementDetails;
}

// Text
// TextSubtext (title)
// TextSubtext *6
// Text
// ExpandText
// TextSubText * 4
// Carosello AR
// Carosello Interessi
// Button


const ArElementContent = ({
  loading,
  contents,
}: ArElementContentProps) => {
  
  const { configs } = useKey()

  const { t } = useTranslation();
  const { goBack } = useNavigation();
  const { theme, config } = useAppContext();

  const { startAR } = useStartAR();

  const { addFavourite, isFavourite, removeFavourite } = useDetails()
  const { isLoggedIn } = useAuth()
  // const [expandBriefDesc, setExpandBriefDesc] = useState(false);
  // const [expandDesc, setExpandDesc] = useState(false);

  if (!loading && !contents) {
    return (
      <TextComponent text_key={t('unable_to_load')} />
    );
  }
  // console.log(theme)
  console.log(contents)
  // const SHORT_DESCR_MAX_LENGTH = 150;
  // const DESCR_MAX_LENGTH = 1000;

  // const short_descr = contents.traduzioni[0].descrizioneBreve;
  // const descr = contents.traduzioni[0].descrizione;

  // const handleDownload = (href: string) => { //TODO: MODO CORRETTO?
  //   const link = document.createElement('a');
  //   link.download = 'Example-PDF-File';
  //   link.target = "_blank"
  //   link.href = href;
  //
  //   link.click();
  // };

  const loadingArContent = (loaded: boolean) => {
    console.log('loaded', loaded);
  }

  return (
    <div className={[classes.column].join(' ')} >
      <NavigationTopBar className={classes.overlapping_topbar}
        button_left={
          <IconTextButton
            backColor="transparent"
            contentsColor="white"
            buttonMode="outline_borderless"
            icon={<ChevronLeft height="24" strokeWidth={1.5} width="24" className={classes.fa_globe} onClick={() => goBack()} />} />
        }
        title_key={t('ar_element')}
        textColor="white"
        shadow={true}
        button_right={
          <IconTextButton
            backColor="transparent"
            contentsColor="white"
            buttonMode="outline_borderless"
            icon={(config?.registrazioneUtente && config.autenticazioneBasic && config.autenticazioneTramiteIdentitaDigitale) ?
              <Heart
                height="24"
                strokeWidth={1.5}
                width="24"
                className={classes.fa_globe}
                fill={isFavourite ? 'currentColor' : 'none'}
                onClick={() => {
                  if (isLoggedIn) {
                    isFavourite ? void removeFavourite(contents.__typename) : void addFavourite(contents.__typename)
                  } else {
                    toast.warn(t("fav_log"))
                  }
                }}
              /> : <></>
            } />
        } />

      <Carousel
        slidesPerView={1}
        slides={[
          {
            cardType: 'largetall',
            id: '0',
            imgUrl: contents.immagineUrl
          }
        ]}

        paddingType='none'
        showButtons
        overlayButtons />

      {/* <div className={classes.ar_button_container}>
        <IconTextButton className={classes.ar_button}
          backColor={theme?.bottoneSecondario?.coloreSfondo ?? undefined}
          contentsColor={theme?.bottoneSecondario?.coloreFronte ?? undefined}
          bordercolor={theme?.bottoneSecondario?.coloreBordo ?? undefined}
          padding={{ all: 12 }}
          icon={<PlayCircle width={24} height={24} strokeWidth={1.5} />}
          textProps={{
            text_key: t('view_instructions'),
            text_size: "regular"
          }}
          invertContents
        />
      </div> */}

      <div className={[classes.column].join(' ')} style={{ gap: 24, marginTop: 24 }}>
        <TextSubtext className={classes.padded}
          textProps={{
            text_key: contents?.traduzioni[0]?.titolo ?? "Titolo",
            text_size: 'title3',
            text_weight: 'bold',
            className: classes.centered,
            color: theme?.contenuto?.containerContenutiAr?.coloreTitoloItem ?? undefined

          }}
          subtextProps={{
            text_key: contents?.traduzioni[0]?.istruzioni ?? "Istruzioni",
            text_size: 'regular',
            color: theme?.contenuto?.containerContenutiAr?.coloreDescrizioneItem ?? undefined
          }}
          gap={16} />



        {
          contents.allegati && contents.allegati.length > 0 && <div className={[classes.column, classes.padded].join(' ')} style={{ gap: 5 }}>
            <TextComponent
              text_key={t('interaction_objects')} //TODO: TRADUZIONI 
              text_line='tight'
              text_size='small'
              text_weight='bold'

            />


            {contents.allegati.map((a) => {
              return (
                  <IconTextButton
                  textProps={{
                    text_key: a.traduzioni[0].titolo ? a.traduzioni[0].titolo : t('download_files'),
                    text_size: 'small',
                    color: theme?.contenuto?.link?.coloreFronte ?? undefined
                  }}
                  subTextProps={{
                    text_key: a.traduzioni[0].descrizione ? a.traduzioni[0].descrizione : '',
                    text_line: "normal",
                    text_size: "tiny",
                    color: theme?.contenuto?.containerContenutiAr?.coloreDescrizioneItem  ?? '#000000'
                  }}
                  backColor="transparent"
                  icon={<Download width={12} height={12} strokeWidth={1.5}
                    stroke={theme?.contenuto?.link?.coloreFronte ?? undefined} />}
                  invertContents />

              )
            })
            }
          </div>
        }

        {
          (contents.immagini.length > 0) && <Carousel
            // background={theme?.contenuto?.containerContenutiCorrelati?.backColor ?? undefined}
            slidesPerView='auto'
            slides={
              contents.immagini.map(cc => {
                return {
                  cardType: "large",
                  id: cc.uniqueId ?? "", // TODO: cambiare query
                  imgUrl: cc.fileUrl ?? "",
                  title: cc.traduzioni[0].titolo,
                  titleWeight: "regular",
                  hasArButton: true

                  // secondaryInfo: '----', // TODO: cambiare query
                  // description: cc.traduzioni[0].descrizioneBreve,
                  // eventText: cc.tipologiaContenutoApp.traduzioni[0].nome,

                  // titleColor: theme?.contenuto?.containerContenutiCorrelati?.coloreTitoloItem ?? undefined,
                  // secondaryInfoColor: theme?.contenuto?.containerContenutiCorrelati?.coloreDataItem ?? undefined,
                  // descriptionColor: theme?.contenuto?.containerContenutiCorrelati?.coloreDescrizioneItem ?? undefined,
                  // contentType: ''
                }
              })
            } />
        }

        <div className={classes.start_ar_container} >
          <IconTextButton
            textProps={{
              text_key: t('start_ar')
            }}
            onClick={() => {
              startAR(configs?.CMS_API_KEY as string, contents.uniqueId, contents.tecnologiaAr, contents.arCmsElementId, loadingArContent);
            }}
            expanded
            backColor={theme?.bottonePrimario?.coloreSfondo ?? undefined}
            contentsColor={theme?.bottonePrimario?.coloreFronte ?? undefined}
            bordercolor={theme?.bottonePrimario?.coloreBordo ?? undefined}
            padding={{ vertical: 16, horizontal: 32 }} />
        </div>

      </div>
    </div>
  );
};

export default ArElementContent;