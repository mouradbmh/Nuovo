import Carousel from "@/components/Carousel";
import { NewsDetails } from "@/components/DetailsProvider";
import IconTextButton from "@/components/IconTextButton";
import NavigationTopBar from "@/components/NavigationTopBar";
import TextSubtext from "@/components/TextSubtext";
import { useAppContext } from "@/hooks/useAppContext";
import { useState } from "react";
import { ChevronLeft, /*Download,*/ Heart } from "react-feather";
import { useTranslation } from "react-i18next";
import useStartAR from '@/hooks/useStartAR';
// import { useNavigate } from "react-router-dom";

import classes from "@/screens/Details/DetailsContent.module.css"
import { useNavigation } from "@/hooks/useNavigation";
import TextComponent from "@/components/TextComponent";
import ExpandButton from "@/components/ExpandButton";
import Separator from "@/components/Separator";
// import { styled } from "styled-components";
import TextSubtextHTML from "@/components/TextSubtextHTML";
import { useDetails } from "@/hooks/useDetails";
import ContentGallery from "@/components/ContentGallery";
import { useAuth } from "@/hooks/useAuth";
import { toast } from "react-toastify";
import { useKey } from "@/hooks/useKeyContext";

export interface NewsContentProps {
  loading: boolean;
  contents: NewsDetails;
}

// const StyledDiv = styled.div<{ backcolor?: string }>`
//   ${props => props.backcolor !== undefined ? `background-color: ${props.backcolor};` : ''}
// `;

const NewsContent = ({
  loading,
  contents,
}: NewsContentProps) => {
  const { configs } = useKey()
  const { t } = useTranslation();
  const { goBack } = useNavigation();
  const { theme, config } = useAppContext();
  const { isFavourite, addFavourite, removeFavourite } = useDetails()
  const { isLoggedIn } = useAuth()
  const [expandBriefDesc, setExpandBriefDesc] = useState(false);
  const [expandDesc, setExpandDesc] = useState(false);
  const [showPrev, setShowPrev] = useState(false);

  const { startAR } = useStartAR();

  if (!loading && !contents) {
    return (
      <TextComponent text_key={t('unable_to_load')} />
    );
  }

  const SHORT_DESCR_MAX_LENGTH = 150;
  const TEXT_MAX_LENGTH = 1000;

  const short_descr = contents.traduzioni[0].descrizioneBreve;
  const text = contents.traduzioni[0].testoCompleto;

  const loadingArContent = (loaded: boolean) => {
    console.log('loaded', loaded);
  }

  return (
    <div className={[classes.column, classes.column_gap].join(' ')}>
      <NavigationTopBar className={classes.overlapping_topbar}
        button_left={
          <IconTextButton
            backColor="transparent"
            contentsColor="white"
            buttonMode="outline_borderless"
            icon={<ChevronLeft height="24" strokeWidth={1.5} width="24" className={classes.fa_globe} onClick={() => goBack()} />} />
        }
        title_key={t('news')}
        textColor="white"
        shadow={true}
        button_right={
          <IconTextButton
            backColor="transparent"
            contentsColor="white"
            buttonMode="outline_borderless"
            icon={(config?.registrazioneUtente || config?.autenticazioneBasic || config?.autenticazioneTramiteIdentitaDigitale) ?
              <Heart
                height="24"
                strokeWidth={1.5}
                width="24"
                className={classes.fa_globe}
                fill={isFavourite ? 'currentColor' : 'none'}
                onClick={() => {
                  if (isLoggedIn) {
                    isFavourite ? void removeFavourite(contents.__typename) : void addFavourite(contents.__typename)
                  } else {
                    toast.warn(t("fav_log"))
                  }
                }}
              />: <></>
            }
          />
        } />
      <div onClick={() => setShowPrev(!showPrev)}>
        <ContentGallery contents={[
          ...(contents.video.filter(v => v.tipologia !== 'VIDEO_360').map((v, index) => {
            return {
              id: 'video_' + index.toString(),
              imgUrl: v.previewFileUrl,
              hasPlayButton: true,
              videoUrl: v.fileUrl,
              type: v.tipologia,
              ytUrl: v.urlYoutube
            }
          })),
          {
            id: '0',
            imgUrl: contents.immagineUrl,
            hasPlayButton: false,
          },
          ...(contents.immagini.map((i, index) => {
            return {
              id: 'img_' + index.toString(),
              imgUrl: i.fileUrl,
              hasPlayButton: false,
            }
          }))
        ]} />
      </div>

      <TextSubtext className={classes.padded}
        textProps={{
          text_key: contents.traduzioni[0].titolo,
          text_size: 'title3',
          text_weight: 'bold',
        }}
        subtextProps={{
          text_key: contents.traduzioni[0].titolo,
          text_line: 'normal',
        }} />

      <TextSubtext className={classes.padded}
        textProps={{
          text_key: t('brief_description'),
          text_line: 'tight',
          text_weight: 'semibold',
        }}
        subtextProps={{
          text_key: short_descr.length < SHORT_DESCR_MAX_LENGTH || expandBriefDesc ? short_descr : short_descr.slice(0, SHORT_DESCR_MAX_LENGTH) + '...',
          text_line: 'normal',
        }} />
      {
        short_descr.length >= SHORT_DESCR_MAX_LENGTH && <ExpandButton className={classes.centered}
          expanded={expandBriefDesc}
          setExpanded={setExpandBriefDesc}
          expanded_text={t('show_less')}
          not_expanded_text={t('show_more')}
          padding={{ vertical: 8, horizontal: 16 }} />
      }

      <Separator />

      <TextSubtextHTML className={classes.padded}
        textProps={{
          text_key: t('text'),
          text_size: 'large',
          text_weight: 'bold',
          color: theme?.contenuto?.coloreTitoloParagrafo ?? undefined
        }}
        gap={16}
        subTextHTML={text.length < TEXT_MAX_LENGTH || expandDesc ? text : text.slice(0, TEXT_MAX_LENGTH) + '...'} />
      {
        text.length >= TEXT_MAX_LENGTH && <ExpandButton className={classes.centered}
          expanded={expandDesc}
          setExpanded={setExpandDesc}
          expanded_text={t('show_less')}
          not_expanded_text={t('show_more')}
          padding={{ vertical: 8, horizontal: 16 }} />
      }

      {
        contents.esperienzeAr.length > 0 && <Carousel
          titleBar={{
            title: {
              text_key: t('linked_ar_contents'),
              text_size: 'large',
              text_weight: 'bold',
              color: theme?.contenuto?.coloreTitoloParagrafo ?? undefined
            },
          }}
          background={theme?.contenuto?.containerContenutiAr?.backColor ?? undefined}
          slidesPerView='auto'
          slides={
            contents.esperienzeAr.map(e => {
              return {
                cardType: 'medium',
                id: e.uniqueId,
                title: e.traduzioni[0].titolo,
                eventText: e.tipologiaContenutoApp.traduzioni[0].nome,
                imgUrl: e.immagineUrl,
                button: {
                  text: t('start_AR'),
                  onClick: () => {
                    startAR(configs?.CMS_API_KEY as string, e.uniqueId, e.tecnologiaAr, e.arCmsElementId, loadingArContent);
                  }
                }
              }
            })
          } />
      }

      {
        contents.persone.length > 0 && <Carousel
          titleBar={{
            title: {
              text_key: t('writers'),
              text_size: 'large',
              text_weight: 'bold',
            },
          }}
          slidesPerView='auto'
          slides={
            contents.persone.map(p => {
              return {
                cardType: 'small',
                id: p.nome + '_' + p.cognome,
                title: p.nome + ' ' + p.cognome,
                imgUrl: p.fotoUrl,
              }
            })
          } />
      }

      {
        contents.contenutiCorrelati.length > 0 && <Carousel
          titleBar={{
            title: {
              text_key: t('suggestions'),
              text_size: 'large',
              text_weight: 'bold',
              color: theme?.contenuto?.containerContenutiCorrelati?.coloreTitoloTipologia ?? undefined
            },
          }}
          background={theme?.contenuto?.containerContenutiCorrelati?.backColor ?? undefined}
          slidesPerView='auto'
          slides={
            contents.contenutiCorrelati.map(cc => {
              return {
                cardType: 'medium',
                id: cc.uniqueId,
                imgUrl: cc.immagineUrl,
                title: cc.traduzioni[0].titolo,
                secondaryInfo: '----', // TODO: cambiare query
                description: cc.traduzioni[0].descrizioneBreve,
                eventText: cc.tipologiaContenutoApp?.traduzioni[0].nome ?? '',
                titleColor: theme?.contenuto?.containerContenutiCorrelati?.coloreTitoloItem ?? undefined,
                secondaryInfoColor: theme?.contenuto?.containerContenutiCorrelati?.coloreDataItem ?? undefined,
                descriptionColor: theme?.contenuto?.containerContenutiCorrelati?.coloreDescrizioneItem ?? undefined,
                contentType: cc.tipologiaContenutoApp?.nomeEntita ?? ''
              }
            })
          } />
      }


    </div >
  );
};

export default NewsContent;