import ScreenLayout from "@/components/ScreenLayout";
import { DetailsContent } from "@/screens/Details";
import DetailsProvider from "@/components/DetailsProvider";

const DetailsScreen = () => {
    return (
        <ScreenLayout showBottomBar={false}>
            <DetailsProvider>
                <DetailsContent />
            </DetailsProvider>
        </ScreenLayout>
    );
};

export default DetailsScreen;