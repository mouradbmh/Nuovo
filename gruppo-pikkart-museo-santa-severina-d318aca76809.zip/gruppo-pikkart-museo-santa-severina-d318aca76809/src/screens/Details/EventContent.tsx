import Carousel from "@/components/Carousel";
import { EventDetails } from "@/components/DetailsProvider";
import IconTextButton from "@/components/IconTextButton";
import NavigationTopBar from "@/components/NavigationTopBar";
import TextSubtext from "@/components/TextSubtext";
import { useAppContext } from "@/hooks/useAppContext";
import { useState } from "react";
import { ChevronLeft, Download, Heart, MapPin } from "react-feather";
import { useTranslation } from "react-i18next";
// import { useNavigate } from "react-router-dom";

import classes from "@/screens/Details/DetailsContent.module.css"
import { useNavigation } from "@/hooks/useNavigation";
import TextComponent from "@/components/TextComponent";
import ExpandButton from "@/components/ExpandButton";
import Separator from "@/components/Separator";
import TextSubtextGroup from "@/components/TextSubtextGroup";
// import DottyIcons from "@/components/DottyIcons";
import { styled } from "styled-components";
import TextSubtextHTML from "@/components/TextSubtextHTML";
import { useDetails } from "@/hooks/useDetails";
import ContentGallery from "@/components/ContentGallery";
import { toast } from "react-toastify";
import { useAuth } from "@/hooks/useAuth";
import ParentChild from "@/components/ParentChild";

export interface EventContentProps {
  loading: boolean;
  contents: EventDetails;
}

// Carosello Immagini
// Text
// TextSubtext (title)
// TextSubtext *6
// Text
// ExpandText
// Carosello AR
// Carosello Galleria
// TextSubText * 3
// FileView
// TextSubtext
// GoToMainEvent
// Carosello Eventi
// Carosello Partecipanti
// Carosello Organizzatori
// Carosello Patrocinanti
// Carosello Sponsors
// Carosello Esperienze
// Checkout {
// 	    Row
// 		    Text
// 		    Button
// }

const StyledDiv = styled.div<{ backcolor?: string }>`
  ${props => props.backcolor !== undefined ? `background-color: ${props.backcolor};` : ''}
`;

const EventContent = ({
  loading,
  contents,
}: EventContentProps) => {
  const { t } = useTranslation();
  const { goBack } = useNavigation();
  const { theme, config } = useAppContext();
  const { addFavourite, isFavourite, removeFavourite, appTerritoriale } = useDetails()
  const { isLoggedIn } = useAuth()
  const [expandBriefDesc, setExpandBriefDesc] = useState(false);
  const [expandDesc, setExpandDesc] = useState(false);

  if (!loading && !contents) {
    return (
      <TextComponent text_key={t('unable_to_load')} />
    );
  }

  const weekday = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
  const month = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];

  const start = new Date(contents.dataOraInizio);
  const end = new Date(contents.dataOraFine);

  const formattedHoursMinutes = (date: Date) => `${date.getHours() < 10 ? '0' + date.getHours().toString() : date.getHours()}:${date.getMinutes() < 10 ? '0' + date.getMinutes().toString() : date.getMinutes()}`;

  const sameDay = start.toDateString() == end.toDateString();

  const SHORT_DESCR_MAX_LENGTH = 150;
  const DESCR_MAX_LENGTH = 1000;

  const short_descr = contents.traduzioni[0].descrizioneBreve;
  const descr = contents.traduzioni[0].descrizioneEstesa;

  console.log(contents)
  return (
    <div className={[classes.column, classes.column_gap].join(' ')}>
      <NavigationTopBar className={classes.overlapping_topbar}
        button_left={
          <IconTextButton
            backColor="transparent"
            contentsColor="white"
            buttonMode="outline_borderless"
            icon={<ChevronLeft height="24" strokeWidth={1.5} width="24" className={classes.fa_globe} onClick={() => goBack()} />} />
        }
        title_key={t('event')}
        textColor="white"
        shadow={true}
        button_right={
          <IconTextButton
            backColor="transparent"
            contentsColor="white"
            buttonMode="outline_borderless"
            icon={(config?.registrazioneUtente || config?.autenticazioneBasic || config?.autenticazioneTramiteIdentitaDigitale) ?
              <Heart
                height="24"
                strokeWidth={1.5}
                width="24"
                className={classes.fa_globe}
                fill={isFavourite ? 'currentColor' : 'none'}
                onClick={() => {
                  if (isLoggedIn) {
                    isFavourite ? void removeFavourite(contents.__typename) : void addFavourite(contents.__typename)
                  } else {
                    toast.warn(t("fav_log"))
                  }
                }}
              /> : <></>
            } />
        } />

      <ContentGallery contents={[
        ...(contents.video.filter(v => v.tipologia !== 'VIDEO_360').map((v, index) => {
          return {
            id: 'video_' + index.toString(),
            imgUrl: v.previewFileUrl,
            hasPlayButton: true,
            videoUrl: v.fileUrl,
            type: v.tipologia,
            ytUrl: v.urlYoutube
          }
        })),
        {
          id: '0',
          imgUrl: contents.immagineUrl,
          hasPlayButton: false,
        },
        ...(contents.immagini.map((i, index) => {
          return {
            id: 'img_' + index.toString(),
            imgUrl: i.fileUrl,
            hasPlayButton: false,
          }
        }))
      ]} />

      {(appTerritoriale === "true" && contents.luoghi && contents.luoghi.length === 1) &&
        <a href={'https://maps.google.com?q=' + contents.luoghi[0].latitudine + ',' + contents.luoghi[0].longitudine}>
          <div className={classes.map_button_container}>
            <IconTextButton className={classes.map_button}
              backColor={theme?.bottonePrimario?.coloreSfondo ?? undefined}
              contentsColor={theme?.bottonePrimario?.coloreFronte ?? undefined}
              bordercolor={theme?.bottonePrimario?.coloreBordo ?? undefined}
              padding={{ all: 12 }}
              icon={<MapPin width={24} height={24} strokeWidth={1.5} color={theme?.bottonePrimario?.coloreFronte ?? 'white'} />}
            />
          </div>
        </a>
      }

      <TextComponent className={classes.padded} text_key={
        sameDay ? // Stesso giorno
          `${weekday[start.getDay()]} ${("0" + start.getDate()).slice(-2)} ${month[start.getMonth()]} - ${formattedHoursMinutes(start)} - ${formattedHoursMinutes(end)}` : // TODO: forzare lunghezza minima di due caratteri (es: '3' visto come '03')
          `${t('from')} ${weekday[start.getDay()]} ${("0" + start.getDate()).slice(-2)} ${month[start.getMonth()]} ${t('to')} ${weekday[end.getDay()]} ${("0" + end.getDate()).slice(-2)} ${month[end.getMonth()]}`
      } color={theme?.contenuto?.link?.coloreFronte ?? undefined} />

      <TextSubtext className={classes.padded}
        textProps={{
          text_key: contents.traduzioni[0].titolo,
          text_size: 'title3',
          text_weight: 'bold',
        }}
        subtextProps={{
          text_key: contents.traduzioni[0].sottotitolo,
          text_line: 'normal',
        }} />

      <TextSubtextGroup className={classes.padded}
        textProps={{
          text_key: t('event_type'),
          text_line: 'tight',
          text_weight: 'semibold',
        }}
        subtextProps={
          contents.tipologie.map(t => {
            return {
              text_key: t.traduzioni[0].nome,
              text_line: 'normal',
            }
          })
        } />
      <TextSubtextGroup className={classes.padded}
        textProps={{
          text_key: t('suitable_for'),
          text_line: 'tight',
          text_weight: 'semibold',
        }}
        subtextProps={
          contents.adattoA.map(a => {
            return {
              text_key: a.traduzioni[0].nome,
              text_line: 'normal',
            }
          })
        } />
      <TextSubtextGroup className={classes.padded}
        textProps={{
          text_key: t('timetables'),
          text_line: 'tight',
          text_weight: 'semibold',
        }}
        subtextProps={sameDay ? [
          {
            text_key: `${t('from')} ${formattedHoursMinutes(start)} ${t('to')} ${formattedHoursMinutes(end)}`
          }
        ] : [
          {
            text_key: `${t('from')} ${weekday[start.getDay()]} ${("0" + start.getDate()).slice(-2)} ${month[start.getMonth()]} ${t('at')} ${formattedHoursMinutes(start)}`,
          },
          {
            text_key: `${t('to')} ${weekday[end.getDay()]} ${("0" + end.getDate()).slice(-2)} ${month[end.getMonth()]} ${t('at')} ${formattedHoursMinutes(end)}`,
          }
        ]} />
      <TextSubtext className={classes.padded}
        textProps={{
          text_key: t('entrance'),
          text_line: 'tight',
          text_weight: 'semibold',
        }}
        subtextProps={{
          text_key: contents.costo > 0 ? t('paid_access') : t('free_access'),
          text_line: 'normal',
        }} />
      <TextSubtextGroup className={classes.padded}
        textProps={{
          text_key: t('contacts'),
          text_line: 'tight',
          text_weight: 'semibold',
        }}
        subtextProps={
          contents.puntiDiContatto.map(pdc => {
            return {
              text_key: pdc.tipologia.nome,
              text_line: 'normal',
            }
          })
        } />
      <TextSubtext className={classes.padded}
        textProps={{
          text_key: t('brief_description'),
          text_line: 'tight',
          text_weight: 'semibold',
        }}
        subtextProps={{
          text_key: short_descr.length < SHORT_DESCR_MAX_LENGTH || expandBriefDesc ? short_descr : short_descr.slice(0, SHORT_DESCR_MAX_LENGTH) + '...',
          text_line: 'normal',
        }} />
      {
        short_descr.length >= SHORT_DESCR_MAX_LENGTH && <ExpandButton className={classes.centered}
          expanded={expandBriefDesc}
          setExpanded={setExpandBriefDesc}
          expanded_text={t('show_less')}
          not_expanded_text={t('show_more')}
          padding={{ vertical: 8, horizontal: 16 }} />
      }

      {
        contents.luoghi.length > 0 && <Carousel
          titleBar={{
            title: {
              text_key: t('event_locations'),
              text_size: 'large',
              text_weight: 'bold',
              color: theme?.contenuto?.coloreTitoloParagrafo ?? undefined
            },
          }}
          background={theme?.contenuto?.containerContenutiAr?.backColor ?? undefined}
          slidesPerView='auto'
          slides={
            contents.luoghi.map(e => {
              return {
                cardType: 'medium',
                id: e.uniqueId,
                title: e.indirizzo,
                eventText: e.nome,
                imgUrl: e.immagineUrl,
                titleColor: theme?.contenuto?.evento?.containerLuoghi?.coloreTitoloItem ?? undefined,
                secondaryInfoColor: theme?.contenuto?.evento?.containerLuoghi?.coloreTitoloItem ?? undefined,
                descriptionColor: theme?.contenuto?.evento?.containerLuoghi?.coloreTitoloItem ?? undefined,
                button: {
                  text: t('go_to_maps'),
                  onClick: () => {
                    window.open('https://maps.google.com?q=' + e.latitudine + ',' + e.longitudine, '_blank');
                    return {};
                  }
                },
                contentType: 'Luogo'
              }
            })
          } />
      }

      <TextSubtextGroup className={classes.padded}
        textProps={{
          text_key: t('access_conditions'),
          text_line: 'tight',
          text_weight: 'semibold',
        }}
        subtextProps={
          contents.condizioniDiAccesso.map(cda => {
            return {
              text_key: cda.traduzioni[0].nome,
              text_line: 'normal',
            }
          })
        } />


      <Separator />

      {
        contents.esperienzeAr.length > 0 && <Carousel
          titleBar={{
            title: {
              text_key: t('linked_ar_contents'),
              text_size: 'large',
              text_weight: 'bold',
              color: theme?.contenuto?.coloreTitoloParagrafo ?? undefined
            },
          }}
          background={theme?.contenuto?.containerContenutiAr?.backColor ?? undefined}
          slidesPerView='auto'
          slides={
            contents.esperienzeAr.map(e => {
              return {
                cardType: 'medium',
                id: e.uniqueId,
                title: e.traduzioni[0].titolo,
                eventText: e.tipologiaContenutoApp.traduzioni[0].nome,
                imgUrl: e.immagineUrl,
                button: {
                  text: t('start_AR')
                }
              }
            })
          } />
      }

      {/* <TextSubtext className={classes.padded}
        textProps={{
          text_key: t('description'),
          text_size: 'large',
          text_weight: 'bold',
        }}
        subtextProps={{
          text_key: descr.length < DESCR_MAX_LENGTH || expandDesc ? descr : descr.slice(0, DESCR_MAX_LENGTH) + '...',
          text_line: 'normal',
        }}
        gap={16} />
      {
        descr.length >= DESCR_MAX_LENGTH && <ExpandButton className={classes.centered}
          expanded={expandDesc}
          setExpanded={setExpandDesc}
          expanded_text={t('show_less')}
          not_expanded_text={t('show_more')}
          padding={{ vertical: 8, horizontal: 16 }} />
      } */}
      <TextSubtextHTML className={classes.padded}
        textProps={{
          text_key: t('description'),
          text_size: 'large',
          text_weight: 'bold',
          color: theme?.contenuto?.coloreTitoloParagrafo ?? undefined
        }}
        gap={16}
        subTextHTML={descr.length < DESCR_MAX_LENGTH || expandDesc ? descr : descr.slice(0, DESCR_MAX_LENGTH) + '...'} /> {/* TODO: limitare la lunghezza della descrizione, sebbene sia contenuto HTML */}

      {
        descr.length >= DESCR_MAX_LENGTH && <ExpandButton className={classes.centered}
          expanded={expandDesc}
          setExpanded={setExpandDesc}
          expanded_text={t('show_less')}
          not_expanded_text={t('show_more')}
          padding={{ vertical: 8, horizontal: 16 }} />
      }

      {contents.traduzioni[0].aChiERivolto && <TextSubtext className={classes.padded}
        textProps={{
          text_key: t('aimed_at'),
          text_size: 'large',
          text_weight: 'bold',
          color: theme?.contenuto?.coloreTitoloParagrafo ?? undefined
        }}
        subtextProps={{
          text_key: contents.traduzioni[0].aChiERivolto,
          text_line: 'normal',
          color: theme?.stile?.coloreFronte ?? undefined,
        }}
        gap={16} />}

      {contents.traduzioni[0].infoPerIlbooking && <TextSubtext className={classes.padded}
        textProps={{
          text_key: t('access_mode'),
          text_size: 'large',
          text_weight: 'bold',
          color: theme?.contenuto?.coloreTitoloParagrafo ?? undefined
        }}
        subtextProps={{
          text_key: contents.traduzioni[0].infoPerIlbooking,
          text_line: 'normal',
          color: theme?.stile?.coloreFronte ?? undefined,
        }}
        gap={16} />}

      {
        contents.traduzioni[0].ulterioriInformazioni.length > 0 && <TextSubtextHTML className={classes.padded}
          textProps={{
            text_key: t('more_info'),
            text_size: 'large',
            text_weight: 'bold',
            color: theme?.contenuto?.coloreTitoloParagrafo ?? undefined
          }}
          gap={16}
          subTextHTML={contents.traduzioni[0].ulterioriInformazioni} />
      }

      {
        contents.allegati.length > 0 && <StyledDiv className={[classes.file_downloads_container].join(' ')}
          backcolor={theme?.contenuto?.containerContenutiAr?.backColor ?? undefined}>
          <TextComponent text_key={t('available_download')} text_size='large' text_weight='bold'
            color={theme?.contenuto?.coloreTitoloParagrafo ?? undefined} />
          <div className={classes.column}>
            {
              contents.allegati.map(a => {
                return (
                  <>
                    <a href={a.file.fileUrl} download>
                      <IconTextButton
                        textProps={{
                          text_key: a.traduzioni[0].titolo ? a.traduzioni[0].titolo : t('download_files'),
                          text_size: 'small',
                          color: theme?.contenuto?.link?.coloreFronte ?? undefined
                        }}
                        subTextProps={{
                          text_key: a.traduzioni[0].descrizione ? a.traduzioni[0].descrizione : '',
                          text_line: "normal",
                          text_size: "tiny",
                          color: theme?.contenuto?.coloreTitoloParagrafo ?? '#000000'
                        }}
                        backColor="transparent"
                        icon={<Download width={12} height={12} strokeWidth={1.5}
                          stroke={theme?.contenuto?.link?.coloreFronte ?? undefined} />}
                        invertContents />
                    </a>
                    {/* {a.traduzioni[0].titolo !== undefined && <a href={a.file.fileUrl} download style={{fontSize: '12px', marginTop: '5px'}}>
                      {a.traduzioni[0].titolo}
                    </a>} */}
                  </>
                );
              })
            }
          </div>
        </StyledDiv>
      }

      {
        (contents.eventoGenitore || contents.appuntamenti) && <ParentChild EventContent={contents} />
      }

      {
        contents.persone.length > 0 && <Carousel
          titleBar={{
            title: {
              text_key: t('participants'),
              text_size: 'large',
              text_weight: 'bold',
            },
          }}
          slidesPerView='auto'
          slides={
            contents.persone.map(p => {
              return {
                cardType: 'small',
                id: p.nome + '_' + p.cognome,
                title: p.nome + ' ' + p.cognome,
                imgUrl: p.fotoUrl,
              }
            })
          } />
      }
      {
        contents.organizzatoDa.length > 0 && <Carousel
          titleBar={{
            title: {
              text_key: t('organized_by'),
              text_size: 'large',
              text_weight: 'bold',
            },
          }}
          slidesPerView='auto'
          slides={
            contents.organizzatoDa.map(o => {
              return {
                cardType: 'smaller',
                id: o.denominazione,
                imgUrl: o.immagineUrl,
                title: o.denominazione,
              }
            })}
          paddingType='horizontal'
          hr={true} />
      }
      {
        contents.patrocinatoDa.length > 0 && <Carousel
          titleBar={{
            title: {
              text_key: t('endorsed_by'),
              text_size: 'large',
              text_weight: 'bold',
            },
          }}
          slidesPerView='auto'
          slides={
            contents.patrocinatoDa.map(p => {
              return {
                cardType: 'smaller',
                id: p.denominazione,
                imgUrl: p.immagineUrl,
                title: p.denominazione,
              }
            })}
          paddingType='horizontal'
          hr={true}
        />
      }
      {
        contents.sponsor.length > 0 && <Carousel
          titleBar={{
            title: {
              text_key: t('sponsored_by'),
              text_size: 'large',
              text_weight: 'bold',
            },
          }}
          slidesPerView='auto'
          slides={
            contents.sponsor.map(s => {
              return {
                cardType: 'smaller',
                id: s.denominazione,
                imgUrl: s.immagineUrl,
                title: s.denominazione,
              }
            })
          }
          paddingType='horizontal' />
      }

      {
        contents.contenutiCorrelati.length > 0 && <Carousel
          titleBar={{
            title: {
              text_key: t('suggestions'),
              text_size: 'large',
              text_weight: 'bold',
              color: theme?.contenuto?.containerContenutiCorrelati?.coloreTitoloTipologia ?? undefined
            },
          }}
          background={theme?.contenuto?.containerContenutiCorrelati?.backColor ?? undefined}
          slidesPerView='auto'
          slides={
            contents.contenutiCorrelati.map(cc => {
              return {
                cardType: 'medium',
                id: cc.uniqueId, // TODO: cambiare query per prendere dati
                imgUrl: cc.immagineUrl,
                title: cc.traduzioni[0].titolo,
                secondaryInfo: '----', // TODO: cambiare query per prendere dati
                description: cc.traduzioni[0].descrizioneBreve,
                eventText: cc.tipologiaContenutoApp?.traduzioni[0].nome ?? '',
                titleColor: theme?.contenuto?.containerContenutiCorrelati?.coloreTitoloItem ?? undefined,
                secondaryInfoColor: theme?.contenuto?.containerContenutiCorrelati?.coloreDataItem ?? undefined,
                descriptionColor: theme?.contenuto?.containerContenutiCorrelati?.coloreDescrizioneItem ?? undefined,
                contentType: cc.tipologiaContenutoApp?.nomeEntita ?? '',
              }
            })
          } />
      }
      < StyledDiv className={classes.price_container}
        backcolor={theme?.contenuto?.containerContenutiAr?.backColor ?? undefined}> {/* FIXME: deve essere barra inferiore */}
        <TextComponent text_key={`${contents.costo}€`} text_size='title3' text_weight='bold' />
        <IconTextButton
          textProps={{
            text_key: t('buy')
          }}
          backColor={theme?.bottonePrimario?.coloreSfondo ?? undefined}
          contentsColor={theme?.bottonePrimario?.coloreFronte ?? undefined}
          bordercolor={theme?.bottonePrimario?.coloreBordo ?? undefined}
          padding={{ vertical: 16, horizontal: 70 }} />
      </StyledDiv>


    </div>
  );
};

export default EventContent;