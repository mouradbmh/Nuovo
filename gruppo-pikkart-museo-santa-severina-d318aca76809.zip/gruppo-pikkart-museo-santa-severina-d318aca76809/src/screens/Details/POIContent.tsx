import Carousel from "@/components/Carousel";
import { POIDetails } from "@/components/DetailsProvider/DetailsTypes";
import ExpandButton from "@/components/ExpandButton";
import IconTextButton from "@/components/IconTextButton";
import NavigationTopBar from "@/components/NavigationTopBar";
import Separator from "@/components/Separator";
import TextSubtext from "@/components/TextSubtext";
import TextSubtextGroup from "@/components/TextSubtextGroup";
import { useAppContext } from "@/hooks/useAppContext";
import { useNavigation } from "@/hooks/useNavigation";
import { useMemo, useState } from "react";
import { ChevronLeft, Heart, MapPin } from "react-feather";
import { useTranslation } from "react-i18next";
import classes from "@/screens/Details/DetailsContent.module.css"
import TextComponent from "@/components/TextComponent";
import TextSubtextHTML from "@/components/TextSubtextHTML";
import { useDetails } from "@/hooks/useDetails";
import { CardType } from "@/components/CarouselCard/CarouselCard.tsx";
import ContentGallery from "@/components/ContentGallery";
import { toast } from "react-toastify";
import { useAuth } from "@/hooks/useAuth";
import "react-toastify/dist/ReactToastify.css"
import useStartAR from '@/hooks/useStartAR';
// import { styled } from "styled-components";
// import DottyIcons from "@/components/DottyIcons";
import ParentChild from "@/components/ParentChild";
import { useKey } from "@/hooks/useKeyContext";

export interface POIContentProps {
  loading: boolean;
  contents?: POIDetails;
}

// Text
// TextSubtext (title)
// TextSubtext *6
// Text
// ExpandText
// TextSubText * 4
// Carosello AR
// Carosello Interessi
// Button

const POIContent = ({
  loading,
  contents,
}: POIContentProps) => {
  const { configs } = useKey()
  const { t } = useTranslation();
  const { goBack } = useNavigation();
  const { theme, config } = useAppContext();
  const { addFavourite, isFavourite, removeFavourite, appTerritoriale } = useDetails()
  const { isLoggedIn } = useAuth()

  const [expandBriefDesc, setExpandBriefDesc] = useState(false);
  const [expandDesc, setExpandDesc] = useState(false);

  const SHORT_DESCR_MAX_LENGTH = 150;
  const DESCR_MAX_LENGTH = 1000;
  const short_descr = useMemo(() => contents?.traduzioni[0]?.descrizioneBreve ?? '', [contents]);
  const descr = useMemo(() => contents?.traduzioni[0]?.descrizione ?? '', [contents]);
  const video360 = useMemo(() => contents?.video.filter(v => v.tipologia === "VIDEO_360"), [contents]);

  const { startAR } = useStartAR();

  if (!loading && !contents) {
    return (
      <TextComponent text_key={t('unable_to_load')} />
    );
  }

  if (!contents) {
    return (
      <></>
    );
  }

  const loadingArContent = (loaded: boolean) => {
    console.log('loaded', loaded);
  }
  
  return (
    <div className={[classes.column, classes.column_gap].join(' ')}>
      <NavigationTopBar className={classes.overlapping_topbar}
        button_left={
          <IconTextButton
            backColor="transparent"
            contentsColor="white"
            buttonMode="outline_borderless"
            icon={<ChevronLeft height="24" strokeWidth={1.5} width="24" className={classes.fa_globe} onClick={() => goBack()} />} />
        }
        title_key={t('point_of_interest')}
        textColor="white"
        shadow={true}
        button_right={
          <IconTextButton
            backColor="transparent"
            contentsColor="white"
            buttonMode="outline_borderless"
            icon={(config?.registrazioneUtente || config?.autenticazioneBasic || config?.autenticazioneTramiteIdentitaDigitale) ?
              <Heart
                height="24"
                strokeWidth={1.5}
                width="24"
                className={classes.fa_globe}
                fill={isFavourite ? 'currentColor' : 'none'}
                onClick={() => {
                  if (isLoggedIn) {
                    isFavourite ? void removeFavourite(contents.__typename) : void addFavourite(contents.__typename)
                  } else {
                    toast.warn(t("fav_log"))
                  }
                }}
              /> : <></>
            } />
        } />

      <ContentGallery contents={[
        ...(contents.video.filter(v => v.tipologia !== 'VIDEO_360').map((v, index) => {
          return {
            id: 'video_' + index.toString(),
            imgUrl: v.previewFileUrl,
            hasPlayButton: true,
            videoUrl: v.fileUrl,
            type: v.tipologia,
            ytUrl: v.urlYoutube
          }
        })),
        {
          id: '0',
          imgUrl: contents.immagineUrl,
          hasPlayButton: false,
        },
        ...(contents.immagini.map((i, index) => {
          return {
            id: 'img_' + index.toString(),
            imgUrl: i.fileUrl,
            hasPlayButton: false,
          }
        }))
      ]} />

      {(appTerritoriale === "true" && contents.latitudine && contents.longitudine) &&
        <a href={'https://maps.google.com?q=' + contents.latitudine + ',' + contents.longitudine} >
          <div className={classes.map_button_container}>
            <IconTextButton className={classes.map_button}
              backColor={theme?.bottonePrimario?.coloreSfondo ?? undefined}
              contentsColor={theme?.bottonePrimario?.coloreFronte ?? undefined}
              bordercolor={theme?.bottonePrimario?.coloreBordo ?? undefined}
              padding={{ all: 12 }}
              icon={<MapPin width={24} height={24} strokeWidth={1.5} color={theme?.bottonePrimario?.coloreFronte ?? 'white'} />}
            />
          </div>
        </a>
      }

      <TextSubtext className={classes.padded}
        textProps={{
          text_key: contents.traduzioni[0]?.nome,
          text_size: 'title3',
          text_weight: 'bold',
        }}
      // subtextProps={{
      //   text_key: '????',
      //   text_line: 'normal',
      // }} 
      />

      <TextSubtextGroup className={classes.padded}
        textProps={{
          text_key: t('type'),
          text_line: 'tight',
          text_weight: 'semibold',
        }}
        subtextProps={
          contents.tipologie.map(t => {
            return {
              text_key: t.traduzioni[0]?.nome,
              text_line: 'normal',
            }
          })
        } />
      <TextSubtext className={classes.padded}
        textProps={{
          text_key: t('address'),
          text_line: 'tight',
          text_weight: 'semibold',
        }}
        subtextProps={{
          text_key: contents.indirizzo,
          text_line: 'normal',
        }} />

      <TextSubtextHTML className={classes.padded}
        textProps={{
          text_key: t('visitors_timetables'),
          text_line: 'tight',
          text_weight: 'semibold',
        }}
        subTextHTML={contents.traduzioni[0]?.orariPerIlPubblico} />
      <TextSubtextGroup className={classes.padded}
        textProps={{
          text_key: t('access_conditions'),
          text_line: 'tight',
          text_weight: 'semibold',
        }}
        subtextProps={
          contents.condizioniDiAccesso.map(cda => {
            return {
              text_key: cda.traduzioni[0]?.nome,
              text_line: 'normal',
            }
          })
        } />

      <TextSubtext className={classes.padded}
        textProps={{
          text_key: t('brief_description'),
          text_line: 'tight',
          text_weight: 'semibold',
        }}
        subtextProps={{
          text_key: short_descr.length < SHORT_DESCR_MAX_LENGTH || expandBriefDesc ? short_descr : short_descr.slice(0, SHORT_DESCR_MAX_LENGTH) + '...',
          text_line: 'normal',
        }} />
      {
        short_descr.length >= SHORT_DESCR_MAX_LENGTH && <ExpandButton className={classes.centered}
          expanded={expandBriefDesc}
          setExpanded={setExpandBriefDesc}
          expanded_text={t('show_less')}
          not_expanded_text={t('show_more')}
          padding={{ vertical: 8, horizontal: 16 }} />
      }

      <Separator />

      {
        contents.esperienzeAr.length > 0 && <Carousel
          titleBar={{
            title: {
              text_key: t('linked_ar_contents'),
              text_size: 'large',
              text_weight: 'bold',
              color: theme?.contenuto?.coloreTitoloParagrafo ?? undefined
            },
          }}
          background={theme?.contenuto?.containerContenutiAr?.backColor ?? undefined}
          slidesPerView='auto'
          slides={
            contents.esperienzeAr.map(e => {
              return {
                cardType: 'medium',
                id: e.uniqueId,
                title: e.traduzioni[0]?.titolo,
                eventText: e.tipologiaContenutoApp.traduzioni[0]?.nome,
                imgUrl: e.immagineUrl,
                button: {
                  text: t('start_AR'),
                  onClick: () => {
                    startAR(configs?.CMS_API_KEY as string, e.uniqueId, e.tecnologiaAr, e.arCmsElementId, loadingArContent);
                  }
                }
              }
            })
          } />
      }

      {
        (contents.matterportSpaces.length > 0
          || contents.tourVirtuali.length > 0
          || contents.elementi3D.length > 0
          || (video360?.length ?? 0) > 0) &&
        <Carousel
          titleBar={{
            title: {
              text_key: t('immersive_contents'),
              text_size: 'large',
              text_weight: 'bold',
              color: theme?.contenuto?.coloreTitoloParagrafo ?? undefined
            },
          }}
          background={theme?.contenuto?.containerContenutiCorrelati?.backColor ?? undefined}
          slidesPerView='auto'
          slides={[
            ...contents.matterportSpaces.map(cc => {
              return {
                cardType: 'large' as CardType,
                id: cc.uniqueId, // TODO: cambiare query
                imgUrl: cc.previewFileUrl,
                title: cc.traduzioni[0]?.titolo,
                secondaryInfo: '', // TODO: cambiare query
                description: cc.traduzioni[0]?.descrizione,
                titleColor: theme?.contenuto?.containerContenutiCorrelati?.coloreTitoloItem ?? undefined,
                secondaryInfoColor: theme?.contenuto?.containerContenutiCorrelati?.coloreDataItem ?? undefined,
                descriptionColor: theme?.contenuto?.containerContenutiCorrelati?.coloreDescrizioneItem ?? undefined,
                contentType: 'MatterportSpace',
                code: cc.codice
              }
            }),
            ...contents.tourVirtuali.map(cc => {
              return {
                cardType: 'large' as CardType,
                id: cc.codice, // TODO: cambiare query
                imgUrl: cc.previewFileUrl,
                title: cc.traduzioni[0]?.titolo,
                secondaryInfo: '', // TODO: cambiare query
                description: cc.traduzioni[0]?.descrizione,
                titleColor: theme?.contenuto?.containerContenutiCorrelati?.coloreTitoloItem ?? undefined,
                secondaryInfoColor: theme?.contenuto?.containerContenutiCorrelati?.coloreDataItem ?? undefined,
                descriptionColor: theme?.contenuto?.containerContenutiCorrelati?.coloreDescrizioneItem ?? undefined,
                contentType: 'TourVirtuale',
                code: cc.codice
              }
            }),
            ...contents.elementi3D.map(cc => {
              return {
                cardType: 'large' as CardType,
                id: cc.uniqueId, // TODO: cambiare query
                imgUrl: cc.previewFileUrl,
                title: cc.traduzioni[0]?.titolo,
                secondaryInfo: '', // TODO: cambiare query
                description: cc.traduzioni[0]?.descrizione,
                titleColor: theme?.contenuto?.containerContenutiCorrelati?.coloreTitoloItem ?? undefined,
                secondaryInfoColor: theme?.contenuto?.containerContenutiCorrelati?.coloreDataItem ?? undefined,
                descriptionColor: theme?.contenuto?.containerContenutiCorrelati?.coloreDescrizioneItem ?? undefined,
                contentType: 'Elemento3D',
                videoUrl: cc.fileUrl,
              }
            }),
            ...video360?.map(cc => {
              return {
                cardType: 'large' as CardType,
                id: cc.uniqueId, // TODO: cambiare query
                imgUrl: cc.previewFileUrl,
                title: cc.traduzioni[0]?.titolo,
                secondaryInfo: '', // TODO: cambiare query
                description: cc.traduzioni[0]?.descrizione,
                titleColor: theme?.contenuto?.containerContenutiCorrelati?.coloreTitoloItem ?? undefined,
                secondaryInfoColor: theme?.contenuto?.containerContenutiCorrelati?.coloreDataItem ?? undefined,
                descriptionColor: theme?.contenuto?.containerContenutiCorrelati?.coloreDescrizioneItem ?? undefined,
                contentType: 'Video360',
                videoUrl: cc.fileUrl,
              }
            }) ?? [],
          ]
          }
        />
      }

      {/* <TextSubtext className={classes.padded}
        textProps={{
          text_key: t('description'),
          text_size: 'large',
          text_weight: 'bold',
        }}
        subtextProps={{
          text_key: descr.length < DESCR_MAX_LENGTH || expandDesc ? descr : descr.slice(0, DESCR_MAX_LENGTH) + '...',
          text_line: 'normal',
        }}
        gap={16} />
      {
        descr.length >= DESCR_MAX_LENGTH && <ExpandButton className={classes.centered}
          expanded={expandDesc}
          setExpanded={setExpandDesc}
          expanded_text={t('show_less')}
          not_expanded_text={t('show_more')}
          padding={{ vertical: 8, horizontal: 16 }} />
      } */}
      <TextSubtextHTML className={classes.padded}
        textProps={{
          text_key: t('description'),
          text_size: 'large',
          text_weight: 'bold',
          color: theme?.contenuto?.coloreTitoloParagrafo ?? undefined
        }}
        gap={16}
        subTextHTML={descr.length < DESCR_MAX_LENGTH || expandDesc ? descr : descr.slice(0, DESCR_MAX_LENGTH) + '...'} /> {/* TODO: limitare la lunghezza della descrizione, sebbene sia contenuto HTML */}

      {
        descr.length >= DESCR_MAX_LENGTH && <ExpandButton className={classes.centered}
          expanded={expandDesc}
          setExpanded={setExpandDesc}
          expanded_text={t('show_less')}
          not_expanded_text={t('show_more')}
          padding={{ vertical: 8, horizontal: 16 }} />
      }

      {
        contents.traduzioni[0]?.modalitaDiAccesso && <TextSubtextHTML className={classes.padded}
        textProps={{
          text_key: t('access_mode'),
          text_size: 'large',
          text_weight: 'bold',
          color: theme?.contenuto?.coloreTitoloParagrafo ?? undefined
        }}
        // subtextProps={{
        //   text_key: contents.traduzioni[0].modalitaDiAccesso,
        //   text_line: 'normal',
        //   color: theme?.stile?.coloreFronte ?? undefined,
        // }}
        gap={16}
        subTextHTML={contents.traduzioni[0]?.modalitaDiAccesso}
      />
      }


      {
        contents.traduzioni[0]?.ulterioriInformazioni.length > 0 && <TextSubtextHTML className={classes.padded}
          textProps={{
            text_key: t('more_info'),
            text_size: 'large',
            text_weight: 'bold',
            color: theme?.contenuto?.coloreTitoloParagrafo ?? undefined
          }}
          gap={16}
          subTextHTML={contents.traduzioni[0]?.ulterioriInformazioni} />
      }





      {/* <div className={classes.column}>
        {
          contents.puntoDiInteresseGenitore && contents.puntoDiInteresseGenitore.uniqueId != contents.uniqueId &&
          <StyledDiv className={classes.event_info_container}
            backcolor={theme?.contenuto?.puntoDiInteresse?.sezionePOIGenitore?.coloreSfondo ?? undefined}>
            <DottyIcons.PuntiInteresse width={32} height={32} strokeWidth={1.5}
              stroke={theme?.contenuto?.puntoDiInteresse?.sezionePOIGenitore?.coloreFronte ?? undefined} />
            <TextSubtext className={classes.stretch}
              textProps={{
                text_key: t('part_of'),
                text_size: 'tiny',
                text_line: 'normal',
                color: theme?.contenuto?.puntoDiInteresse?.sezionePOIGenitore?.coloreFronte ?? undefined
              }}
              subtextProps={{
                text_key: contents?.puntoDiInteresseGenitore?.traduzioni[0]?.nome ?? undefined,
                text_size: 'tiny',
                text_weight: 'bold',
                text_line: 'normal',
                color: theme?.contenuto?.puntoDiInteresse?.sezionePOIGenitore?.coloreFronte ?? undefined
              }} />
            <IconTextButton
              textProps={{
                text_key: t('discover'),
                color: theme?.bottoneSecondario?.coloreFronte ?? undefined
              }}
              icon={
                <ArrowRight width={16} height={16} strokeWidth={1.5}
                  stroke={theme?.bottoneSecondario?.coloreFronte ?? undefined} />
              }
              backColor={theme?.bottoneSecondario?.coloreSfondo ?? undefined}
              bordercolor={theme?.bottoneSecondario?.coloreBordo ?? undefined}
              padding={{ vertical: 8, horizontal: 16 }}
              buttonMode="outline_borderless"
              invertContents
              onClick={() => go('/details/?id=' + contents.puntoDiInteresseGenitore?.uniqueId + '&type=2')} 
              /> 
          </StyledDiv>
        }
        {
          contents.puntiDiInteresse && contents.puntiDiInteresse.length > 0 &&
          <Carousel
            titleBar={{
              title: {
                text_key: t('what_you_will_find'),
                text_size: 'large',
                text_weight: 'bold',
                color: theme?.contenuto?.puntoDiInteresse?.containerPOICorrelati?.coloreTitoloTipologia ?? undefined
              },
            }}
            background={theme?.contenuto?.puntoDiInteresse?.containerPOICorrelati?.backColor ?? undefined}
            slidesPerView='auto'
            slides={
              contents.puntiDiInteresse.filter(a => a.uniqueId != contents.uniqueId).map(a => {
                return {
                  cardType: 'medium',
                  id: a.uniqueId,
                  imgUrl: a.immagineUrl,
                  title: a.traduzioni[0].nome,
                  eventText: a.__typename,
                  titleColor: theme?.contenuto?.puntoDiInteresse?.containerPOICorrelati?.coloreTitoloItem ?? undefined,
                  secondaryInfoColor: theme?.contenuto?.puntoDiInteresse?.containerPOICorrelati?.coloreDescrizioneItem ?? undefined,
                  descriptionColor: theme?.contenuto?.puntoDiInteresse?.containerPOICorrelati?.coloreDescrizioneItem ?? undefined,
                  contentType: a.__typename
                }
              })
            } />
        }

      </div> */}

      {
        (contents.puntoDiInteresseGenitore || contents.puntiDiInteresse) && <ParentChild POIContent={contents} />
      }


      {
        contents.contenutiCorrelati.length > 0 && <Carousel
          titleBar={{
            title: {
              text_key: t('suggestions'),
              text_size: 'large',
              text_weight: 'bold',
              color: theme?.contenuto?.containerContenutiCorrelati?.coloreTitoloTipologia ?? undefined
            },
          }}
          background={theme?.contenuto?.containerContenutiCorrelati?.backColor ?? undefined}
          slidesPerView='auto'
          slides={
            contents.contenutiCorrelati.map(cc => {
              return {
                cardType: 'medium',
                id: cc.uniqueId, // TODO: cambiare query
                imgUrl: cc.immagineUrl,
                title: cc.traduzioni[0]?.titolo,
                secondaryInfo: '----', // TODO: cambiare query
                description: cc.traduzioni[0]?.descrizioneBreve,
                eventText: cc.tipologiaContenutoApp?.traduzioni[0].nome ?? '',
                titleColor: theme?.contenuto?.containerContenutiCorrelati?.coloreTitoloItem ?? undefined,
                secondaryInfoColor: theme?.contenuto?.containerContenutiCorrelati?.coloreDataItem ?? undefined,
                descriptionColor: theme?.contenuto?.containerContenutiCorrelati?.coloreDescrizioneItem ?? undefined,
                contentType: cc.tipologiaContenutoApp?.nomeEntita ?? ''
              }
            })
          } />
      }
      {/* 
      <div className={classes.virtual_tour_button_container}>
        <IconTextButton
          textProps={{
            text_key: t('virtual_tour'),
          }}
          backColor={theme?.bottoneSecondario?.coloreSfondo ?? undefined}
          contentsColor={theme?.bottoneSecondario?.coloreFronte ?? undefined}
          bordercolor={theme?.bottoneSecondario?.coloreBordo ?? undefined}
          padding={{ vertical: 16 }}
          expanded
          buttonMode="outline" />
      </div> */}


      <Separator />

    </div>
  );
};

export default POIContent;