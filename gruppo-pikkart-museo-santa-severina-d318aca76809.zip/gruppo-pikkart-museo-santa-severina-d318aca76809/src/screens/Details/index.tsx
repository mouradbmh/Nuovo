import DetailsScreen from "@/screens/Details/DetailsScreen";
import DetailsContent from "@/screens/Details/DetailsContent";
import ItineraryContent, { ItineraryContentProps } from "@/screens/Details/ItineraryContent";

export default DetailsScreen;
export { DetailsContent, ItineraryContent };
export type { ItineraryContentProps }
