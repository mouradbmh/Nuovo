import { DetailsContentsType } from "@/components/DetailsProvider/DetailsProvider";
import { useDetails } from "@/hooks/useDetails";
import { ItineraryContent } from "@/screens/Details";
import { ItineraryDetails, EventDetails, POIDetails, NewsDetails, ExperienceDetails, CADetails, ICDetails, TPDetails, ArElementDetails } from "@/components/DetailsProvider";
import EventContent from "./EventContent";  // TODO: sistemare imports
import POIContent from "./POIContent";
import NewsContent from "./NewsContent";
import ExperienceContent from "./ExperienceContent";
import CAContent from "./CAContent";
import ICContent from "./ICContent";
import TPContent from "./TPContent";
import ArPoiContent from './ArElementContent'
// import classes from "@/screens/Details/DetailsContent.module.css";
// import * as Icon from "react-feather";
import { useMemo } from "react";
import Loader from "@/components/Loader";
import ArElement from "@/components/ArElement";

const DetailsContent = () => {
  const { type, data, loading } = useDetails();

  const contentFromType = (type: DetailsContentsType) => {
    switch (type) {
      case DetailsContentsType.ITINERARY:
        return <ItineraryContent loading={loading} contents={data?.itinerariQuery?.itinerari?.lista?.[0] as ItineraryDetails} />

      case DetailsContentsType.EVENT:
        return <EventContent loading={loading} contents={data?.eventiQuery?.eventi?.lista?.[0] as EventDetails} />

      case DetailsContentsType.POINT_OF_INTEREST:
        return <POIContent loading={loading} contents={data?.puntiDiInteresseQuery?.puntiDiInteresse?.lista?.[0] as POIDetails} />

      case DetailsContentsType.NEWS:
        return <NewsContent loading={loading} contents={data?.notizieQuery?.notizie?.lista?.[0] as NewsDetails} />

      case DetailsContentsType.EXPERIENCE:
        return <ExperienceContent loading={loading} contents={data?.esperienzeQuery?.esperienze?.lista?.[0] as ExperienceDetails} />

      case DetailsContentsType.COMMERCIAL_ACTIVITY:
        return <CAContent loading={loading} contents={data?.attivitaCommercialiQuery?.attivitaCommerciali?.lista?.[0] as CADetails} />

      case DetailsContentsType.INFORMATIVE_CONTENT:
        return <ICContent loading={loading} contents={data?.contenutiInformativiAppQuery?.contenutiInformativiApp?.lista?.[0] as ICDetails} />

      case DetailsContentsType.TYPICAL_PRODUCT:
        return <TPContent loading={loading} contents={data?.prodottiTipiciQuery?.prodottiTipici?.lista?.[0] as TPDetails} />

      case DetailsContentsType.AR_ELEMENT:
          return <ArPoiContent loading={loading} contents={data?.esperienzeArQuery?.esperienzeAR?.lista?.[0] as ArElementDetails}/>

      case DetailsContentsType.IMMERSIVE_CONTENT:
          return <ArElement />
    }
  };

  const status = useMemo(() => {
    if (!data || loading) {
      return (
        <Loader />
      )
    } else {
      return (<>
        {contentFromType(type)}
      </>)
    }
  }, [data, loading, type])

  return status;

};

export default DetailsContent;