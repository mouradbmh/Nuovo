import NavigationTopBar from "@/components/NavigationTopBar";
import { ChevronLeft } from "react-feather";
import classes from "@/screens/Profile/ChangePassword/changePassword.module.css";
import InputComponent from "@/components/InputComponent";
import Spacer from "@/components/Spacer";
import IconTextButton from "@/components/IconTextButton";
import { useAppContext } from "@/hooks/useAppContext";
import { useState } from "react";
import { t } from "i18next";
import { useAuth } from "@/hooks/useAuth";
import TextComponent from "@/components/TextComponent";
import Loader from "@/components/Loader";

type Props = {
    onApply: (verCode: string) => Promise<void>
    back: () => void
}

const ValidateCode = ({ onApply, back }: Props) => {
    const { theme } = useAppContext();
    const [verCode, setVerCode] = useState('')
    const { requestReset, pwrErr, pwrLoading, pwrMsg } = useAuth()

    return (
        <>
            {pwrLoading &&

                <div style={{
                    position: 'absolute',
                    height: '100vh',
                    width: '100%',
                    backgroundColor: 'rgba(63,63,70,0.7)',
                    zIndex: 10
                }}>
                    <Loader />
                </div>
            }

            <NavigationTopBar
                title_key="Cambia password"
                button_left={<ChevronLeft onClick={back} />}
            />
            
            <div className={classes.container}>
            {pwrErr && <TextComponent text_key={pwrErr} color="red"/>}
            {pwrMsg && <TextComponent text_key={pwrMsg} color="green"/>}
                <InputComponent
                    inputType="text"
                    inputName="verification-code"
                    inputProps={{
                        text_key: verCode,
                        text_size: 'regular',
                    }}
                    placeholderProps={{
                        text_key: t('Code'),
                        text_size: 'tiny',
                        text_weight: 'regular',
                    }}
                    showViewPasswordButton
                    setOnChange={setVerCode}
                />
            </div>

            <Spacer />

            <div className={classes.button}>
                <IconTextButton
                    expanded
                    buttonMode="normal"
                    textProps={{
                        text_key: t('request_code'),
                        text_size: 'regular',
                        text_weight: 'medium',
                    }}
                    padding={{
                        all: 16
                    }}
                    backColor={theme?.bottonePrimario?.coloreSfondo || undefined}
                    contentsColor={theme?.bottonePrimario?.coloreFronte || undefined}
                    onClick={() => void requestReset()}
                />
            </div>

            <div className={classes.button}>
                <IconTextButton
                    expanded
                    buttonMode="normal"
                    textProps={{
                        text_key: t('Verify_and_send'),
                        text_size: 'regular',
                        text_weight: 'medium',
                    }}
                    padding={{
                        all: 16
                    }}
                    backColor={theme?.bottonePrimario?.coloreSfondo || undefined}
                    contentsColor={theme?.bottonePrimario?.coloreFronte || undefined}
                    onClick={() => onApply(verCode)}
                />
            </div>

        </>
    );
};

export default ValidateCode;
