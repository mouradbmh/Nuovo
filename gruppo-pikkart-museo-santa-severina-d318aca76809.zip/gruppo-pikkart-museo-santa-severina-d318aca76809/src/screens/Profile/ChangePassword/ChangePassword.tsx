import NavigationTopBar from "@/components/NavigationTopBar";
import { useProfileContent } from "@/hooks/useProfileContent";
import { ChevronLeft } from "react-feather";
import classes from "@/screens/Profile/ChangePassword/changePassword.module.css";
import InputComponent from "@/components/InputComponent";
import Spacer from "@/components/Spacer";
import IconTextButton from "@/components/IconTextButton";
import { useAppContext } from "@/hooks/useAppContext";
import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { t } from "i18next";
import ValidateCode from "./ValidateCode";

export type ChangePwr = {
    email: string;
    password: string;
    code: string;
}

const ChangePassword = () => {
    const { setCurrentScreen } = useProfileContent();
    const { theme } = useAppContext();
    const {user} = useAuth()
    const [password, setPassword] = useState<string>("");
    const [newPassword, setNewPassword] = useState<string>("");
    const {resetPw} = useAuth()
    const [toValidate, setToValidate] = useState(false)

    const timeout = (delay: number) => {
        return new Promise(res => setTimeout(res, delay))
    }

    const onApply = async (verCode: string) => {
        if (verCode === "") {
            alert("Codice mancante");
            return;
        }

        const data: ChangePwr = {
            password: password,
            email: user?.email ?? '',
            code: verCode
        };
        console.log(data);
        const res = await resetPw(data)
        if (res) {
            await timeout(2000)
            setCurrentScreen("profile")
        }
    };

    const verifyPSW = () => {
        if (password === "" || newPassword === "" || newPassword !== password) {
            alert("Password non valida");
            return;
        }

        setToValidate(true)
    }

    if (toValidate) {
        return <ValidateCode onApply={onApply} back={() => setToValidate(false)}/>
    }

    return (
        <>
            <NavigationTopBar
                title_key="Cambia password"
                button_left={<ChevronLeft onClick={() => setCurrentScreen("profile")} />}
            />
            <div className={classes.container}>
                <InputComponent
                    inputType="password"
                    inputName="old-password"
                    inputProps={{
                        text_key: password,
                        text_size: 'regular',
                    }}
                    placeholderProps={{
                        text_key: t('New_password'),
                        text_size: 'tiny',
                        text_weight: 'regular',
                    }}
                    showViewPasswordButton
                    setOnChange={setPassword}
                />
                <InputComponent
                    inputType="password"
                    inputName="new-password"
                    inputProps={{
                        text_key: newPassword,
                        text_size: 'regular',
                    }}
                    placeholderProps={{
                        text_key: t('Verify_new_password'),
                        text_size: 'tiny',
                        text_weight: 'regular',
                    }}
                    showViewPasswordButton
                    setOnChange={setNewPassword}
                />
            </div>
            <Spacer />
            <div className={classes.button}>
                <IconTextButton
                    expanded
                    buttonMode="normal"
                    textProps={{
                        text_key: 'Applica',
                        text_size: 'regular',
                        text_weight: 'medium',
                    }}
                    padding={{
                        all: 16
                    }}
                    backColor={theme?.bottonePrimario?.coloreSfondo || undefined}
                    contentsColor={theme?.bottonePrimario?.coloreFronte || undefined}
                    onClick={verifyPSW}
                />
            </div>
        </>
    );
};

export default ChangePassword;
