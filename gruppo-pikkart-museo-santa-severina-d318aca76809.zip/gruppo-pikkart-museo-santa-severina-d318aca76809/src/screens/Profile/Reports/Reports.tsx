import NavigationTopBar from "@/components/NavigationTopBar";
import ScreenLayout from "@/components/ScreenLayout";
import { useProfileContent } from "@/hooks/useProfileContent";
import { ChevronLeft } from "react-feather";
import classes from "@/screens/Profile/Reports/reports.module.css";
import IconTextButton from "@/components/IconTextButton";
import { useAppContext } from "@/hooks/useAppContext";
import TextSubtext from "@/components/TextSubtext";
import ReportActivity from "@/components/Reports/ReportActivity";
import { useReports } from "@/hooks/useReports";
import CreateReport from "@/screens/Profile/Reports/CreateReport";

const Reports = () => {
    const { currentReportScreen } = useReports();

    return (
        <ScreenLayout currentScreen="profile" showBottomBar={false}>
            {currentReportScreen === "overview" ? <Overview /> : <CreateReport />}
        </ScreenLayout>
    );
};

const Overview = () => {
    const { setCurrentScreen } = useProfileContent();
    const { theme } = useAppContext();
    const { activities, setCurrentReportScreen } = useReports();

    return (
        <div className={classes.container}>
            <NavigationTopBar
                title_key="Segnalazioni"
                button_left={<ChevronLeft onClick={() => setCurrentScreen("profile")} />}
            />
            <div className={classes.button_container}>
                <IconTextButton
                    textProps={{
                        text_key: "Fai una segnalazione",
                        text_size: "regular",
                        text_weight: "medium",
                        color: theme?.bottonePrimario?.coloreFronte || undefined
                    }}
                    padding={{
                        horizontal: 84,
                        vertical: 16
                    }}
                    buttonMode="normal"
                    backColor={theme?.bottonePrimario?.coloreSfondo || undefined}
                    onClick={() => setCurrentReportScreen("create")}
                />
            </div>
            <TextSubtext
                textProps={{
                    text_key: "Attività",
                    text_size: "title3",
                    text_weight: "bold",
                    color: theme?.stile?.coloreFronte || undefined
                }}
                className={classes.activities_title}
            />
            <div className={classes.activities_container}>
                {activities.map((activity, index) => (
                    <ReportActivity key={index} activity={activity} />
                ))} 
            </div>
        </div>
    );
};

export default Reports;
