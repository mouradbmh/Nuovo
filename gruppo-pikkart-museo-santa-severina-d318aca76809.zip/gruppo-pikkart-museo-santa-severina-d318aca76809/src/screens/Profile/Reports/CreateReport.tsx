import NavigationTopBar from "@/components/NavigationTopBar";
import { useReports } from "@/hooks/useReports";
import classes from "@/screens/Profile/Reports/createReport.module.css";
import { useState } from "react";
import { ChevronLeft } from "react-feather";
import ReportTermsAndConditions from "@/screens/Profile/Reports/CreateReportSteps/ReportTermsAndConditions";
import ReportData from "@/screens/Profile/Reports/CreateReportSteps/ReportData";
import ReportRecap from "@/screens/Profile/Reports/CreateReportSteps/ReportRecap";
import ReportSuccess from "@/screens/Profile/Reports/CreateReportSteps/ReportSuccess";
import { useProfileContent } from "@/hooks/useProfileContent";

export type StepProps = {
    nextStep?: () => void;
    prevStep?: () => void;
    currentStep: number;
    maxStep: number;
};

const CreateReport = () => {
    const LAST_STEP = 3;
    const { setCurrentReportScreen, clearActivity, activities } = useReports();
    const [currentStep, setCurrentStep] = useState(0);
    const {setCurrentScreen} = useProfileContent()

    const handleNextStep = () => {
        if (currentStep < steps.length - 1) {
            setCurrentStep(currentStep + 1);
        } else {
            clearActivity()
            setCurrentReportScreen("overview");
        }
    };

    const handlePreviousStep = () => {
        if (currentStep > 0) {
            setCurrentStep(currentStep - 1);
        }
    };

    const props = {
        nextStep: handleNextStep,
        prevStep: handlePreviousStep,
        currentStep: currentStep + 1,
        maxStep: LAST_STEP,
    };

    const steps: JSX.Element[] = [
        <ReportTermsAndConditions {...props} />,
        <ReportData {...props} />,
        <ReportRecap {...props} />,
        <ReportSuccess {...props}/>,
    ];

    const handleGoBack = () => {
        if (currentStep === 0 && activities.length === 0) {
            clearActivity()
            setCurrentScreen('profile')
        }
        else if (currentStep === 0 || currentStep === steps.length - 1) {
            clearActivity()
            setCurrentReportScreen("overview");
        } else {
            handlePreviousStep();
        }
    };

    return (
        <div className={classes.container}>
            <NavigationTopBar
                title_key="Segnala un disservizio"
                button_left={<ChevronLeft onClick={handleGoBack} />}
            />
            {steps[currentStep]}
        </div>
    );
};

export default CreateReport;