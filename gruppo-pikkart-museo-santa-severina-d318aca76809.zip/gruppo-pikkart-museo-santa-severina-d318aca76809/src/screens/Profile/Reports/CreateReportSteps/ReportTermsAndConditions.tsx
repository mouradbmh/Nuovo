import TextSubtext from "@/components/TextSubtext";
import { useAppContext } from "@/hooks/useAppContext";
import classes from "@/screens/Profile/Reports/CreateReportSteps/createReportSteps.module.css";
import { StepProps } from "@/screens/Profile/Reports/CreateReport";
import Checkbox from "@/components/Checkbox/Checkbox";
import { useState } from "react";
import Spacer from "@/components/Spacer";
import IconTextButton from "@/components/IconTextButton";
import { t } from "i18next";
import TextComponent from "@/components/TextComponent";

const ReportTermsAndConditions = ({
    nextStep,
    currentStep,
    maxStep,
}: StepProps) => {
    const { theme } = useAppContext();
    const { config } = useAppContext()
    const [accepted, setAccepted] = useState<boolean>(false);
    const buttonBackgroundColor = accepted ? theme?.bottonePrimario?.coloreSfondo : theme?.bottoneDisabilitato?.coloreSfondo;
    const buttonTextColor = accepted ? theme?.bottonePrimario?.coloreFronte : theme?.bottoneDisabilitato?.coloreFronte;

    return (
        <div className={classes.step_container}>
            <div className={classes.title}>
                <TextSubtext
                    textProps={{
                        text_key: t("auth_and_conditions"),
                        text_size: "title4",
                        text_weight: "bold",
                        color: theme?.bottonePrimario?.coloreSfondo || undefined,
                    }}
                />
                <TextSubtext
                    textProps={{
                        text_key: currentStep.toString() + " / " + maxStep.toString(),
                        text_size: "regular",
                        text_weight: "regular",
                        color: theme?.stile?.coloreFronte || undefined,
                    }}
                />
            </div>
            <div className={classes.terms_container}>
                <TextSubtext
                    textProps={{
                        text_key: t('report_terms', { comune: config?.nome ?? 'N/A' }),   //Sarebbe meglio mi venisse ritornato anche un nuovo campo tipo nome comune nelle configurazioni
                        text_size: "small",
                        text_weight: "regular",
                        color: theme?.stile?.coloreFronte || undefined,
                    }}
                />
                <div style={{
                    display: "inline-flex",
                    marginTop: "2vh"
                }}>
                    <TextComponent
                        text_key={t("privacy_info1")}
                        text_size="small"
                        text_weight="regular"
                        color={theme?.stile?.coloreFronte || undefined}
                    />
                    <TextComponent
                        text_key={t("privacy_info2")}
                        className={classes.privacy_link}
                        text_size="small"
                        text_weight="regular"
                        color={theme?.bottonePrimario?.coloreSfondo || undefined}
                        onClick={() => window.open(config?.urlPrivacyPolicy)}
                    />
                </div>
            </div>
            <div className={classes.accept_container}>
                <div className={classes.accept_check}>
                    <Checkbox
                        size={12}
                        checked={accepted}
                        onChange={() => setAccepted(!accepted)}
                        borderColor={theme?.stile?.coloreFronte || undefined}
                    />
                </div>
                <TextSubtext
                    textProps={{
                        text_key: t("read_and_confirm"),
                        text_size: "small",
                        text_weight: "bold",
                        color: theme?.stile?.coloreFronte || undefined,
                        className: classes.accept_text,
                    }}
                />
            </div>
            <Spacer />
            <IconTextButton
                textProps={{
                    text_key: t("go_next"),
                    text_size: "regular",
                    text_weight: "medium",
                    color: buttonTextColor ?? undefined,
                }}
                padding={{
                    vertical: 16,
                }}
                expanded
                buttonMode="normal"
                backColor={buttonBackgroundColor ?? undefined}
                onClick={() => nextStep && nextStep()}
                disabled={!accepted}
                className={classes.next_button}
            />
        </div>
    );
};

export default ReportTermsAndConditions;
