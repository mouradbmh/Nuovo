import classes from "@/screens/Profile/Reports/CreateReportSteps/createReportSteps.module.css";
import { StepProps } from "@/screens/Profile/Reports/CreateReport";
import TextSubtext from "@/components/TextSubtext";
import IconTextButton from "@/components/IconTextButton";
import Spacer from "@/components/Spacer";
import { useAppContext } from "@/hooks/useAppContext";
import { CheckCircle, Download } from "react-feather";
import { useReports } from "@/hooks/useReports";
import { useCallback } from "react";
import { useAuth } from "@/hooks/useAuth";
import TextComponent from "@/components/TextComponent";
import { t } from "i18next";

const ReportSuccess = ({
    nextStep,
    // prevStep,
    // currentStep,
    // maxStep,
}: StepProps) => {
    const { theme } = useAppContext();
    const { handleDownloadReceipt, startingActivity } = useReports()
    const { user } = useAuth()

    const downloadRecipt = useCallback(() => {

        console.log(startingActivity)
        void handleDownloadReceipt(startingActivity!)
    }, [handleDownloadReceipt, startingActivity])

    return (
        <div className={classes.step_container}>
            <div className={classes.report_success_title}>
                <CheckCircle
                    color={theme?.bottonePrimario?.coloreSfondo || undefined}
                    size={24}
                />
                <TextSubtext
                    textProps={{
                        text_key: t("report_sent"),
                        text_size: "title4",
                        text_weight: "bold",
                        color: theme?.bottonePrimario?.coloreSfondo || undefined,
                    }}
                />
            </div>
            <div className={classes.report_success_container}>
                {/* <TextSubtext
                    textProps={{
                        text_key: "Grazie, abbiamo ricevuto la tua ",
                        text_size: "small",
                        text_weight: "regular",
                        color: theme?.stile?.coloreFronte || undefined,
                    }}
                    subtextProps={{
                        text_key: "segnalazione " + (startingActivity?.codice ?? '') + ".",
                        text_size: "small",
                        text_weight: "bold",
                        color: theme?.stile?.coloreFronte || undefined,
                    }}
                    className={classes.inline_text}
                /> */}
                <TextComponent
                    text_key={t("thanks_seg")}
                    text_size="small"
                    text_weight="regular"
                    color={theme?.stile?.coloreFronte || undefined}
                />
                <div>
                    <TextComponent
                        text_key={t("assigned_id1")}
                        text_size="small"
                        text_weight="regular"
                        color={theme?.stile?.coloreFronte || undefined}
                    />
                    <TextComponent
                        text_key={(startingActivity?.codice ?? '')}
                        text_size="small"
                        text_weight="bold"
                        color={theme?.stile?.coloreFronte || undefined}
                    />
                </div>
                <div className={classes.inline_text}>
                    <TextComponent
                        text_key={t("will_be_visible1")}
                        text_size="small"
                        text_weight="regular"
                        color={theme?.stile?.coloreFronte || undefined}
                    />
                    <TextComponent
                        text_key={t("will_be_visible2")}
                        text_size="small"
                        text_weight="bold"
                        color={theme?.bottonePrimario?.coloreSfondo || undefined}
                    />
                    <TextComponent
                        text_key={t("will_be_visible3")}
                        text_size="small"
                        text_weight="regular"
                        color={theme?.stile?.coloreFronte || undefined}
                    />
                </div>
                {/* <TextSubtext
                    textProps={{
                        text_key: "Sarà visibile sulla ",
                        text_size: "small",
                        text_weight: "regular",
                        color: theme?.stile?.coloreFronte || undefined,
                    }}
                    subtextProps={{
                        text_key: "lista di tutte le segnalazioni",
                        text_size: "small",
                        text_weight: "regular",
                        color: theme?.bottonePrimario?.coloreSfondo || undefined,
                        className: classes.privacy_link,
                        onClick: () => console.log("privacy"),
                    }}
                    className={classes.inline_text}
                />
                <TextSubtext
                    textProps={{
                        text_key: " una volta presa in carico dall'ammistrazione.",
                        text_size: "small",
                        text_weight: "regular",
                        color: theme?.stile?.coloreFronte || undefined,
                    }}
                /> */}
                {/* <TextSubtext
                    textProps={{
                        text_key: "Abbiamo inviato il riepilogo all'email ",
                        text_size: "small",
                        text_weight: "regular",
                        color: theme?.stile?.coloreFronte || undefined,
                    }}
                    subtextProps={{
                        text_key: user?.email ?? '',
                        text_size: "small",
                        text_weight: "bold",
                        color: theme?.stile?.coloreFronte || undefined,
                    }}
                    className={classes.inline_text}
                /> */}
                <div>
                    <TextComponent
                        text_key={t("recap_sent1")}
                        text_size="small"
                        text_weight="regular"
                    />
                    <TextComponent
                        text_key={user?.email ?? ''}
                        text_size="small"
                        text_weight="bold"
                    />
                </div>
                <IconTextButton
                    icon={<Download size={23} color={theme?.bottonePrimario?.coloreBordo || undefined} strokeWidth={1.5} />}
                    textProps={{
                        text_key: t("download_receipt"),
                        text_size: "small",
                        text_weight: "bold",
                        color: theme?.bottonePrimario?.coloreBordo || undefined,
                    }}
                    expanded
                    buttonMode="outline"
                    contentsColor={theme?.bottonePrimario?.coloreFronte || undefined}
                    className={classes.download_button}
                    padding={{
                        vertical: 10,
                    }}
                    onClick={downloadRecipt}
                />
            </div>
            <Spacer />
            <IconTextButton
                textProps={{
                    text_key: t("back_to_reports"),
                    text_size: "regular",
                    text_weight: "medium",
                    color: theme?.bottonePrimario?.coloreFronte ?? undefined,
                }}
                padding={{
                    vertical: 16,
                }}
                expanded
                buttonMode="normal"
                backColor={theme?.bottonePrimario?.coloreSfondo ?? undefined}
                onClick={() => nextStep && nextStep()}
                className={classes.back_button}
            />
        </div>
    );
};

export default ReportSuccess;
