import Loader from "@/components/Loader";
import { AuthorRecap, BottomButtonsBar, RecapSection } from "@/components/Reports/CreateReport";
import Spacer from "@/components/Spacer";
import TextComponent from "@/components/TextComponent";
import TextSubtext from "@/components/TextSubtext";
import { useAppContext } from "@/hooks/useAppContext";
import { useReports } from "@/hooks/useReports";
import { StepProps } from "@/screens/Profile/Reports/CreateReport";
import classes from "@/screens/Profile/Reports/CreateReportSteps/createReportSteps.module.css";
import { t } from "i18next";
import { useCallback, useState } from "react";
import { AlertTriangle } from "react-feather";
import { styled } from "styled-components";

const StyledWarning = styled.div<{ color: string }>`
    border-left: 1px solid ${(props) => props.color};
`;

const ReportRecap = ({
    nextStep,
    prevStep,
    currentStep,
    maxStep,
}: StepProps) => {
    const { theme } = useAppContext();
    const { createReport, description, title, location, typeName, startingActivity, imagesList, handleConfirmSendReport, editLoading, createLoading, setConfirmLoading, confirmLoading } = useReports()
    const [saveError, setSaveError] = useState(false)

    const handleNextStep = useCallback(() => {
        createReport().then(res => {
            if (res.ok) {
                handleConfirmSendReport(res.uniqueId!).then(res => {
                    if (typeof res !== 'undefined' && nextStep) {
                        setConfirmLoading(false)
                        setSaveError(false);
                        nextStep()
                    }
                }).catch(err => {
                    setConfirmLoading(false)
                    console.error(err)
                })
            }
            else {
                setConfirmLoading(false)
                setSaveError(true);
            }
        })
            .catch((err) => {
                setConfirmLoading(false)
                setSaveError(true);
                console.error(err)
            })


    }, [createReport, handleConfirmSendReport, nextStep, setConfirmLoading])

    return (
        <>
            {(editLoading || createLoading || confirmLoading) && (
                <div style={{
                    position: 'absolute',
                    height: '100%',
                    width: '100%',
                    backgroundColor: 'rgba(63,63,70,0.7)',
                    zIndex: 10
                }}>
                    <Loader />
                </div>
            )}
            <div className={classes.step_container}>
                <div className={classes.title}>
                    <TextSubtext
                        textProps={{
                            text_key: t("summary"),
                            text_size: "title4",
                            text_weight: "bold",
                            color: theme?.bottonePrimario?.coloreSfondo || undefined,
                        }}
                    />
                    <TextSubtext
                        textProps={{
                            text_key: currentStep.toString() + " / " + maxStep.toString(),
                            text_size: "regular",
                            text_weight: "regular",
                            color: theme?.stile?.coloreFronte || undefined,
                        }}
                    />
                </div>
                <Warning />
                <div className={classes.recap_title_container}>
                    <TextSubtext
                        textProps={{
                            text_key: t("disservice"),
                            text_size: "title3",
                            text_weight: "bold",
                            color: theme?.stile?.coloreFronte || undefined,
                        }}
                    />
                    <TextSubtext
                        textProps={{
                            text_key: t("edit"),
                            text_size: "small",
                            text_weight: "regular",
                            color: theme?.bottonePrimario?.coloreSfondo || undefined,
                            onClick: () => {
                                if (prevStep) {
                                    prevStep()
                                }
                            }
                        }}
                    />
                </div>
                <div className={classes.recap_sections_container}>
                    <RecapSection
                        label={t("address")}
                        description={location}
                    />
                    <RecapSection
                        label={t("disservice_type")}
                        description={typeName === '' ? (startingActivity?.tipologia?.nome ?? '') : typeName}
                    />
                    <RecapSection
                        label={t("title")}
                        description={title}
                    />
                    <RecapSection
                        label={t("report_details")}
                        description={description}
                    />
                    <RecapSection
                        label={t("img")}
                        description=""
                        showBorder={false}
                        imageUrls={imagesList?.map(i => URL.createObjectURL(i))}
                    />
                    <TextSubtext
                        textProps={{
                            text_key: t("report_author"),
                            text_size: "title3",
                            text_weight: "bold",
                            color: theme?.stile?.coloreFronte || undefined,
                        }}
                        className={classes.author_title}
                    />
                    <AuthorRecap />
                </div>
                {saveError && <TextComponent 
                    text_key={t("error_saving")}
                    color="red"
                />}
                <Spacer />
                {prevStep && nextStep && (<BottomButtonsBar onSave={() => { }} onBack={prevStep} onNext={handleNextStep} />)}
            </div>
        </>
    );
};

const Warning = () => {
    const { theme } = useAppContext();

    return (
        <StyledWarning className={classes.warning_container} color={theme?.bottonePrimario?.coloreSfondo ?? "var(--emerald-700)"}>
            <div className={classes.warning_message_title}>
                <AlertTriangle strokeWidth={2} color={theme?.bottonePrimario?.coloreSfondo || undefined} size={15} />
                <TextSubtext
                    textProps={{
                        text_key: t("WARNING"),
                        text_size: "tiny",
                        text_weight: "regular",
                        color: theme?.bottonePrimario?.coloreSfondo || undefined,
                    }}
                />
            </div>
            <TextSubtext
                textProps={{
                    text_key: t("declaration"),
                    text_size: "tiny",
                    text_weight: "regular",
                    color: theme?.stile?.coloreFronte || undefined,
                }}
            />
        </StyledWarning>
    );
}

export default ReportRecap;
