import IconTextButton from "@/components/IconTextButton";
import InputComponent from "@/components/InputComponent";
import InputSelect from "@/components/InputSelect";
import { AuthorRecap, BottomButtonsBar, RecapSection } from "@/components/Reports/CreateReport";
import Spacer from "@/components/Spacer";
import TextSubtext from "@/components/TextSubtext";
import { useAppContext } from "@/hooks/useAppContext";
import { useReports } from "@/hooks/useReports";
import { StepProps } from "@/screens/Profile/Reports/CreateReport";
import classes from "@/screens/Profile/Reports/CreateReportSteps/createReportSteps.module.css";
import { useCallback, useRef, useState } from "react";
import { ChevronDown, Navigation, Upload, XCircle } from "react-feather";
import { useAuth } from "@/hooks/useAuth";
import LazyImage from "@/components/LazyImage";
import Loader from "@/components/Loader";
import Autocomplete from "react-google-autocomplete";
import { useKey } from "@/hooks/useKeyContext";
import { t } from "i18next";
import { fromLatLng, setKey } from 'react-geocode'

type GeocodeResponse = {
    results: {
        formatted_address:string
        geometry: {
            location: {
                lat: number,
                lng: number
            }
        }
        types: string[]
    }[]
    status: google.maps.GeocoderStatus
}

const ReportData = ({
    nextStep,
    prevStep,
    currentStep,
    maxStep,
}: StepProps) => {
    const { theme } = useAppContext();
    const { location, description, title, typeId, createReport, editLoading, createLoading, latitude, longitude } = useReports()
    const [errorFieldCompile, setErrorFieldCompile] = useState(false);
    const [errorFieldSave, setErrorFieldSave] = useState(false);

    const handleNextStep = useCallback(() => {
        if (location !== '' && location !== undefined && description !== '' && title !== '' && typeId !== '' && latitude !== undefined && longitude !== undefined && nextStep) {
            // createReport().then((res) => {
            //     setErrorFieldCompile(false)
            //     if (res.ok) {
            //         setErrorFieldSave(false);
            //         nextStep()
            //     } else {
            //         setErrorFieldSave(true);
            //     }
            // }).catch((e) => {
            //     console.log(e)
            // })
            setErrorFieldSave(false);
            nextStep()
        } else {
            setErrorFieldCompile(true)
        }
    }, [location, description, title, typeId, latitude, longitude, nextStep])

    return (
        <>
            {(editLoading || createLoading) && (
                <div style={{
                    position: 'absolute',
                    height: '100%',
                    width: '100%',
                    backgroundColor: 'rgba(63,63,70,0.7)',
                    zIndex: 10
                }}>
                    <Loader />
                </div>
            )}
            <div className={classes.step_container}>
                <div className={classes.title}>
                    <TextSubtext
                        textProps={{
                            text_key: t("report_data"),
                            text_size: "title4",
                            text_weight: "bold",
                            color: theme?.bottonePrimario?.coloreSfondo || undefined,
                        }}
                    />
                    <TextSubtext
                        textProps={{
                            text_key: currentStep.toString() + " / " + maxStep.toString(),
                            text_size: "regular",
                            text_weight: "regular",
                            color: theme?.stile?.coloreFronte || undefined,
                        }}
                    />
                </div>
                <div className={classes.subtitle}>
                    <TextSubtext
                        textProps={{
                            text_key: t("report_required_fields"),
                            text_size: "tiny",
                            text_weight: "regular",
                            color: theme?.stile?.coloreFronte || undefined,
                        }}
                    />
                </div>
                <div className={classes.form_container}>
                    <Location />
                    <Details />
                    <Author />
                </div>
                <Spacer />
                {errorFieldCompile && <div className={classes.title}>
                    <TextSubtext
                        textProps={{
                            text_key: t("complete_to_proceed"),
                            text_size: "tiny",
                            text_weight: "regular",
                            color: "red",
                        }}
                    />
                </div>}
                {errorFieldSave && <div className={classes.title}>
                    <TextSubtext
                        textProps={{
                            text_key: t("report_save_error"),
                            text_size: "tiny",
                            text_weight: "regular",
                            color: "red",
                        }}
                    />
                </div>}
                {prevStep && nextStep && (<BottomButtonsBar onSave={() => { void createReport() }} onBack={prevStep} onNext={handleNextStep} />)}
            </div>
        </>
    );
};

const Location = () => {
    const { theme } = useAppContext();
    const { location, setLocation, setLatitude, setLongitude } = useReports();
    const { configs } = useKey()

    // setDefaults({
    //     key: configs!.GOOGLE_API_KEY,

    // })

    setKey(configs!.GOOGLE_API_KEY)

    const getUserCurrentPosition = () => {
        setLocation(t("Loading"));
        navigator.geolocation.getCurrentPosition((position) => {
            fromLatLng(position.coords.latitude, position.coords.longitude)
                .then((data: GeocodeResponse) => {
                    const res = data.results;
                    console.log(res)
                    if (data.status === google.maps.GeocoderStatus.OK) {
                        const streetAddress = res.find(el => el.types.find(el => el === 'street_address'))
                        if (streetAddress) {
                            setLocation(streetAddress.formatted_address)
                            setLatitude(streetAddress.geometry.location.lat)
                            setLongitude(streetAddress.geometry.location.lng)
                            return;
                        }
                        const route = res.find(el => el.types.find(el => el === 'route'))
                        if (route) {
                            setLocation(route.formatted_address)
                            setLatitude(route.geometry.location.lat)
                            setLongitude(route.geometry.location.lng)
                            return;
                        }
                        const locality = res.find(el => el.types.find(el => el === 'locality'))
                        if (locality) {
                            setLocation(locality.formatted_address)
                            setLatitude(locality.geometry.location.lat)
                            setLongitude(locality.geometry.location.lng)
                            return;
                        }
                        const country = res.find(el => el.types.find(el => el === 'country'))
                        if (country) {
                            setLocation(country.formatted_address)
                            setLatitude(country.geometry.location.lat)
                            setLongitude(country.geometry.location.lng)
                            return;
                        }
                        setLocation(t("gps_fail"))
                    }
                })
                .catch(err => console.log(err))
        })
    }

    return (
        <div className={classes.form_row}>
            <TextSubtext
                textProps={{
                    text_key: t("location"),
                    text_size: "title3",
                    text_weight: "bold",
                    color: theme?.stile?.coloreFronte || undefined,
                }}
            />
            <div className={classes.input_container}>
                {/* <InputComponent
                    inputType="text"
                    inputName="position"
                    placeholderProps={{
                        text_key: "Cerca un luogo*",
                        text_size: "regular",
                        text_weight: "regular",
                        color: "var(--zinc-300)"
                    }}
                    inputText_key={location}
                    inputProps={{
                        text_key: location === '' ? startingActivity?.indirizzo ?? '' : location,
                        text_size: "regular",
                        text_weight: "regular",
                        color: theme?.stile?.coloreFronte || undefined,
                    }}
                    setOnChange={setLocation}
                /> */}
                <Autocomplete
                    apiKey={configs!.GOOGLE_API_KEY}
                    onPlaceSelected={(place) => {
                        const lng = place.geometry?.location?.lng() as number;
                        const lat = place.geometry?.location?.lng() as number;
                        const address = place.formatted_address as string;

                        console.log(address, lat, lng)

                        setLocation(address)
                        setLatitude(lat)
                        setLongitude(lng)
                    }}
                    color={theme?.stile?.coloreFronte || undefined}
                    className={classes.location_input}
                    placeholder={t("search_location")}
                    defaultValue={location}
                    options={{
                        types: ['locality', 'route', 'street_address', 'street_number'],
                        componentRestrictions: { country: "it" }
                    }}
                    inputAutocompleteValue="off"
                    autoCorrect="off"
                    spellCheck={false}
                />
            </div>
            <div className={classes.use_position_container} onClick={getUserCurrentPosition}>
                <Navigation size={20} color={theme?.bottonePrimario?.coloreSfondo ?? undefined} strokeWidth={1.5} />
                <TextSubtext
                    textProps={{
                        text_key: t("use_gps"),
                        text_size: "small",
                        text_weight: "regular",
                        color: theme?.bottonePrimario?.coloreSfondo || undefined,
                    }}
                />
            </div>
        </div>
    );
};

const Details = () => {
    const { theme } = useAppContext();
    const { typologies, setDescription, setTitle, setTypeId, description, setTypeName, typeId, imagesList, setImagesList, title } = useReports();
    // const { useRestRequest } = useDataRequest();
    // const [uploadImage] = useRestRequest({
    //     path: "api/v1/immagini",
    //     headers: {
    //         'Content-Type': 'application/json',
    //         'Content-Language': i18n.language.split('-')[0]
    //     },
    //     method: "POST",
    // });
    const uploadImageRef = useRef<HTMLInputElement | null>(null);

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (!e.target.files) {
            return;
        }

        const images = [...e.target.files]
        setImagesList(images);
        // const data = new FormData();
        // images.forEach((image, index) => {
        //     data.append("file" + index.toString(), image);
        // });

        // uploadImage({ data });
    };

    const removeImage = (index: number) => {
        if (!imagesList) {
            return;
        }

        const images = [...imagesList];
        images.splice(index, 1);
        setImagesList(images);
    };

    return (
        <div className={classes.form_row}>
            <TextSubtext
                textProps={{
                    text_key: t("disservice"),
                    text_size: "title3",
                    text_weight: "bold",
                    color: theme?.stile?.coloreFronte || undefined,
                }}
            />
            <div className={classes.input_container}>
                <InputSelect
                    placeholder={t("select_disservice")}
                    value={typeId}
                    options={typologies.map((typology) => {
                        return {
                            value: typology.uniqueId,
                            label: typology.nome,
                        }
                    })}
                    onChange={(e: { value: string, label: string }) => { setTypeId(e.value); setTypeName(e.label) }}
                />
                <InputComponent
                    inputType="text"
                    inputName="title"
                    placeholderProps={{
                        text_key: t("title"),
                        text_size: "regular",
                        text_weight: "regular",
                        color: "var(--zinc-300)"
                    }}
                    inputProps={{
                        text_key: title,
                        text_size: "regular",
                        text_weight: "regular",
                        color: theme?.stile?.coloreFronte || undefined,
                    }}
                    setOnChange={setTitle}
                />
                <div className={classes.input_with_disclaimer_container}>
                    <div className={classes.textarea_container}>
                        <TextSubtext
                            textProps={{
                                text_key: t("report_details"),
                                text_size: "regular",
                                text_weight: "regular",
                                color: theme?.stile?.coloreFronte || undefined,
                            }}
                        />
                        <textarea
                            className={classes.text_area_input}
                            onChange={(e) => { setDescription(e.target.value) }}
                            value={description}
                        />
                    </div>
                    <TextSubtext
                        textProps={{
                            text_key: t("max_200ch"),
                            text_size: "tiny",
                            text_weight: "regular",
                            color: "var(--ink-lighter)",
                            className: classes.disclaimer
                        }}
                    />
                </div>
                <div className={classes.input_with_disclaimer_container}>
                    <div className={classes.textarea_container}>
                        <TextSubtext
                            textProps={{
                                text_key: t("img"),
                                text_size: "regular",
                                text_weight: "regular",
                                color: theme?.stile?.coloreFronte || undefined,
                            }}
                        />
                        {imagesList && imagesList.length > 0 && (<div className={classes.uploaded_images_container}>
                            {imagesList.map((image, index) => {
                                return (
                                    <div key={index} className={classes.uploaded_image_wrapper}>
                                        <LazyImage src={URL.createObjectURL(image)} alt="immagine" key={index} className={classes.uploaded_image} />
                                        <XCircle size={20} color="white" strokeWidth={1.5} className={classes.delete_image_button} onClick={() => removeImage(index)} />
                                    </div>
                                )
                            })}
                        </div>)}
                        <input id='fileUpload' type='file' multiple accept='image/*' onChange={handleFileChange} ref={uploadImageRef} style={{ display: "none" }} />
                        <IconTextButton
                            icon={<Upload size={23} color={theme?.bottonePrimario?.coloreFronte || undefined} strokeWidth={1.5} />}
                            textProps={{
                                text_key: t("upload_file"),
                                text_size: "small",
                                text_weight: "bold",
                                color: theme?.bottonePrimario?.coloreFronte || undefined,
                            }}
                            expanded
                            buttonMode="normal"
                            backColor={theme?.bottonePrimario?.coloreSfondo || undefined}
                            contentsColor={theme?.bottonePrimario?.coloreFronte || undefined}
                            className={classes.upload_button}
                            padding={{
                                vertical: 10,
                            }}
                            onClick={() => uploadImageRef.current?.click()}
                        />
                    </div>
                    <TextSubtext
                        textProps={{
                            text_key: t("select_imgs"),
                            text_size: "tiny",
                            text_weight: "regular",
                            color: "var(--ink-lighter)",
                            className: classes.disclaimer
                        }}
                    />
                </div>
            </div>
        </div>
    );
};

const Author = () => {
    const { theme } = useAppContext();
    const [showAll, setShowAll] = useState<boolean>(false);
    const { user } = useAuth()

    return (
        <div className={classes.form_row}>
            <TextSubtext
                textProps={{
                    text_key: t("report_author"),
                    text_size: "title3",
                    text_weight: "bold",
                    color: theme?.stile?.coloreFronte || undefined,
                }}
            />
            {showAll ? (
                <AuthorRecap setShowAll={setShowAll} />
            ) : (
                <>
                    <div className={classes.input_container}>
                        <RecapSection
                            label={t("cf")}
                            description={user?.cf ?? ''}
                        />
                    </div>
                    <div className={classes.show_all} onClick={() => setShowAll(true)}>
                        <TextSubtext
                            textProps={{
                                text_key: t("show_all"),
                                text_size: "small",
                                text_weight: "regular",
                                color: theme?.bottonePrimario?.coloreSfondo || undefined,
                            }}
                        />
                        <ChevronDown size={20} color={theme?.bottonePrimario?.coloreSfondo ?? undefined} strokeWidth={1.5} />
                    </div>
                </>
            )}
        </div>
    );
};

export default ReportData;
