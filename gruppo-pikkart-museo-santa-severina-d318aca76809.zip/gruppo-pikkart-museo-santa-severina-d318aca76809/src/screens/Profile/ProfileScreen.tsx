import ProfileContentProvider from "@/components/ProfileContentProvider";
import ScreenLayout from "@/components/ScreenLayout";
import ProfileContent from "@/screens/Profile/ProfileContent";
import { useState } from "react";

const ProfileScreen = () => {
    const [visible, setVisibility] = useState(false)

    return (
        <ScreenLayout currentScreen="profile" showBottomBar={visible}>
            <ProfileContentProvider>
                <ProfileContent setVisibility={setVisibility}/>
            </ProfileContentProvider>
        </ScreenLayout>
    );
};

export default ProfileScreen;
