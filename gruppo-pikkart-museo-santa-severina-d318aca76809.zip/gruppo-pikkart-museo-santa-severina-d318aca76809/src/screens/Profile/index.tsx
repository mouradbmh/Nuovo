import ProfileScreen from "@/screens/Profile/ProfileScreen";

export default ProfileScreen;
