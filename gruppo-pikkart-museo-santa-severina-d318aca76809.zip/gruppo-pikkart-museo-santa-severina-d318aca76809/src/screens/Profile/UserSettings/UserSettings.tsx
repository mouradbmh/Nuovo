import NavigationTopBar from "@/components/NavigationTopBar";
import OptionBar from "@/components/OptionBar";
import ScreenLayout from "@/components/ScreenLayout";
import Separator from "@/components/Separator";
//import { useProfileContent } from "@/hooks/useProfileContent";
import { ChevronLeft } from "react-feather";
import classes from "@/screens/Profile/UserSettings/userSettings.module.css";
import TextSubtext from "@/components/TextSubtext";
import { useAuth } from "@/hooks/useAuth";
import { useNavigate } from "react-router-dom";
import EditUserBar from "@/components/EditUserBar";
import { useTranslation } from "react-i18next";
import FoldableMultiSelect from "@/components/FoldableMultiSelect";
import { useNavigation } from "@/hooks/useNavigation";

const UserSettings = () => {
    //const { setCurrentScreen,  } = useProfileContent();
    const { logout, user, update } = useAuth();
    const { i18n } = useTranslation();
    const navigate = useNavigate();
    const {go} = useNavigation();

    const changeLanguage = (lng: string) => {
        void i18n.changeLanguage(lng);
    };

    return (
        <ScreenLayout currentScreen="profile" showBottomBar={false}>
            <div className={classes.container}>
                <NavigationTopBar
                    title_key={"Utente"}
                    button_left={<ChevronLeft onClick={() => {go('/profile',false)}} />}
                />
                <EditUserBar
                    label_key="Nome"
                    value={user?.firstName || "-"}
                    setOnEdit={(value) => update({ nome: value })}
                />
                <Separator />
                <EditUserBar
                    label_key="Cognome"
                    value={user?.lastName || "-"}
                    setOnEdit={(value) => update({ cognome: value })}
                />
                <UserSettingsSeparator
                    label="ACCOUNT INFORMATION"
                />
                <OptionBar
                    textLeft_key="Email"
                    textRight_key={user?.email || "-"}
                    onHoverColor="transparent"
                />
                <UserSettingsSeparator
                    label="INTERNATIONAL PREFERENCES"
                />
                <FoldableMultiSelect
                    textLeft_key="Language"
                    textLeft_subtext_key={i18n.language === "en" ? "English" : "Italiano"}
                    options={[
                        {
                            textLeft_key: "English",
                            onClick: () => changeLanguage("en")
                        },
                        {
                            textLeft_key: "Italiano",
                            onClick: () => changeLanguage("it")
                        }
                    ]}
                />
                <OptionBar
                    textLeft_key="Delete account"
                />
                <OptionBar
                    textLeft_key="Log out"
                    onClick={() => {
                        logout();
                        navigate("/profile");
                    }}
                />
            </div>
        </ScreenLayout>
    );
};

const UserSettingsSeparator = ({ label }: { label: string }) => {
    return (
        <div className={classes.separator}>
            <span className={classes.separator_label}>
                <TextSubtext
                    textProps={{
                        text_key: label,
                        text_size: "small",
                        color: "var(--zinc-500)"
                    }}
                />
            </span>
        </div>
    );
};

export default UserSettings;
