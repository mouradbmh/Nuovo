import Checkbox from "@/components/Checkbox/Checkbox";
import FoldableSection from "@/components/FoldableSection";
import NavigationTopBar from "@/components/NavigationTopBar";
import OptionBar, { OptionBarProps } from "@/components/OptionBar";
import ScreenLayout from "@/components/ScreenLayout";
import ToggleSwitch from "@/components/ToggleSwitch";
import { ChevronLeft } from "react-feather";
import classes from "@/screens/Profile/NotificationSettings/notificationSettings.module.css";
import Separator from "@/components/Separator";
import { useProfileContent } from "@/hooks/useProfileContent";

const eventsOptions: OptionBarProps[] = [
    {
        textLeft_key: "Nuovi",
        iconRight: <Checkbox checked={false} onChange={() => { }} />
    },
    {
        textLeft_key: "Info sull'evento",
        iconRight: <Checkbox checked={true} onChange={() => { }} />
    },
    {
        textLeft_key: "Notifiche push",
        iconRight: <ToggleSwitch onChange={() => { }} />
    }
];

const NotificationSettings = () => {
    const { setCurrentScreen } = useProfileContent();
    
    return (
        <ScreenLayout currentScreen="profile" showBottomBar={false}>
            <NavigationTopBar
                title_key="Notifiche"
                button_left={<ChevronLeft onClick={() => setCurrentScreen("profile")} />}
            />
            <FoldableSection
                textLeft_key="Generali"
                textLeft_subtext_key="Mostra notifiche generali dell'app"
                options={[
                ]}
                className={classes.section}
            />
            <div className={classes.section}>
                <Separator />
            </div>
            <FoldableSection
                textLeft_key="Eventi"
                options={eventsOptions}
                className={classes.section}
            />
            <FoldableSection
                textLeft_key="Itinerari"
                options={eventsOptions}
                className={classes.section}
            />
            <FoldableSection
                textLeft_key="Esperienze"
                options={eventsOptions}
                className={classes.section}
            />
            <FoldableSection
                textLeft_key="Luoghi di interesse"
                options={eventsOptions}
                className={classes.section}
            />
            <FoldableSection
                textLeft_key="Altro"
                options={eventsOptions}
                className={classes.section}
            />
            <div className={classes.section}>
                <Separator />
            </div>
            <div className={classes.section}>
                <OptionBar
                    iconRight={<ToggleSwitch onChange={() => { }} />}
                    textLeft_key="Allerta meteo"
                    titleWeight="bold"
                    textLeft_subtext_key="Mostra info se presente allerta"
                />
            </div>
        </ScreenLayout>
    );
};

export default NotificationSettings;
