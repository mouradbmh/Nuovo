import NavigationTopBar from "@/components/NavigationTopBar";
import TextSubtext from "@/components/TextSubtext";
import TimeSelector from "@/components/TimeSelector";
import classes from "@/screens/Profile/ManageAccess/singleManageAccess.module.css";
import { useState } from "react";
import { ChevronLeft } from "react-feather";

const SingleManageAccess = ({
    event,
    setSelectedEvent
}: { event: string, setSelectedEvent: (e: string | null) => void }) => {
    const [time, /*setTime*/] = useState<string>(new Date().toISOString()
            .slice(0, 16)
            .replace(/-/g, ".")
            .replace("T", " - ")
            .replace(":", "."));

    return (
        <div className={classes.container}>
            <NavigationTopBar
                title_key="Gestione accessi"
                button_left={<ChevronLeft onClick={() => setSelectedEvent(null)} />}
            />
            <div className={classes.title_container}>
                <TextSubtext
                    textProps={{
                        text_key: event,
                        text_size: "title3",
                        text_weight: "bold",
                    }}
                />
            </div>
            <div className={classes.time_selector_container}>
                <TimeSelector
                    text_key="Data e ora"
                    time={time}
                    onClick={() => { }}
                />
            </div>
        </div>
    );
};

export default SingleManageAccess;
