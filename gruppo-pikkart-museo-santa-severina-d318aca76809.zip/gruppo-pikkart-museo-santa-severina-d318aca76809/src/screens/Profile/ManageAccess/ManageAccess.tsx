import InputComponent from "@/components/InputComponent";
import NavigationTopBar from "@/components/NavigationTopBar";
import { useProfileContent } from "@/hooks/useProfileContent";
import { ChevronLeft, Search } from "react-feather";
import classes from "@/screens/Profile/ManageAccess/manageAccess.module.css";
import TextSubtext from "@/components/TextSubtext";
import TabContents from "@/components/TabContents";
import { useState } from "react";
import SingleManageAccess from "@/screens/Profile/ManageAccess/SingleManageAccess";

const ManageAccess = () => {
    const { setCurrentScreen } = useProfileContent();
    const [selectedEvent, setSelectedEvent] = useState<string | null>(null);

    return (
        <>
            {selectedEvent === null ? (
                <>
                    <NavigationTopBar
                        title_key="Gestione accessi"
                        button_left={<ChevronLeft onClick={() => setCurrentScreen("profile")} />}
                    />
                    <div className={classes.search_container}>
                        <InputComponent
                            icon={<Search width="16px" height="16px" />}
                            inputName="search"
                            inputProps={{
                                text_key: "",
                                text_size: "small",
                            }}
                            inputType="text"
                            placeholderText_key="Cerca"
                            setOnChange={() => { }}
                        />
                    </div>
                    <div className={classes.title_container}>
                        <TextSubtext
                            textProps={{
                                text_key: "Eventi",
                                text_size: "title3",
                                text_weight: "bold",
                            }}
                        />
                    </div>
                    <div className={classes.events_container}>
                        <TabContents
                            tabs={[
                                {
                                    text: "Evento 1",
                                    imgUrl: "https://picsum.photos/200/300",
                                    date: "12/12/2021",
                                    onClick: () => setSelectedEvent("Evento 1"),
                                },
                                {
                                    text: "Evento 2",
                                    imgUrl: "https://picsum.photos/200/300",
                                    date: "12/12/2021",
                                    onClick: () => setSelectedEvent("Evento 2"),
                                },
                                {
                                    text: "Evento 3",
                                    imgUrl: "https://picsum.photos/200/300",
                                    date: "12/12/2021",
                                    onClick: () => setSelectedEvent("Evento 3"),
                                },
                                {
                                    text: "Evento 4",
                                    imgUrl: "https://picsum.photos/200/300",
                                    date: "12/12/2021",
                                    onClick: () => setSelectedEvent("Evento 4"),
                                },
                                {
                                    text: "Evento 5",
                                    imgUrl: "https://picsum.photos/200/300",
                                    date: "12/12/2021",
                                    onClick: () => setSelectedEvent("Evento 5"),
                                },
                            ]}
                        />
                    </div>
                </>) :
                <SingleManageAccess event={selectedEvent} setSelectedEvent={setSelectedEvent} />}
        </>
    );
};

export default ManageAccess;
