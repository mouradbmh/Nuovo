import { ProfileEvent } from "@/components/ProfileContentProvider";
import ProfileOptionsList from "@/components/ProfileOptionsList";
import ProfileTitle from "@/components/ProfileTitle";
import TabContents from "@/components/TabContents";
import TabsBar from "@/components/TabsBar";
import { useAuth } from "@/hooks/useAuth";
import { useProfileContent } from "@/hooks/useProfileContent";
import classes from "@/screens/Profile/profileContent.module.css";
import { Dispatch, SetStateAction, useMemo, useState } from "react";
import { AlertOctagon, ChevronRight, Lock, User } from "react-feather";
import NotificationSettings from "@/screens/Profile/NotificationSettings/NotificationSettings";
import { styled } from "styled-components";
import { useAppContext } from "@/hooks/useAppContext";
import UserSettings from "@/screens/Profile/UserSettings/UserSettings";
import ChangePassword from "@/screens/Profile/ChangePassword/ChangePassword";
import ButtonBar from "@/components/ButtonBar";
import { useNavigate } from "react-router-dom";
import TextSubtext from "@/components/TextSubtext";
import ManageAccess from "@/screens/Profile/ManageAccess/ManageAccess";
import Reports from "@/screens/Profile/Reports/Reports";
import ReportsProvider from "@/components/Reports/ReportsProvider";
import { useNavigation } from "@/hooks/useNavigation";
import { DetailsContentsType } from "@/components/DetailsProvider/DetailsProvider";
import { Capacitor } from "@capacitor/core";
// import { Browser } from '@capacitor/browser';
// import { useProfile } from "@/hooks/useProfile";
// import { useKey } from "@/hooks/useKeyContext.tsx";
// import MunicipalitySelector from "@/components/MunicipalitySelector";

type Props = {
  setVisibility: Dispatch<SetStateAction<boolean>>
}

const getType = (type: string | undefined) => {
  switch (type) {

    case 'Notizia':
    case 'NotiziaTraduzione':
      return DetailsContentsType.NEWS;

    case 'Evento':
    case 'EventoTraduzione':
      return DetailsContentsType.EVENT;

    case 'Esperienza':
    case 'EsperienzaTraduzione':
      return DetailsContentsType.EXPERIENCE;

    case 'PuntoDiInteresse':
    case 'PuntoDiInteresseTraduzione':
      return DetailsContentsType.POINT_OF_INTEREST;

    case 'Itinerario':
    case 'ItinerarioTraduzione':
      return DetailsContentsType.ITINERARY;

    case 'ProdottoTipico':
    case 'ProdottoTipicoTraduzione':
      return DetailsContentsType.TYPICAL_PRODUCT;

    case 'AttivitaCommerciale':
    case 'AttivitaCommercialeTraduzione':
      return DetailsContentsType.COMMERCIAL_ACTIVITY;

    case 'ContenutoInformativo':
    case 'ContenutoInformativoTraduzione':
      return DetailsContentsType.INFORMATIVE_CONTENT;

    case 'EsperienzaAR':
    case 'EsperienzaARTraduzione':
      return DetailsContentsType.AR_ELEMENT;

    default:
      return -1;
  }
};

const ProfileContent = ({ setVisibility }: Props) => {
  const { currentScreen } = useProfileContent();
  if (currentScreen === "profile") {
    setVisibility(true);
    return <MainContent />;
  } else if (currentScreen === "notification-settings") {
    setVisibility(false);
    return <NotificationSettings />;
  } else if (currentScreen === "user-settings") {
    setVisibility(false);
    return <UserSettings />;
  } else if (currentScreen === "change-password") {
    setVisibility(false);
    return <ChangePassword />;
  } else if (currentScreen === "manage-access") {
    setVisibility(false);
    return <ManageAccess />;
  } else if (currentScreen === "reports") {
    setVisibility(false);
    return (
      <ReportsProvider>
        <Reports />
      </ReportsProvider>
    );
  }
  return null;
};

const StyledDiv = styled.div<{ backcolor: string }>`
  background-color: ${(props) => props.backcolor};
`;

const MainContent = () => {
  // const { configs } = useKey();
  // const { clearProfile } = useProfile();
  const { user, isLoggedIn } = useAuth();
  const { setCurrentScreen, savedEvents, servicesEnte } = useProfileContent();
  const [currentTab, setCurrentTab] = useState<"booked" | "saved">("booked");
  const { theme, config } = useAppContext();
  const navigate = useNavigate();
  const { go } = useNavigation()

  const registerEnabled = useMemo(() => {
    const val = config?.autenticazioneBasic || config?.registrazioneUtente || config?.autenticazioneTramiteIdentitaDigitale

    if (val === undefined) {
      return false
    } else {
      return val
    }

  }, [config?.autenticazioneBasic, config?.autenticazioneTramiteIdentitaDigitale, config?.registrazioneUtente])


  const backColor = theme?.stile?.coloreSfondo || "var(--outline-bg)";
  const textColor = theme?.stile?.coloreFronte || "var(--zinc-900)";
  const tabColor = theme?.tab?.coloreFronte || "var(--zinc-500)";
  const tabActiveColor = theme?.tabSelezionato?.coloreFronte || "var(--emerald-700)";

  // const handleChangeMunicipality = () => {
  //   clearProfile();
  //   localStorage.removeItem("showOnboarding");
  //   navigate('/setup');
  // };

  const eventsToTabContents = (events: ProfileEvent[]) => {
    return events.map((event) => {
      return {
        text: event.title,
        imgUrl: event.imgUrl + '&thumbkey=thumbnail',
        date: event.date,
        onClick: () => { go('/details/?id=' + event.id.toString() + '&type=' + getType(event.contentType).toString()) }
      }
    });
  }

  const onLogin = () => {
    if (config?.autenticazioneTramiteIdentitaDigitale) {
      /**
       * The callback URL should use a deep link schema/universal link for our app. However, if we register https://comune.gassino.to.it/ as our universal link, when we process this endpoint, it will not go anywhere; it will instead remain within our app because https://comune.gassino.to.it/ will be redirected to our app.
       * 
       * Even if it's using an internal browser, not external, the access token and refresh token that we obtain are still not saved in the same place. Cordova and the * internal app are separate places, even if they are within the same environment.
       */
      // const url = `${config.urlApplicazioneWeb!}/accesso/?hideHeaderFooter=1&hideDefaultLogin=1&appBackUrl=${encodeURIComponent('comunegassino://')}`;
      if(Capacitor.isNativePlatform()){
        const url = `${config.urlApplicazioneWeb!}/accesso/?hideHeaderFooter=1&hideDefaultLogin=1&appBackUrl=${encodeURIComponent('comunegassino://')}`;
        // await Browser.open({ url});
        window.open(url)
      }else{
        const url = `${config.urlApplicazioneWeb!}/accesso/?hideHeaderFooter=1&hideDefaultLogin=1&appBackUrl=${encodeURIComponent(window.location.hostname)}`;
        // await Browser.open({ url});
        window.open(url)
      }
    } else {
      navigate('/login')
    }
  }

  return (
    <StyledDiv backcolor={backColor} className={registerEnabled ? classes.container : classes.container_no_padding}>
      {registerEnabled && (
        isLoggedIn ? (
          <ProfileTitle
            user_full_name={(user?.firstName || 'Nome') + ' ' + (user?.lastName || 'Cognome')}
            user_email={user?.email || ''}
            color={textColor}
          />) : (
          <ButtonBar
            text_color={textColor}
            backColor={theme?.bottonePrimario?.coloreSfondo || undefined}
            text_key="Account"
            text_subtext_key="Accedi o crea un account"
            button_text_key="Accedi"
            button_text_color={theme?.bottonePrimario?.coloreFronte || undefined}
            showArrow={false}
            icon={<User height="24" strokeWidth={1.5} width="24" />}
            onClick={() => void onLogin()}
          />
        ))}
      {/* {configs?.MULTITENANT === 'true' &&
        <MunicipalitySelector
          municipality_text_key={config?.nome || undefined}
          on_change_municipality={() => handleChangeMunicipality()}
          label_text_color={textColor}
          municipality_text_color={theme?.settings?.comuneSelezionato?.coloreFronte || undefined}
          back_color={theme?.settings?.comuneSelezionato?.coloreSfondo || undefined}
          border_color={theme?.settings?.comuneSelezionato?.coloreBordo || undefined}
          button_back_color={theme?.bottonePrimario?.coloreSfondo || undefined}
          button_border_color={theme?.bottonePrimario?.coloreBordo || undefined}
          button_text_color={theme?.bottonePrimario?.coloreFronte || undefined}
        />
      } */}
      {/* <button onClick={() => setCurrentScreen("reports")} style={{backgroundColor: 'red'}}>test</button> */}
      {registerEnabled && (isLoggedIn && <ProfileOptionsList
        profileOptions={[{
          iconLeft: <User height="24" strokeWidth={1.5} width="24" />,
          iconRight: <ChevronRight height="24" strokeWidth={1.5} width="24" />,
          color: textColor,
          backColor: "transparent",
          textLeft_key: 'Utente',
          hidden: !isLoggedIn,
          onClick: () => setCurrentScreen("user-settings")
        },
        {
          iconLeft: <Lock height="24" strokeWidth={1.5} width="24" />,
          iconRight: <ChevronRight height="24" strokeWidth={1.5} width="24" />,
          color: textColor,
          backColor: "transparent",
          textLeft_key: 'Cambia Password',
          hidden: !isLoggedIn,
          onClick: () => setCurrentScreen("change-password"),
        },
        // {
        //     iconLeft: <Bell height="24" strokeWidth={1.5} width="24" />,
        //     iconRight: <ChevronRight height="24" strokeWidth={1.5} width="24" />,
        //     color: textColor,
        //     backColor: "transparent",
        //     textLeft_key: 'Notifiche',
        // },
        {
          iconLeft: <AlertOctagon height="24" strokeWidth={1.5} width="24" />,
          iconRight: <ChevronRight height="24" strokeWidth={1.5} width="24" />,
          color: textColor,
          backColor: "transparent",
          textLeft_key: 'Segnalazioni',
          hidden: !isLoggedIn || !(servicesEnte.length > 0),
          onClick: () => setCurrentScreen("reports"),
        },
          // {
          //     iconLeft: <Settings height="24" strokeWidth={1.5} width="24" />,
          //     iconRight: <ChevronRight height="24" strokeWidth={1.5} width="24" />,
          //     color: textColor,
          //     backColor: "transparent",
          //     textLeft_key: 'Impostazioni notifiche',
          //     disabled: !isLoggedIn,
          //     disabledColor: disabledColor || undefined,
          //     textLeft_subtext_key: !isLoggedIn ? 'accedi per impostare le tue notifiche' : undefined,
          //     onClick: () => setCurrentScreen("notification-settings"),
          // },
          // {
          //     iconLeft: <User height="24" strokeWidth={1.5} width="24" />,
          //     iconRight: <ChevronRight height="24" strokeWidth={1.5} width="24" />,
          //     color: textColor,
          //     backColor: "var(--zinc-100)", // TODO: use theme
          //     textLeft_key: 'Gestione accessi',
          //     hidden: !isLoggedIn,
          //     onClick: () => setCurrentScreen("manage-access"),
          // }
        ]}
      />)}
      {config?.autenticazioneBasic && config.registrazioneUtente && config.autenticazioneTramiteIdentitaDigitale && <TabsBar
        tabs={[
          {
            title_key: 'Salvati',
            inactivebackColor: "transparent",
            activeBackColor: "transparent",
            inactiveTextColor: tabColor,
            activeTextColor: tabActiveColor,
          }]}
        onTabChange={() => setCurrentTab(currentTab === "booked" ? "saved" : "booked")}
      />}
      {config?.autenticazioneBasic && config.registrazioneUtente && config.autenticazioneTramiteIdentitaDigitale && (
        isLoggedIn ? (<TabContents
          tabs={
            eventsToTabContents(/*currentTab === "booked" ? bookedEvents :*/ savedEvents)
          }

        />) : (
          <div className={classes.not_loggedin_bookings_container}>
            <TextSubtext
              textProps={{
                text_key: "Accedi per prenotare o salvare i tuoi preferiti",
                color: textColor,
                text_size: "small",
                text_weight: "regular",
              }}
            />
          </div>
        ))}
    </StyledDiv>
  )
}

// const eventsToTabContents = (events: ProfileEvent[]) => {
//     return events.map((event) => {
//         return {
//             text: event.title,
//             imgUrl: event.imgUrl + '&thumbkey=thumbnail',
//             date: event.date,
//         }
//     });
// }

export default ProfileContent;
