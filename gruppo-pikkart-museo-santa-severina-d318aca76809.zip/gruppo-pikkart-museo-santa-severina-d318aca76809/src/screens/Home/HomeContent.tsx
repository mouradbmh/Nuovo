import classes from '@/screens/Home/homeContent.module.css';
import HomeSection from "@/components/HomeSection";
import TextComponent from "@/components/TextComponent";
import { useAppContext } from "@/hooks/useAppContext";
import { useHome } from "@/hooks/useHome";
import { useTranslation } from "react-i18next";
import { styled } from "styled-components";

const StyledHomeContent = styled.div<{ backgroundcolor: string, color: string }>`
    background-color: ${props => props.backgroundcolor};
    color: ${props => props.color};
`;

const HomeContent = () => {
  const { inEvidenza, tipologieContenuto } = useHome();
  const { t } = useTranslation();
  const { theme, config } = useAppContext();
  // console.log(inEvidenza)

  return (
    <StyledHomeContent backgroundcolor={theme?.stile?.coloreSfondo ? theme?.stile?.coloreSfondo : 'unset'}
      color={theme?.stile?.coloreFronte ? theme.stile.coloreFronte : 'black'}>
      <div className={classes.payoff_container}>
        <TextComponent text_key={config?.messaggioHome as string} text_size="small" text_line="normal" />   {/*FIXME: tradurre? */}
      </div>
      {
        inEvidenza ?
          <HomeSection content={{
            container: inEvidenza?.container,
            contenuti: inEvidenza?.contenuti,
            tipologiaLayout: "GRIGLIA_GRANDE",
            nome: t("highlighted")
          }}
            cardStyled={true}
          />
          :
          <div className={classes.loader_wrapper}>
            <span className={classes.loader}></span>
          </div>
      }
      {
        tipologieContenuto?.map((tipologia, index) => {
          return tipologia && <HomeSection key={index} content={tipologia} vediTuttiText={t('view_all')} />
        })
      }
    </StyledHomeContent>
  );
};

export default HomeContent;