import HomeTopBar from "@/components/HomeTopBar";
import { HomeProvider } from "@/components/HomeProvider";
import ScreenLayout from "@/components/ScreenLayout";
import { HomeContent } from "@/screens/Home";

const HomeScreen = () => {
    return (
        <ScreenLayout currentScreen="home">
            <HomeProvider>
                <HomeTopBar />
                <HomeContent />
            </HomeProvider>
        </ScreenLayout>
    );
};

export default HomeScreen;