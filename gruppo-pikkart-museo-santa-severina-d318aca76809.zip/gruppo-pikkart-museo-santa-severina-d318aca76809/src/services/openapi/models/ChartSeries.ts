/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type ChartSeries = {
    name?: string | null;
    data?: Array<number> | null;
};

