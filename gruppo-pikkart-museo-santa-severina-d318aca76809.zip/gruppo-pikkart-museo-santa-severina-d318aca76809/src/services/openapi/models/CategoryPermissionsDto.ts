/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { PermissionRolesDto } from './PermissionRolesDto';

export type CategoryPermissionsDto = {
    name?: string;
    permissions?: Array<PermissionRolesDto>;
};

