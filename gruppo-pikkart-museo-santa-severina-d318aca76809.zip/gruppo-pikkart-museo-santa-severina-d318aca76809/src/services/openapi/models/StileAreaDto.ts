/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { StileFontDto } from './StileFontDto';

export type StileAreaDto = (StileFontDto & {
    coloreSfondo?: string | null;
});

