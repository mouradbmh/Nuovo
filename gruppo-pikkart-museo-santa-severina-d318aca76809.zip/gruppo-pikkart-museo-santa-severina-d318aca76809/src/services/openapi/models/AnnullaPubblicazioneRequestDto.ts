/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type AnnullaPubblicazioneRequestDto = {
    tipologiaAnnullamentoUniqueId: string;
    estremiAnnullamento: string;
};

