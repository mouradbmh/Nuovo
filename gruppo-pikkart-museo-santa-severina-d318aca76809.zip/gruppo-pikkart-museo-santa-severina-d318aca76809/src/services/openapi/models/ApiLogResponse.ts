/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { PaginationResponseOfApiLogDto } from './PaginationResponseOfApiLogDto';

export type ApiLogResponse = PaginationResponseOfApiLogDto;

