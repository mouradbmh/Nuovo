/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type DisponibilitaPrenotabileDto = {
    uniqueId?: string;
    inizio?: string;
    fine?: string;
    prenotabile?: boolean;
};

