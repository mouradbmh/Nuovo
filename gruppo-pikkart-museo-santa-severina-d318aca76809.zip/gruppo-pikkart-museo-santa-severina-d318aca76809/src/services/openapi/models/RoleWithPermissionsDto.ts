/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { RoleDto2 } from './RoleDto2';

export type RoleWithPermissionsDto = (RoleDto2 & {
    permissions?: Array<string> | null;
});

