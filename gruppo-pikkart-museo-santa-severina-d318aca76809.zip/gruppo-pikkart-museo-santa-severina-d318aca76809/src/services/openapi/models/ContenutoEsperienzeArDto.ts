import { ContenutoEsperienzeArBaseDto } from "@/services/openapi";

export type ContenutoEsperienzeArDto = {
    content?: ContenutoEsperienzeArBaseDto[]
    nome?: string | null;
    uniqueId?: string | null;
    nomeEntita?: string;
    tipologiaLayout?: string | null;
};