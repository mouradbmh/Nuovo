/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type FeatureDto = {
    id?: string;
    name?: string;
    priority?: number;
    category?: string;
    description?: string;
    moduleName?: string;
    defaultTenantOnly?: boolean;
    dependencies?: Array<string>;
    isAlwaysEnabled?: boolean;
    isEnabled?: boolean;
};

