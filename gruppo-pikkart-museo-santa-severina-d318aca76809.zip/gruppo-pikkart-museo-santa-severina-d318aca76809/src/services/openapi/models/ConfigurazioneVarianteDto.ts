/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { CodiceMomento } from './CodiceMomento';
import type { ConfigurazioneAllegatoVarianteDto } from './ConfigurazioneAllegatoVarianteDto';
import type { ConfigurazioneCampoCustomVarianteDto } from './ConfigurazioneCampoCustomVarianteDto';
import type { NomeEntitaVariante } from './NomeEntitaVariante';

export type ConfigurazioneVarianteDto = {
    uniqueId?: string | null;
    titolo?: string;
    codiceMomento?: CodiceMomento;
    nomeEntitaVariante?: NomeEntitaVariante;
    consentePersonaFisica?: boolean | null;
    consentePersonaGiuridica?: boolean | null;
    sottoTitolo?: string;
    numeroMinimoOccorrenze?: number;
    numeroMassimoOccorrenze?: number;
    titoloHelpOnline?: string | null;
    testoHelpOnline?: string | null;
    ordinamento?: number | null;
    configurazioniAllegatiVarianti?: Array<ConfigurazioneAllegatoVarianteDto>;
    configurazioniCampiCustomVarianti?: Array<ConfigurazioneCampoCustomVarianteDto>;
    ruoloPersonaUniqueId?: string | null;
    richiediResidenzaPersona?: boolean | null;
    richiediDomicilioPersona?: boolean | null;
    richiediContattiPersona?: boolean | null;
};

