/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type RoleDto = {
    id?: string;
    name?: string;
    code?: string;
    description?: string | null;
};

