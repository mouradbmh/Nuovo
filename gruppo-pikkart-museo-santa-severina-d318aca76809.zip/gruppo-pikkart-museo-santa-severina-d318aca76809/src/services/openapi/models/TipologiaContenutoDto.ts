/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { IndiceContenutoDto } from './IndiceContenutoDto';

export type TipologiaContenutoDto = {
    uniqueId?: string | null;
    nome?: string | null;
    nomeEntita?: string | null;
    contenuti?: Array<IndiceContenutoDto>;
};

