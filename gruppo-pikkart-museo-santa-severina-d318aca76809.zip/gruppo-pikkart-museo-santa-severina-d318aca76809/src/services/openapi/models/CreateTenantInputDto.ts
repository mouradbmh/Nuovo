/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type CreateTenantInputDto = {
    registrationRequestUniqueId: string;
};

