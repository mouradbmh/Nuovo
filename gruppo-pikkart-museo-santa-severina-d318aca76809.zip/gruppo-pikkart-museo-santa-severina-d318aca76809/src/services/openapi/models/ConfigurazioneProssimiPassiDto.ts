/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { CodiceMomento } from './CodiceMomento';

export type ConfigurazioneProssimiPassiDto = {
    uniqueId?: string | null;
    codiceMomento?: CodiceMomento;
    dataFissa?: string | null;
    nGiorniDaEvento?: number | null;
    titolo?: string;
    descrizione?: string | null;
    ordinamento?: number | null;
};

