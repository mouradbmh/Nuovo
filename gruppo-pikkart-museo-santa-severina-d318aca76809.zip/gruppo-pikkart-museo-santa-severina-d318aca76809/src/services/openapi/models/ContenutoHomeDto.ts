/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { ContenutoHomeBaseDto } from './ContenutoHomeBaseDto';

export type ContenutoHomeDto = (ContenutoHomeBaseDto & {
    nome?: string | null;
    uniqueId?: string | null;
    nomeEntita?: string;
    tipologiaLayout?: string | null;
});

