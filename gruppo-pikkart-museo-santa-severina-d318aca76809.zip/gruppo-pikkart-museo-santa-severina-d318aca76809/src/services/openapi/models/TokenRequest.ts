/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type TokenRequest = {
    email: string;
    password: string;
};

