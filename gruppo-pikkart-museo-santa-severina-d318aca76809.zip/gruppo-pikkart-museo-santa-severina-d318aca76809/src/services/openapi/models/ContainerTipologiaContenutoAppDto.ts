/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type ContainerTipologiaContenutoAppDto = {
    nome?: string;
    backColor?: string | null;
    coloreTitoloTipologia?: string | null;
    coloreVediTutti?: string | null;
    coloreTitoloItem?: string | null;
    coloreDescrizioneItem?: string | null;
    coloreDataItem?: string | null;
};

