/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type CollegaAccountPersonaPubblicaDto = {
    personaPubblicaUniqueId: string;
    username: string;
};

