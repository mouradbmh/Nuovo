/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type RecipientKeyDto = {
    encriptedKey?: string;
    recipientId?: string;
};

