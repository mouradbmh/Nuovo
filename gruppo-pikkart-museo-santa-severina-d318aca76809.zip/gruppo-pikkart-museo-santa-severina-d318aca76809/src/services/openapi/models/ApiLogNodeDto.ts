/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type ApiLogNodeDto = {
    uniqueId?: string;
    node?: string;
};

