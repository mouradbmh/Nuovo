/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { ProblemDetails } from './ProblemDetails';

export type HttpValidationProblemDetails = (ProblemDetails & Record<string, any>);

