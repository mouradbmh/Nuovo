/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type DbProductInfo = {
    productName?: string;
    edition?: string;
    productMajorVersion?: string;
    productMinorVersion?: string;
    productVersion?: string;
    productUpdateReference?: string;
    productBuild?: string;
    productBuildType?: string;
    productLevel?: string;
    engineEdition?: string;
    buildClrVersion?: string;
};

