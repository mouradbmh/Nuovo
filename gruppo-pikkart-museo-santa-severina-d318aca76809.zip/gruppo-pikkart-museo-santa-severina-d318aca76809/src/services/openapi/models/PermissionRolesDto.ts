/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { RoleDto } from './RoleDto';

export type PermissionRolesDto = {
    code?: string;
    name?: string;
    description?: string;
    isSecurityCritical?: boolean;
    roles?: Array<RoleDto>;
};

