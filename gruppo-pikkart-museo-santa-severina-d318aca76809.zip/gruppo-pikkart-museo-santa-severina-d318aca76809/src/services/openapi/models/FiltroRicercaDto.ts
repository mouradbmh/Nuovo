/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { FiltroDataDto } from './FiltroDataDto';
import type { FiltroEsperienzeDto } from './FiltroEsperienzeDto';
import type { FiltroItinerariDto } from './FiltroItinerariDto';
import type { FiltroPuntiDiInteresseDto } from './FiltroPuntiDiInteresseDto';
import type { FiltroTipologieDto } from './FiltroTipologieDto';

export type FiltroRicercaDto = {
    testo?: string | null;
    tipologiaContenutoUniqueId?: string | null;
    data?: FiltroDataDto | null;
    adattoA?: Array<string> | null;
    condizioniDiAccesso?: Array<string> | null;
    itinerari?: FiltroItinerariDto | null;
    puntiDiInteresse?: FiltroPuntiDiInteresseDto | null;
    eventi?: FiltroTipologieDto | null;
    notizie?: FiltroTipologieDto | null;
    attivitaCommerciali?: FiltroTipologieDto | null;
    esperienze?: FiltroEsperienzeDto | null;
    prodottiTipici?: FiltroTipologieDto | null;
};

