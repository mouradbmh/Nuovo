/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type TenantRegistrationRequestDto = {
    uniqueId?: string;
    insertDate?: string;
    updateDate?: string | null;
    tenantId?: string;
    email?: string;
    tenantPublicKey?: string | null;
    waitingForPayment?: boolean;
};

