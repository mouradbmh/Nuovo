/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { ContainerTipologiaContenutoAppDto } from './ContainerTipologiaContenutoAppDto';
import type { StileAreaDto } from './StileAreaDto';

export type StileEventoDto = {
    sezioneEventoGenitore?: StileAreaDto | null;
    containerEventiCorrelati?: ContainerTipologiaContenutoAppDto | null;
    containerLuoghi?: ContainerTipologiaContenutoAppDto | null;
};

