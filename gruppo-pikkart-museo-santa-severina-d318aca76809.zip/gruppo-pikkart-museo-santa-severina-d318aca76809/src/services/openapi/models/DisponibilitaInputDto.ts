/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type DisponibilitaInputDto = {
    inizio?: string;
    fine?: string;
    ufficioUniqueId?: string;
    servizioEnteUniqueId?: string;
    codiceTipoRicorrenza?: string | null;
    fineRicorrenza?: string | null;
};

