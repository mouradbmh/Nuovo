/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { PaginationResponseOfApiRuntimeLogDto } from './PaginationResponseOfApiRuntimeLogDto';

export type ApiRuntimeLogResponse = PaginationResponseOfApiRuntimeLogDto;

