/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type RefertaFirmataRequestDto = {
    refertaFirmataUniqueId: string;
};

