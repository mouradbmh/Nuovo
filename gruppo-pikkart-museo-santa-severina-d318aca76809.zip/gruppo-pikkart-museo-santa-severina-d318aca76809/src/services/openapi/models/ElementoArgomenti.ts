/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type ElementoArgomenti = {
    nome?: string;
    slug?: string;
    numero?: number;
};

