/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type NodePerfStatsDto = {
    node?: string;
    nodeUniqueId?: string;
    requestsCount?: number;
    averageProcessTime?: number;
};

