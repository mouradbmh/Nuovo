export type ComuneDto = {
  text_key: string;
  subtext_key: string;
  tenantId: string;
  authDomain: string;
}