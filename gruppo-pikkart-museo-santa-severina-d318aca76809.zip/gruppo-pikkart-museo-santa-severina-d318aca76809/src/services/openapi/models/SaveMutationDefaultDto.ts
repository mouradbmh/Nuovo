/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type SaveMutationDefaultDto = {
    moduleNodeName: string;
    entityNodeName: string;
    formJson: string;
};

