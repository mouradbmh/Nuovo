/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { ContainerTipologiaContenutoAppDto } from './ContainerTipologiaContenutoAppDto';
import type { StileAreaDto } from './StileAreaDto';
import type { StileFontDto } from './StileFontDto';

export type StileRicercaDto = {
    iconaTipologiaContenuto?: StileAreaDto | null;
    iconaTipologiaContenutoSelezionata?: StileAreaDto | null;
    labelTipologiaContenuto?: StileFontDto | null;
    containerRisultati?: ContainerTipologiaContenutoAppDto | null;
};

