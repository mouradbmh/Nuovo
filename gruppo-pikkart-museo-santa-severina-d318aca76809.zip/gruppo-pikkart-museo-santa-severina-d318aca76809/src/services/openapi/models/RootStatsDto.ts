/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type RootStatsDto = {
    tenantsCount?: number;
    expiringTenantsCount?: number;
    usersCount?: number;
};

