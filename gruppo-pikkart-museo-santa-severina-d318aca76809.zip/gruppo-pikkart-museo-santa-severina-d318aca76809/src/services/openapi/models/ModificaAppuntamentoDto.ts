/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type ModificaAppuntamentoDto = {
    disponibilitaUniqueId?: string | null;
    titoloRichiesta?: string;
    dettaglioRichiesta?: string;
    nome?: string;
    cognome?: string;
    email?: string;
    note?: string | null;
};

