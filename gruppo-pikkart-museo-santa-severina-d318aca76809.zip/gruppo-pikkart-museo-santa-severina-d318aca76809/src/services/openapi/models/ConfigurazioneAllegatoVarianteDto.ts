/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { FileType } from './FileType';

export type ConfigurazioneAllegatoVarianteDto = {
    uniqueId?: string | null;
    configurazioneVarianteUniqueId?: string | null;
    nomeTipologiaAllegato?: string;
    obbligatorio?: boolean;
    formatiAccettati?: Array<FileType>;
    ordinamento?: number | null;
};

