/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { ContainerTipologiaContenutoAppDto } from './ContainerTipologiaContenutoAppDto';

export type StileItinerarioDto = {
    containerTappe?: ContainerTipologiaContenutoAppDto;
};

