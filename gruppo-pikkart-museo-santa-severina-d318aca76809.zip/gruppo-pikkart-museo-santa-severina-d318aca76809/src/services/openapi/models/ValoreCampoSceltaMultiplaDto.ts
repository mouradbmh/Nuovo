/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type ValoreCampoSceltaMultiplaDto = {
    uniqueId?: string | null;
    configurazioneCampoCustomVarianteUniqueId?: string;
    testoScelta?: string;
    ordinamentoScelta?: number | null;
    valoreDefault?: boolean;
};

