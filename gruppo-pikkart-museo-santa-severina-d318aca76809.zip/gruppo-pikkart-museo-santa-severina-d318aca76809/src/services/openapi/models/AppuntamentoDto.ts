/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type AppuntamentoDto = {
    uniqueId?: string;
    disponibilitaUniqueId?: string;
    titoloRichiesta?: string;
    dettaglioRichiesta?: string;
    nome?: string;
    cognome?: string;
    email?: string;
    note?: string | null;
    emailVerificata?: boolean | null;
    dataRichiesta?: string | null;
    confermato?: boolean | null;
    dataConferma?: string | null;
};

