/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type PraticaCambioStatoDto = {
    codice?: string;
    messaggio?: string;
};

