/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { StileAreaDto } from './StileAreaDto';

export type StileBottoneDto = (StileAreaDto & {
    coloreBordo?: string | null;
});

