/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type TenantRegistrationOTPRequestDto = {
    tenantId: string;
    email: string;
};

