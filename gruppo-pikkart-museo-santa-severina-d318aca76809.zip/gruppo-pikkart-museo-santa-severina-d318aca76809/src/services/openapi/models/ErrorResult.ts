/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type ErrorResult = {
    extensions?: Record<string, any> | null;
    messages?: Array<string>;
    source?: string | null;
    exception?: string | null;
    requestId?: string | null;
    supportMessage?: string | null;
    statusCode?: number;
    timestamp?: string;
};

