/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type NodeErrorsStatsDto = {
    node?: string;
    nodeUniqueId?: string;
    requestsCount?: number;
    errorsCount?: number;
};

