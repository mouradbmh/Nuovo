/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type ScollegaAccountPersonaPubblicaDto = {
    username: string;
};

