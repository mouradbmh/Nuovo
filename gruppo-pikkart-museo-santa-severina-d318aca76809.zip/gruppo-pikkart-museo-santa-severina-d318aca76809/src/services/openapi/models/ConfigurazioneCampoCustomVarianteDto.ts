/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { TipologiaCampoVariante } from './TipologiaCampoVariante';
import type { ValoreCampoSceltaMultiplaDto } from './ValoreCampoSceltaMultiplaDto';

export type ConfigurazioneCampoCustomVarianteDto = {
    uniqueId?: string | null;
    configurazioneVarianteUniqueId?: string | null;
    tipoCampoVarianteUniqueId?: string | null;
    nomeCampo?: string;
    labelCampoFrontend?: string;
    tooltipFrontend?: string | null;
    maxCaratteri?: number | null;
    obbligatorio?: boolean;
    preselezionato?: boolean | null;
    valoreDefault?: string | null;
    maxRisposteSelezionabili?: number | null;
    tipologiaCampoVariante?: TipologiaCampoVariante;
    valoriCampiSceltaMultipla?: Array<ValoreCampoSceltaMultiplaDto>;
    ordinamento?: number | null;
};

