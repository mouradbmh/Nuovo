/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { ContainerTipologiaContenutoAppDto } from './ContainerTipologiaContenutoAppDto';
import type { StileAreaDto } from './StileAreaDto';

export type StileHomeDto = {
    header?: StileAreaDto | null;
    allertaMeteo?: StileAreaDto | null;
    containerInEvidenza?: ContainerTipologiaContenutoAppDto | null;
};

