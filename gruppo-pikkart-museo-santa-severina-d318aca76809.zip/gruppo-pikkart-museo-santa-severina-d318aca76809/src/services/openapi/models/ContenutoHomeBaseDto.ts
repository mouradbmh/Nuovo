/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { ContainerTipologiaContenutoAppDto } from './ContainerTipologiaContenutoAppDto';
import type { IndiceContenutoDto } from './IndiceContenutoDto';

export type ContenutoHomeBaseDto = {
    container?: ContainerTipologiaContenutoAppDto | null;
    contenuti?: Array<IndiceContenutoDto>;
};

