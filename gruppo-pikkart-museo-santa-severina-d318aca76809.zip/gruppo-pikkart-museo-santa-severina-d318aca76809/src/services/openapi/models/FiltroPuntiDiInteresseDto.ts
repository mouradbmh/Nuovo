/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { FiltroTipologieDto } from './FiltroTipologieDto';

export type FiltroPuntiDiInteresseDto = (FiltroTipologieDto & {
    accessoGratuito?: boolean | null;
});

