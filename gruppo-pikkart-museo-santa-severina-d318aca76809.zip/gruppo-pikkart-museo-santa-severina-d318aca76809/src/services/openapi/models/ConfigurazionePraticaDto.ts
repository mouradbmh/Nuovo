/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { ConfigurazioneProssimiPassiDto } from './ConfigurazioneProssimiPassiDto';
import type { ConfigurazioneVarianteDto } from './ConfigurazioneVarianteDto';
import type { ModalitaPagamentoDto } from './ModalitaPagamentoDto';

export type ConfigurazionePraticaDto = {
    uniqueId?: string | null;
    archetipoUniqueId?: string;
    titolo?: string | null;
    descrizione?: string | null;
    servizioEnteUniqueId?: string;
    prevedePagamentoDurante?: boolean | null;
    prevedePagamentoDopo?: boolean | null;
    prevedePerfezionamento?: boolean | null;
    istruzioniPagamentoDurante?: string | null;
    istruzioniPagamentoDopo?: string | null;
    importoFissoDurante?: number | null;
    importoFissoDopo?: number | null;
    testoInformativo?: string | null;
    nomeFaseDurante?: string;
    nomeFaseDopo?: string;
    testoPulsanteAvanzamentoFase?: string;
    visibileOnlineDa?: string;
    visibileOnlineA?: string;
    visibileOnline?: boolean;
    configurazioniModalitaPagamento?: Array<ModalitaPagamentoDto> | null;
    configurazioniVarianti?: Array<ConfigurazioneVarianteDto> | null;
    configurazioniProssimiPassi?: Array<ConfigurazioneProssimiPassiDto> | null;
};

