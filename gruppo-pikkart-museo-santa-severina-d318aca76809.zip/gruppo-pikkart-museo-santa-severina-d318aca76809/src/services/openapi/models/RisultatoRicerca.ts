/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { DatiRicerca } from './DatiRicerca';

export type RisultatoRicerca = {
    data?: DatiRicerca;
    currentPage?: number;
    totalPages?: number;
    totalCount?: number;
    pageSize?: number;
    hasPreviousPage?: boolean;
    hasNextPage?: boolean;
};

