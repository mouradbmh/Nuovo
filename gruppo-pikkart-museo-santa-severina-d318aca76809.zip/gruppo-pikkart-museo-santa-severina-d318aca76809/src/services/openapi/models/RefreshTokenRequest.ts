/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type RefreshTokenRequest = {
    token?: string;
    refreshToken?: string;
};

