/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type ElementoRicerca = {
    contenutoUniqueId?: string;
    nomeEntita?: string;
    titolo?: string;
    descrizione?: string | null;
    priorita?: number;
};

