/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type ActivityLogDto = {
    time?: string;
    userId?: string;
    user?: string;
    entityFullName?: string;
    entityName?: string;
    entityDescription?: string | null;
    eventType?: string;
};

