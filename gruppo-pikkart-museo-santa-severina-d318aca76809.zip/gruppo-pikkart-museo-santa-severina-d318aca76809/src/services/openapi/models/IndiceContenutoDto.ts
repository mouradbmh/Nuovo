/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type IndiceContenutoDto = {
    uniqueId?: string;
    lng?: number | null;
    lat?: number | null;
    dataOraFine?: string | null;
    dataOraInizio?: string | null;
    descrizioneBreve?: string | null;
    nomeEntita?: string;
    titolo?: string;
    urlImmagine?: string | null;
};

