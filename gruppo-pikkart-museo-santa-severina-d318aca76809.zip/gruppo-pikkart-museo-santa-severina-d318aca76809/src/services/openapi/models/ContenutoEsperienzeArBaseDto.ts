
export type ContenutoEsperienzeArBaseDto = {
    uniqueId: string,
    tipologiaContenutoApp: {
        nomeEntita: string
        container: {
            backColor: string
            coloreDescrizioneItem: string
            coloreTitoloItem: string
            coloreTitoloTipologia: string
        }
        traduzioni: {
            nome: string
        }[]
    },
    consigliata: boolean,
    tecnologiaAr: string,
    traduzioni:
    {
        titolo: string,
        istruzioni: string
    }[],
    immagineUrl: string
    immagini: {
        traduzioni: {
            titolo: string,
            descrizione: string
        }[],
        fileUrl: string
    }[],
    arCmsElementId: string
    rilevanza: number

}