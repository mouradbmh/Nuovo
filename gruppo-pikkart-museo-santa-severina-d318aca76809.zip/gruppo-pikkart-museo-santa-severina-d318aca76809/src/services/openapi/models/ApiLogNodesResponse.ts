/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { PaginationResponseOfApiLogNodeDto } from './PaginationResponseOfApiLogNodeDto';

export type ApiLogNodesResponse = PaginationResponseOfApiLogNodeDto;

