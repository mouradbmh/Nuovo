/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { RecipientKeyDto } from './RecipientKeyDto';

export type TenantSignedMessageDto = {
    message: string;
    authorSignature: string;
    authorId: string;
    recipientKeys?: Array<RecipientKeyDto>;
};

