/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type UpdateRolePermissionsRequest = {
    roleId: string;
    permissions: Array<string>;
};

