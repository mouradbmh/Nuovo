/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type ResetPasswordRequest = {
    email?: string | null;
    password?: string | null;
    token?: string | null;
};

