/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type AutorizzazionePersonaPubblicaDto = {
    username?: string;
    personaPubblicaUniqueId?: string;
    personaPubblicaNome?: string;
    personaPubblicaCognome?: string;
    unitaOrganizzativaUniqueId?: string;
    unitaOrganizzativaDenominazione?: string;
    servizioEnteUniqueId?: string;
    servizioEnteTitolo?: string;
};

