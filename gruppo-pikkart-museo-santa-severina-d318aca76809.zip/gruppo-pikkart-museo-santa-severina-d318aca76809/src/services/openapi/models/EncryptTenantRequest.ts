/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type EncryptTenantRequest = {
    enabled?: boolean;
};

