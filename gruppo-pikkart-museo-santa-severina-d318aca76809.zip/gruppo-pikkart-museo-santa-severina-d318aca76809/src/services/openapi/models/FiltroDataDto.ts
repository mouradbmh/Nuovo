/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type FiltroDataDto = {
    da?: string | null;
    'a'?: string | null;
};

