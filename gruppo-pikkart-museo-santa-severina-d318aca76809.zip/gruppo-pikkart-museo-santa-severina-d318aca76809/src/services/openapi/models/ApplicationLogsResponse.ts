/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { PaginationResponseOfApplicationReadLogDto } from './PaginationResponseOfApplicationReadLogDto';

export type ApplicationLogsResponse = PaginationResponseOfApplicationReadLogDto;

