/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type ApiRuntimeLogDto = {
    uniqueId?: string | null;
    requestTime?: string;
    requestJson?: string;
    responseJson?: string | null;
    responseLength?: number | null;
    processTime?: number | null;
    userUniqueId?: string | null;
    user?: string | null;
    requestHeaders?: string | null;
    responseHeaders?: string | null;
};

