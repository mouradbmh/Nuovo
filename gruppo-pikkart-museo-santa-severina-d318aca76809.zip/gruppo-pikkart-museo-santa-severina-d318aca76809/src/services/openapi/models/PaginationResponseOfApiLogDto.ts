/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { ApiLogDto } from './ApiLogDto';

export type PaginationResponseOfApiLogDto = {
    data?: Array<ApiLogDto>;
    currentPage?: number;
    totalPages?: number;
    totalCount?: number;
    pageSize?: number;
    hasPreviousPage?: boolean;
    hasNextPage?: boolean;
};

