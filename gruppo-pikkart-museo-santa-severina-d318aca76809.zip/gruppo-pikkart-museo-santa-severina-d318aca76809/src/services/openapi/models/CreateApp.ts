/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type CreateApp = {
    appId?: string;
    appName?: string;
};

