/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { ArGeoCoordDto } from './ArGeoCoordDto';
import type { MessaggioOnBoardingDto } from './MessaggioOnBoardingDto';
import type { ProfiloAppDto } from './ProfiloAppDto';
import type { StileAreaDto } from './StileAreaDto';
import type { StileBottoneDto } from './StileBottoneDto';
import type { StileContenutoDto } from './StileContenutoDto';
import type { StileFontDto } from './StileFontDto';
import type { StileHomeDto } from './StileHomeDto';
import type { StileProfilazioneDto } from './StileProfilazioneDto';
import type { StileRicercaDto } from './StileRicercaDto';
import type { StileSettingsDto } from './StileSettingsDto';

export type ConfigurazioneAppDto = {
    nome?: string | null;
    payoff?: string | null;
    urlLogo?: string | null
    messaggioHome?: string | null;
    mostraAllertaMeteo?: boolean;
    urlAllertaMeteo?: string | null;
    lingue?: Array<string> | null;
    messaggiOnBoarding?: Array<MessaggioOnBoardingDto> | null;
    arGeoCoords?: Array<ArGeoCoordDto> | null;
    profiliUtente?: Array<ProfiloAppDto> | null;
    stile?: StileAreaDto | null;
    bottomBar?: StileAreaDto | null;
    bottonePrimario?: StileBottoneDto | null;
    bottonePrimarioSelezionato?: StileBottoneDto | null;
    bottoneSecondario?: StileBottoneDto | null;
    bottoneSecondarioSelezionato?: StileBottoneDto | null;
    bottoneDisabilitato?: StileBottoneDto | null;
    tab?: StileFontDto | null;
    tabSelezionato?: StileFontDto | null;
    progressBar?: StileAreaDto | null;
    profilazione?: StileProfilazioneDto | null;
    home?: StileHomeDto | null;
    ricerca?: StileRicercaDto | null;
    contenuto?: StileContenutoDto | null;
    settings?: StileSettingsDto | null;
    applicationAuth?: string,
    urlTerminiDiServizio?: string,
    urlPrivacyPolicy?: string;
    urlApplicazioneWeb?: string;
    registrazioneUtente?: boolean;
    autenticazioneTramiteIdentitaDigitale?: boolean;
    autenticazioneBasic?: boolean;
};

