/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { ApiLogNodeDto } from './ApiLogNodeDto';

export type PaginationResponseOfApiLogNodeDto = {
    data?: Array<ApiLogNodeDto>;
    currentPage?: number;
    totalPages?: number;
    totalCount?: number;
    pageSize?: number;
    hasPreviousPage?: boolean;
    hasNextPage?: boolean;
};

