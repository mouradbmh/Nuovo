/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type UserDetailsDto = {
    id?: string;
    userName?: string | null;
    firstName?: string | null;
    lastName?: string | null;
    email?: string | null;
    isActive?: boolean;
    emailConfirmed?: boolean;
    phoneNumber?: string | null;
    imageUrl?: string | null;
    cf?: string | null;
};

