/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type CriterioRicerca = {
    pageNumber?: number;
    pageSize?: number;
    testo?: string;
    entita?: Array<string> | null;
    argomentiSlug?: Array<string> | null;
};

