/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type ApiLogDto = {
    uniqueId?: string;
    requestTime?: string;
    requestLength?: number;
    requestType?: string;
    nodeUniqueId?: string;
    node?: string;
    domainUniqueId?: string;
    domain?: string;
    responseLength?: number;
    processTime?: number;
    resource?: string;
    success?: boolean;
    requestJson?: string;
    user?: string | null;
    requestHeaders?: string | null;
    responseHeaders?: string | null;
};

