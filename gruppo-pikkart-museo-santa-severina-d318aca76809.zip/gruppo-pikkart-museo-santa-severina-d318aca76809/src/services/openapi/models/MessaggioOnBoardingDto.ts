/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type MessaggioOnBoardingDto = {
    titolo?: string | null;
    messaggio?: string;
    urlImmagine?: string | null;
};

