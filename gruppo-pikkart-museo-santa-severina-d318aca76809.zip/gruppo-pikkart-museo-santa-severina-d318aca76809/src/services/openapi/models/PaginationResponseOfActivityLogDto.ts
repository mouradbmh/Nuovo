/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { ActivityLogDto } from './ActivityLogDto';

export type PaginationResponseOfActivityLogDto = {
    data?: Array<ActivityLogDto>;
    currentPage?: number;
    totalPages?: number;
    totalCount?: number;
    pageSize?: number;
    hasPreviousPage?: boolean;
    hasNextPage?: boolean;
};

