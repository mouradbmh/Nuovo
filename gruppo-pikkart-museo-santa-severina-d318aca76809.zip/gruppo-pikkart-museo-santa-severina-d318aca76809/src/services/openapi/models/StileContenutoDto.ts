/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { ContainerTipologiaContenutoAppDto } from './ContainerTipologiaContenutoAppDto';
import type { StileEventoDto } from './StileEventoDto';
import type { StileFontDto } from './StileFontDto';
import type { StileItinerarioDto } from './StileItinerarioDto';
import { StilePOIDto } from './StilePOIDto';

export type StileContenutoDto = {
    coloreTitoloParagrafo?: string | null;
    link?: StileFontDto | null;
    containerContenutiImmersivi?: ContainerTipologiaContenutoAppDto | null;
    containerContenutiAr?: ContainerTipologiaContenutoAppDto | null;
    containerContenutiCorrelati?: ContainerTipologiaContenutoAppDto | null;
    evento?: StileEventoDto | null;
    puntoDiInteresse?: StilePOIDto | null
    itinerario?: StileItinerarioDto | null;
};

