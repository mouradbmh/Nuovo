/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type ApplicationReadLogDto = {
    id?: number;
    timeStamp?: string;
    message?: string | null;
    level?: string | null;
    exception?: string | null;
    properties?: string | null;
    requestId?: string | null;
    username?: string | null;
    category?: string | null;
};

