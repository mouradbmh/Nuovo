/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { AppuntamentoDto } from './AppuntamentoDto';

export type DisponibilitaDto = {
    uniqueId?: string;
    inizio?: string;
    fine?: string;
    ricorrenzaUniqueId?: string | null;
    appuntamento?: AppuntamentoDto | null;
};

