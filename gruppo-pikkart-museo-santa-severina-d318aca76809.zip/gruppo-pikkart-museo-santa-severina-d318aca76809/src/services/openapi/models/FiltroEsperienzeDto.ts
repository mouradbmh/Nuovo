/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { FiltroTipologieDto } from './FiltroTipologieDto';

export type FiltroEsperienzeDto = (FiltroTipologieDto & {
    durata?: Array<string> | null;
});

