/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { UserRoleDto } from './UserRoleDto';

export type UserRolesRequest = {
    userRoles?: Array<UserRoleDto>;
};

