/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { CodiceMomento } from './CodiceMomento';

export type ModalitaPagamentoDto = {
    uniqueId?: string;
    codiceMomento?: CodiceMomento;
    modalitaPagamentoUniqueId?: string;
};

