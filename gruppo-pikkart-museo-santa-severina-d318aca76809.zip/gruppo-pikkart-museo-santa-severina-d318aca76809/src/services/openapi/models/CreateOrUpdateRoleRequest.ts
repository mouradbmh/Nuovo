/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type CreateOrUpdateRoleRequest = {
    id?: string | null;
    name: string;
    code?: string;
    description?: string | null;
};

