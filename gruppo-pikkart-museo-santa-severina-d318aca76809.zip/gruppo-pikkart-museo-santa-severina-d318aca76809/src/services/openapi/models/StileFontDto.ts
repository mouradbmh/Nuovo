/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type StileFontDto = {
    coloreFronte?: string | null;
};

