/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { StileBottoneDto } from './StileBottoneDto';

export type StileSettingsDto = {
    comuneSelezionato?: StileBottoneDto | null;
};

