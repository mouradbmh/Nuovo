/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type TenantStatsDto = {
    day?: string;
    requestsCount?: number;
    bandwidthCount?: number;
    totalProcessTime?: number;
    averageProcessTime?: number;
    errorsCount?: number;
    storageLength?: number;
};

