/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { ElementoArgomenti } from './ElementoArgomenti';
import type { ElementoEntita } from './ElementoEntita';
import type { ElementoRicerca } from './ElementoRicerca';

export type DatiRicerca = {
    risultati?: Array<ElementoRicerca>;
    argomenti?: Array<ElementoArgomenti>;
    entita?: Array<ElementoEntita>;
};

