/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { FiltroTipologieDto } from './FiltroTipologieDto';

export type FiltroItinerariDto = (FiltroTipologieDto & {
    durata?: Array<string> | null;
    difficolta?: Array<string> | null;
    percorribilita?: Array<string> | null;
});

