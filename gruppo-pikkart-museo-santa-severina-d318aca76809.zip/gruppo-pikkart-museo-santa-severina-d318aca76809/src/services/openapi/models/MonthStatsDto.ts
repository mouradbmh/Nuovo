/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type MonthStatsDto = {
    apiUsage?: number;
    bandwidthUsage?: number;
    fileStorageUsage?: number;
};

