/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export enum CodiceMomento {
    '_1' = 1,
    '_2' = 2,
}
