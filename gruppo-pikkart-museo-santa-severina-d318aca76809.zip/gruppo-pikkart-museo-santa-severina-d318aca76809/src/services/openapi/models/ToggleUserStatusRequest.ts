/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type ToggleUserStatusRequest = {
    activateUser?: boolean;
    userId?: string | null;
};

