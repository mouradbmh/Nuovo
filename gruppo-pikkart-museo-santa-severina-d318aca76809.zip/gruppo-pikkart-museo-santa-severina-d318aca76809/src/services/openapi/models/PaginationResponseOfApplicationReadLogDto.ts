/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { ApplicationReadLogDto } from './ApplicationReadLogDto';

export type PaginationResponseOfApplicationReadLogDto = {
    data?: Array<ApplicationReadLogDto>;
    currentPage?: number;
    totalPages?: number;
    totalCount?: number;
    pageSize?: number;
    hasPreviousPage?: boolean;
    hasNextPage?: boolean;
};

