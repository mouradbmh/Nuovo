/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { CategoryPermissionsDto } from './CategoryPermissionsDto';

export type FeaturePermissionsDto = {
    id?: string;
    name?: string;
    priority?: number;
    category?: string;
    description?: string;
    moduleName?: string;
    defaultTenantOnly?: boolean;
    dependencies?: Array<string>;
    isAlwaysEnabled?: boolean;
    isEnabled?: boolean;
    categories?: Array<CategoryPermissionsDto>;
};

