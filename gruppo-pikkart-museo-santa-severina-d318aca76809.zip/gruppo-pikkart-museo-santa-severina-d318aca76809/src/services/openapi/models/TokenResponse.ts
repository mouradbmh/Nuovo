/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type TokenResponse = {
    token?: string;
    refreshToken?: string;
    expiresIn?: number;
    refreshTokenExpiryTime?: string;
};

