/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type ProfiloAppDto = {
    id?: string;
    nome?: string;
    descrizione?: string | null;
    iconaUrl?: string | null;
};

