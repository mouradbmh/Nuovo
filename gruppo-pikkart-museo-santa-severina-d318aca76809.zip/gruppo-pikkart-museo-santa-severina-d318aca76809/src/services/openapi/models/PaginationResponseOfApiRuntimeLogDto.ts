/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { ApiRuntimeLogDto } from './ApiRuntimeLogDto';

export type PaginationResponseOfApiRuntimeLogDto = {
    data?: Array<ApiRuntimeLogDto>;
    currentPage?: number;
    totalPages?: number;
    totalCount?: number;
    pageSize?: number;
    hasPreviousPage?: boolean;
    hasNextPage?: boolean;
};

