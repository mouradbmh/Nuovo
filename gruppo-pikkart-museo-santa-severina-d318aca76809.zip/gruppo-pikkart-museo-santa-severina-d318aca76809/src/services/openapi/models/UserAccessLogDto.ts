/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type UserAccessLogDto = {
    accessDate?: string;
    loginSuccess?: boolean;
};

