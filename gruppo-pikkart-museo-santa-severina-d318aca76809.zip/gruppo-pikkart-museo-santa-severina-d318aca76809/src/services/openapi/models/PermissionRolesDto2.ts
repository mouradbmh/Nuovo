/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { RoleDto2 } from './RoleDto2';

export type PermissionRolesDto2 = {
    code?: string;
    name?: string;
    description?: string;
    category?: string;
    isSecurityCritical?: boolean;
    roles?: Array<RoleDto2>;
};

