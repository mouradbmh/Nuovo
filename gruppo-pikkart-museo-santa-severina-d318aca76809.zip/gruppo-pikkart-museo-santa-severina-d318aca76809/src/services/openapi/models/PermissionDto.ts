/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type PermissionDto = {
    code?: string;
    name?: string;
    description?: string;
    category?: string;
    isSecurityCritical?: boolean;
    impliedBy?: Array<PermissionDto>;
    featureIds?: Array<string>;
    policyName?: string;
};

