/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type FileUploadRequest = {
    name: string;
    extension: string;
    data: string;
};

