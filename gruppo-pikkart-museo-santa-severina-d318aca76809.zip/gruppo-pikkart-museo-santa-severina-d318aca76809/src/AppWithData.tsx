import '@/App.css'
import Routing from '@/components/Routing'
import { AuthProvider } from '@/components/AuthProvider'
import { BrowserRouter, HashRouter } from 'react-router-dom'
import { NavigationProvider } from '@/components/NavigationProvider'
import { DataProvider } from '@ai4/data-request'
import AppProvider from '@/components/AppProvider/AppProvider'
import GlobalLayout from '@/components/GlobalLayout'
import { ProfileProvider } from '@/components/ProfileProvider'
import { useCallback, useEffect, useMemo } from 'react'
import { useKey } from './hooks/useKeyContext'
import { useLoader } from './hooks/useLoader'
import Loader from './components/Loader'
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css"
import { SafeArea } from 'capacitor-plugin-safe-area';
import { Capacitor } from '@capacitor/core'
// import { ProfileSetupScreen } from './screens/ProfileSetup'


// type ScreenSize = {
//   width: number,
//   height: number
// }

function AppWithData() {
  const { key, configs, authDomain } = useKey()
  const dom = 'dom';
  // const config = cfg
  const { visible, message, percentage } = useLoader()


  useEffect(() => {
    if(Capacitor.getPlatform() === 'ios'){
      void SafeArea.getSafeAreaInsets().then(({ insets }) => {
        for (const [key, value] of Object.entries(insets)) {
          document.documentElement.style.setProperty(
            `--safe-area-${key}`,
            `${value}px`,
          );
        }
      });
    }
  }, []);


  // const getCurrentDimension = () => {
  //   return {
  //     width: window.innerWidth,
  //     height: window.innerHeight
  //   } as ScreenSize
  // }

  // const [screenSize, setScreenSize] = useState(getCurrentDimension())

  // useEffect(() => {
  //   const updateDimension = () => {
  //     setScreenSize(getCurrentDimension())
  //   }
  //   window.addEventListener('resize', updateDimension);


  //   return (() => {
  //     window.removeEventListener('resize', updateDimension);
  //   })
  // }, [screenSize])

  const record = useCallback(() => {
    return {
      'dom': {
        base: configs?.URL_AI4CLOUD_ENDPOINT as string,
        xAPIKey: key
      },
      'auth': {
        base: authDomain + '/',
        xAPIKey: key
      },
    }
  }, [configs?.URL_AI4CLOUD_ENDPOINT, key, authDomain])

  const getRandomKey = useCallback(() => {
    if (key && authDomain) {
      const randomValues = new Uint32Array(key.length + authDomain.length);

      return window.crypto.getRandomValues(randomValues)[0]
    }
  }, [authDomain, key])

  const isCordova = useMemo(() => {
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-ignore
    // eslint-disable-next-line @typescript-eslint/no-unsafe-member-access
    if (window.cordova && window.cordova.version) {
      //console.log("we are in cordova");
      return true;
    }
    //console.log("we are NOT in cordova");
    return false;
  }, []);

  // console.log('width', window.innerWidth)

  return (
    <>
      {visible && (
        <div style={{ maxWidth: 1300, zIndex: 5000, position: 'fixed', top: 0, backgroundColor: 'white', width: '100%', height: '100%', marginLeft: 0 }}>
          <Loader
            size={150}
            percentage={percentage}
            message={message}
          />
        </div>
      )}

      <ToastContainer
        position="top-center"
        autoClose={5000}
        hideProgressBar={true}
        newestOnTop={false}
        closeOnClick
        rtl={false}
        pauseOnFocusLoss
        draggable
        pauseOnHover
        theme="light"
        closeButton={false}
      />

      <DataProvider
        domain={dom}
        authDomain={'auth'}
        domains={record()}
        onContinueSession={() => null}
        onInvalidAccess={() => null}
        key={getRandomKey()}
        authPaths={{
          tokens: 'wp-json/wp/v2/api/tokens/get',
          refreshToken: 'wp-json/wp/v2/api/tokens/refresh',
        }}
      >
        <AppProvider>
          <AuthProvider>
            <ProfileProvider>
              {isCordova && <HashRouter>
                <NavigationProvider>
                  <GlobalLayout>
                    <Routing />
                  </GlobalLayout>
                </NavigationProvider>
              </HashRouter>}
              {!isCordova && <BrowserRouter>
                <NavigationProvider>
                  <GlobalLayout>
                    <Routing />
                  </GlobalLayout>
                </NavigationProvider>
              </BrowserRouter>}
            </ProfileProvider>
          </AuthProvider>
        </AppProvider>
      </DataProvider>
    </>
  );
}

export default AppWithData;
