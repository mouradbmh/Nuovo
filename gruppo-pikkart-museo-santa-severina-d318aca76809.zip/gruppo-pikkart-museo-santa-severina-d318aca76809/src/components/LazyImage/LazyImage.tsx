// import React from 'react'
import { LazyLoadImage } from 'react-lazy-load-image-component'
import { CSSProperties } from 'react'
import classes from './LazyImage.module.css'
import defaultPlaceholderSrc from '@/assets/defaultPlaceholder.svg'
import 'react-lazy-load-image-component/src/effects/black-and-white.css';

type LazyImageProps = {
    className?:string,
    key?:number
    style?:CSSProperties
    src:string,
    alt?:string
  }

const LazyImage = ({
  className,
  key,
  src,
  alt,
  style
}: LazyImageProps) => {

  return (
        <LazyLoadImage
          effect={'black-and-white'}
          {...{key,wrapperClassName:classes.wrapperComponent,className,src,alt, placeholderSrc: defaultPlaceholderSrc, style}}
        />
  )
}

export default LazyImage;
