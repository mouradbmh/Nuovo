import { ReactNode, createContext, useEffect, useMemo, useState } from "react";
import { gql, useDataRequest } from "@ai4/data-request";
// import { useProfile } from "@/hooks/useProfile";
import { ArExperience, ArExperienceTypes } from "./ArTypes";
import { useTranslation } from "react-i18next";

export type ArContextType = {
  data?: ArExperience,
  loading: boolean,
  error?: any,
  experienceType: ArExperienceTypes[],
  types: {
    uid?: string,
    name?: string,
    rilevanza?: number,
  }[]
};

export const ArContext = createContext<ArContextType>({} as ArContextType);

type Props = {
  children: JSX.Element | ReactNode;
};

const ArProvider = ({ children }: Props) => {

  const { useLazyQuery } = useDataRequest();

  const { i18n } = useTranslation();

  // const AR_QUERY = gql(`
  //   query {
  //       esperienzeArQuery {
  //       esperienzeAR {
  //       lista {
  //       uniqueId
  //       tipologiaContenutoApp {
  //       traduzioni {
  //       nome
  //       }
  //       }
  //       consigliata
  //       tecnologiaAr
  //       traduzioni {
  //           titolo
  //           istruzioni
  //           }
  //           immagineUrl
  //           immagini {
  //           traduzioni {
  //           titolo
  //           descrizione
  //           }
  //           fileUrl
  //           }
  //           arCmsElementId
  //           }
  //           }
  //           }
  //          }
  //   `);

  const AR_QUERY = gql(`
    query {
      esperienzeArQuery {
        esperienzeAR {
          lista {
            uniqueId
            tipologiaContenutoApp {
              uniqueId
              nomeEntita
              tipologiaLayout
              rilevanza
              container{
                backColor
                coloreTitoloItem
                coloreDescrizioneItem
                coloreTitoloTipologia
                }
              traduzioni {
                nome
              }
            }
            consigliata
            tecnologiaAr
            traduzioni {
              titolo
              istruzioni
            }
            immagineUrl
            immagini {
              traduzioni {
                titolo
                descrizione
              }
              fileUrl
            }
            arCmsElementId
            rilevanza
            allegati {
              traduzioni {
                uniqueId
                titolo
                descrizione
              }
              file {
                fileExt
                fileLength
                fileUrl
              }
            }
            immagini {
              traduzioni {
                titolo
                descrizione
              }
              file {
                fileExt
                fileLength
                fileUrl
              }
            }
          }
        }
      }
    }`);

  const [fetch, { loading, data, error }] = useLazyQuery<ArExperience>(AR_QUERY);
  const [result, setResult] = useState<ArExperience>();
  const [experienceType, setExperienceType] = useState<ArExperienceTypes[]>([]);

  useEffect(() => {
    if (data) {
      return;
    }

    void fetch({
      context: {
        headers: {
          'Content-Language': i18n.language.split('-')[0]
        }
      },
    });
  }, [fetch, data]);

  useEffect(() => {
    if (!data) {
      return;
    }
    setResult(data);
    console.log(data)
  }, [data]);


  
  useEffect(() => {
    if (data && data?.esperienzeArQuery?.esperienzeAR?.lista.length > 0) {
      data.esperienzeArQuery.esperienzeAR.lista.map(element => {
        // return { uniqueId: element.tipologiaContenutoApp.uniqueId, nome: element.tipologiaContenutoApp.traduzioni[0].nome}
       
        if(experienceType.filter(experience => experience.uniqueId === element.tipologiaContenutoApp.uniqueId).length === 0){
          setExperienceType(result => [...result, { uniqueId: element.tipologiaContenutoApp.uniqueId, nome: element.tipologiaContenutoApp.traduzioni[0].nome}])
        }
        
      })
    }
    
  }, [data]);


  const types = useMemo(() => {
    if (data && data?.esperienzeArQuery?.esperienzeAR?.lista.length > 0) {

      return [...new Map(data.esperienzeArQuery.esperienzeAR.lista.map(element =>
        [element.tipologiaContenutoApp.uniqueId, {
          uid: element.tipologiaContenutoApp.uniqueId,
          name: element.tipologiaContenutoApp.traduzioni[0].nome,
          riservato: element.tipologiaContenutoApp.rilevanza === null ? 0 : element.tipologiaContenutoApp.rilevanza,
        }])).values()];
    }
    return [];
  }, [data]);

  const value: ArContextType = {
    data: result,
    loading,
    error,
    experienceType: experienceType,
    types
  };

  return (
    <ArContext.Provider value={value}>
      {children}
    </ArContext.Provider>
  );
};

export default ArProvider;