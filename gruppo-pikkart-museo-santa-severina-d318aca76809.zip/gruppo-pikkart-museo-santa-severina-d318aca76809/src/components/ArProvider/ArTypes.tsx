export type ArExperience = {
    esperienzeArQuery: {
        esperienzeAR: {
            lista: {
                uniqueId: string,
                tipologiaContenutoApp: {
                    uniqueId: string
                    rilevanza: number
                    nomeEntita: string
                    container: {
                        backColor: string
                        coloreDescrizioneItem: string
                        coloreTitoloItem: string
                        coloreTitoloTipologia: string
                    }
                    traduzioni:
                    {
                        nome: string
                    }[]
                },
                consigliata: boolean,
                tecnologiaAr: string,
                traduzioni:
                {
                    titolo: string,
                    istruzioni: string
                }[],
                immagineUrl: string
                immagini: {
                    traduzioni: {
                        titolo: string,
                        descrizione: string
                    }[],
                    fileUrl: string
                }[],
                arCmsElementId: string
                rilevanza: number
            }[]
        }
    }
}

export type ArSingleExperience = {
    uniqueId: string,
    tipologiaContenutoApp: {
        uniqueId: string
        rilevanza: number
        nomeEntita: string
        container: {
            backColor: string
            coloreDescrizioneItem: string
            coloreTitoloItem: string
            coloreTitoloTipologia: string
        }
        traduzioni:
        {
            nome: string
        }[]
    },
    consigliata: boolean,
    tecnologiaAr: string,
    traduzioni:
    {
        titolo: string,
        istruzioni: string
    }[],
    immagineUrl: string
    immagini: {
        traduzioni: {
            titolo: string,
            descrizione: string
        }[],
        fileUrl: string
    }[],
    arCmsElementId: string
    rilevanza: number

}

export type ArDetails = {
    esperienzeArQuery: {
        esperienzeAR: {
            lista: {
                allegati: {
                    file: {
                        fileExt: string
                        fileLength: number
                        fileUrl: string
                    }
                    traduzioni: {
                        uniqueId: string
                        titolo: string
                        descrizione: string
                    }[]

                }[]
                uniqueId: string,
                tipologiaContenutoApp: {
                    uniqueId: string
                    rilevanza: number
                    nomeEntita: string
                    container: {
                        backColor: string
                        coloreDescrizioneItem: string
                        coloreTitoloItem: string
                        coloreTitoloTipologia: string
                    }
                    traduzioni:
                    {
                        nome: string
                    }[]
                },
                consigliata: boolean,
                tecnologiaAr: string,
                traduzioni:
                {
                    titolo: string,
                    istruzioni: string
                }[],
                immagineUrl: string
                immagini: {
                    traduzioni: {
                        titolo: string,
                        descrizione: string
                    }[],
                    fileUrl: string
                }[],
                arCmsElementId: string
                rilevanza: number
            }[]

        }
    }
}

export type ArExperienceTypes = {
    uniqueId: string
    nome: string
}