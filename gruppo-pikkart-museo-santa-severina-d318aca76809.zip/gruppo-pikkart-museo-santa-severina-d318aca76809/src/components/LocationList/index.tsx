import LocationList, { LocationListProps } from "@/components/LocationList/LocationList";

export default LocationList;
export type { LocationListProps };