import { styled } from "styled-components";
import LocationComponent, { LocationComponentProps } from "@/components/LocationComponent"

export interface LocationListProps {
  backColor?: string,
  locations?: LocationComponentProps[];
}

const StyledDiv = styled.div<{ backcolor?: string }>`
  ${props => props.backcolor !== undefined ? `background-color: ${props.backcolor};` : '' }
`;

const LocationList = ({
  backColor,
  locations,
}: LocationListProps) => {
  return (
    <StyledDiv backcolor={backColor}>
      {
        locations?.map((loc, index) => {
          // console.log(loc)
          return (
            <LocationComponent {...loc} key={index} />
          );
        })
      }
    </StyledDiv>
  );
}

export default LocationList;