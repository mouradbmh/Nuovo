import classes from '@/components/CarouselTitleBar/carouselTitleBar.module.css'
import TextComponent, { TextProps } from '@/components/TextComponent'
import { Link } from 'react-router-dom';

export interface CarouselTitleBarProps {
  title: TextProps;
  description?: TextProps;
  link?: TextProps & {
    href: string;
  };
  centerTitle?: boolean;
}

const CarouselTitleBar = ({
  title,
  description,
  link,
  centerTitle = false,
}: CarouselTitleBarProps) => {
  return (
    <div className={centerTitle ? [classes.carousel_title_bar, classes.title_centered].join(' ') : classes.carousel_title_bar}>
      <div className={classes.container_left}>
        <TextComponent className={title.className} text_key={title.text_key} color={title.color} text_size={title.text_size} text_line={title.text_line} text_weight={title.text_weight} />
        {
          description !== undefined ? (
            <TextComponent className={title.className} text_key={description.text_key} color={description.color} text_size={description.text_size} text_line={description.text_line} text_weight={description.text_weight} />
          ) : (<></>)
        }
      </div>
      {
        link !== undefined ? (
          <div className={classes.container_right}>
            <Link to={link.href} className={classes.no_underline}>
              <TextComponent className={link.className} text_key={link.text_key} color={link.color} text_size={link.text_size} text_line={link.text_line} text_weight={link.text_weight} />
            </Link>
          </div>
        ) : (<></>)
      }
    </div>
  )

}

export default CarouselTitleBar;