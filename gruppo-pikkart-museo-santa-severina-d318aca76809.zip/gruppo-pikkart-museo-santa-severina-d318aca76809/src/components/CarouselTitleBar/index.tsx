import CarouselTitleBar from "@/components/CarouselTitleBar/CarouselTitleBar";
import { CarouselTitleBarProps } from "@/components/CarouselTitleBar/CarouselTitleBar";

export default CarouselTitleBar;
export type { CarouselTitleBarProps };