import LoginButtonsComponent, { LoginButtonsComponentProps } from "@/components/LoginButtonsComponent/LoginButtonsComponent";

export default LoginButtonsComponent;
export type { LoginButtonsComponentProps };