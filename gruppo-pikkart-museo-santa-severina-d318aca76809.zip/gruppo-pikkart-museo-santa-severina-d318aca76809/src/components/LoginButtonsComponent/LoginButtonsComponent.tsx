import { styled } from "styled-components";
import classes from '@/components/LoginButtonsComponent/loginButtonsComponent.module.css';
import TextComponent from "../TextComponent";
import IconTextButton from "../IconTextButton";
import { useTranslation } from "react-i18next";
import {useAppContext} from "@/hooks/useAppContext.tsx";

export interface LoginButtonsComponentProps {
  className?: string;
  backColor?: string;
  showAnonymousLogin?: boolean;
  onLogIn: () => void;
  register?: boolean
}

const StyledDiv = styled.div<{ backcolor?: string }>`
  ${props => props.backcolor !== undefined ? `background-color: ${props.backcolor};` : ''}
`;

const LoginButtonsComponent = ({
  className,
  backColor,
//  showAnonymousLogin = true,
  onLogIn,
  register = false
}: LoginButtonsComponentProps) => {
  const { t } = useTranslation();

  const { config } = useAppContext();

  return (
    <StyledDiv className={className !== undefined ? [className, classes.buttons_container].join(' ') : classes.buttons_container} backcolor={backColor}>
      <div className={classes.row_container}>
        <TextComponent className={classes.spacing}  // FIXME: rivedere qualora si tolga la traduzione da TextComponent, questi elementi si possono ricombinare.
          text_key={t('privacy1')}
          text_size='tiny'
          text_line='normal' />
        <IconTextButton
          textProps={{
            className: classes.spacing,
            text_key: t('tos'),
            text_size: 'tiny',
            text_line: 'normal',
          }}
          onClick={() => window.open(config?.urlTerminiDiServizio ?? '', '_blank')}
          buttonMode='outline_borderless' />
        <TextComponent className={classes.spacing}
          text_key={t('privacy2')}
          text_size='tiny'
          text_line='normal' />
        <IconTextButton
          textProps={{
            text_key: t('privacy_policy'),
            text_size: 'tiny',
            text_line: 'normal',
          }}
          onClick={() => window.open(config?.urlPrivacyPolicy ?? '', '_blank')}
          buttonMode='outline_borderless' />
        <span>.</span>
      </div>
      <IconTextButton className={classes.button}
        textProps={{
          text_key: register ? t('register') : t('login'),
          text_weight: 'regular',
          color: 'var(--outline-bg)',
        }}
        backColor="var(--emerald-700)"
        padding={{ vertical: 16 }}
        onClick={onLogIn}
      />
      {/* {showAnonymousLogin && (<IconTextButton className={classes.button}
        textProps={{
          text_key: t('without_acc'),
          text_weight: 'semibold',
        }}
        padding={{ vertical: 16 }}
        buttonMode='outline_borderless'
      />)} */}
    </StyledDiv>
  );
};

export default LoginButtonsComponent;