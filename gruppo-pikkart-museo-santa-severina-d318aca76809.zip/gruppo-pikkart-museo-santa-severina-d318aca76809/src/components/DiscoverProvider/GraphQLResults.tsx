import { Activity, ActivityStatus } from "../Reports/ReportsProvider";

export type GraphQLList = {
    __typename: string;
    lista: {
        __typename: string;
        uniqueId: string;
        codice?: string;
        traduzioni: {
            __typename: string;
            nome: string
        }[];
        figli?: {
            __typename: string;
            uniqueId: string;
            codice?: string;
            traduzioni: {
                __typename: string;
                nome: string
            }[];
        }[];
    }[]
}

export type GraphQLSegnalazione = {
    __typename: string;
    segnalazioniMutation:{
        segnalazioni:{
            salva:{
                uniqueId: string
                codice: string,
                titolo: string,
                tipologia: {
                    uniqueId: string,
                    nome: string
                },
                descrizione: string,
                indirizzo: string,
                latitudine: number,
                longitudine: number,
                allegati: string[],
                immagini: string[],
                messaggi: string[],
                autore: {
                    userName: string
                }
                stato: {
                    nome: string
                    uniqueId: string
                }
            }
        }
    }
   
}
export type GraphQLServicesEnte = {
    cartaDeiServiziQuery:{
        __typename: string;
        serviziEnti:{
            __typename: string;
            lista:string[]
        }
    }   
}

export type GraphQLResults = {
    segnalazioniQuery: {
        tipologie: {
            lista: {
                uniqueId: string;
                nome: string;
            }[]
        };
        segnalazioni: {
            lista: Activity[];
        }
    };
    praticheQuery: {
        statiPratiche: {
            lista: {
                nome: ActivityStatus;
                uniqueId?: string
            }[]
        }
    };
    tassonomieQuery: {
        __typename: string;
        adattoA: GraphQLList;
        condizioniDiAccesso: GraphQLList;
    };
    itinerariQuery: {
        __typename: string;
        tipologie: GraphQLList;
        percorribilita: GraphQLList;
        difficolta: GraphQLList;
        durata: GraphQLList;
    };
    esperienzeQuery: {
        __typename: string;
        durata: GraphQLList;
        tipologie: GraphQLList;
    };
    attivitaCommercialiQuery: {
        __typename: string;
        tipologie: GraphQLList;
    };
    prodottiTipiciQuery: {
        __typename: string;
        tipologie: GraphQLList;
    };
    notizieQuery: {
        __typename: string;
        tipologie: GraphQLList;
    };
    eventiQuery: {
        __typename: string;
        tipologie: GraphQLList;
    }
}

export type Filter = {
    filterName: string;
    subfilters: Subfilter[];
}

export type Subfilter = {
    subfilterName: string;
    values: {
        uniqueId: string;
        code?: string;
        text: string;
        figli?: {
            uniqueId: string;
            text: string;
        }[]
    }[];
}

export type FilterSubfilters = {
    filterName: string;
    subfilter: Subfilter;
}

function valuesToSubfilter(values: [string, GraphQLList]): Subfilter {
    return {
        subfilterName: values[0],
        values: values[1].lista.map(e => {
            return {
                uniqueId: e.uniqueId,
                code: e.codice,
                text: e.traduzioni[0]?.nome,
                figli: e.figli?.map<{
                    uniqueId: string;
                    text: string;
                }>(f => {
                    return {
                        uniqueId: f.uniqueId,
                        text: f.traduzioni[0].nome,
                    }
                }),
            };
        })
    };
}

export function resultsToFilters(graphQLResults: GraphQLResults): Filter[] {
    const results: Filter[] = [];

    Object.entries(graphQLResults).forEach(e => {
        const arrayResult: Filter = {
            filterName: e[0],
            subfilters: Object.entries(e[1]).filter((_, i) => i > 0).map(v => valuesToSubfilter(v as [string, GraphQLList])),
        }

        results.push(arrayResult);
    })

    return results;
}