import { Dispatch, MutableRefObject, ReactNode, SetStateAction, createContext, useCallback, useEffect, useMemo, useRef, useState } from "react";
import { gql, useDataRequest } from "@ai4/data-request";
import { FiltroRicercaDto, TipologiaContenutoDto } from "@/services/openapi";
import { Filter, FilterSubfilters, GraphQLResults, resultsToFilters } from "@/components/DiscoverProvider/GraphQLResults";
// eslint-disable-next-line @typescript-eslint/ban-ts-comment
// @ts-ignore
import { Value } from "react-calendar/dist/cjs/shared/types";
import { useLocation } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import i18n from "i18next";
import { useKey } from "@/hooks/useKeyContext";

export type DiscoverContextType = {
  searchResults?: TipologiaContenutoDto[];
  loading?: boolean;
  error?: any;
  filters?: Filter[];
  filtersSubfilters?: FilterSubfilters[];
  loadingFilters?: boolean;
  filtersError?: any;
  refSubfilterStates: MutableRefObject<string[][]>;
  updateSubfilterStates: () => void;
  updateSubfilterConfirmation: () => void;
  selectedDates: Value;
  setSelectedDates: Dispatch<SetStateAction<Value>>;
  selectedFilter: string;
  setSelectedFilter: (filter: string) => void;
  setSearchString: (searchString: string) => void;
  barVisible: boolean;
  setBarVisible: (visibility: boolean) => void;
  searchString: string;
  filterType: FilterType[]
  recentLoading: boolean;
};

export const DiscoverContext = createContext<DiscoverContextType>({} as DiscoverContextType);

export type DiscoverProviderProps = {
  children: JSX.Element | ReactNode;
};

export type FilterType = {
  nome: string,
  nomeEntita: string,
  uniqueId: string,
  urlIcona?: string;
}

const DiscoverProvider = ({ children }: DiscoverProviderProps) => {
  const { useRestRequest, useLazyQuery } = useDataRequest();
  const [searchString, setSearchString] = useState<string>('');
  const [filterType, setFilterType] = useState<FilterType[]>([])
  const { key } = useKey()

  const [fromQuery, setFromQuery] = useState(false)
  const [results, setResults] = useState<TipologiaContenutoDto[]>();

  const [filters, setFilters] = useState<GraphQLResults>();

  const [selectedDates, setSelectedDates] = useState<Value>(null);
  const [selectedFilter, setSelectedFilter] = useState('');
  const refSubfilterSelections = useRef<string[][]>([]);
  const [subfilterState, setSubFilterState] = useState(0);
  const [subfilterConfirmation, setSubfilterConfirmation] = useState(0);
  const [barVisible, setVisible] = useState(true);

  const refFilterChanged = useRef(false);

  const transformedFilters = useRef<Filter[] | undefined>();
  const filtersSubfilters = useRef<FilterSubfilters[] | undefined>();

  const search = useLocation().search;

  const { isLoggedIn } = useAuth();

  const [fetch, { data, loading, error }] = useRestRequest({
    path: 'rest/{ver}/app/ricerca',
    headers: {
      'Content-Type': 'application/json',
      'Content-Language': i18n.language.split('-')[0]
    },
    method: 'POST'
  });

  const [recentFetch, { data: recentData, loading: recentLoading }] = useRestRequest({
    path: 'rest/{ver}/app/contenuti-visti',
    headers: {
      'Content-Type': 'application/json',
      'Content-Language': i18n.language.split('-')[0]
    },
    method: 'GET',
    jwt: true
  })

  const [typesFetch, { data: typesData }] = useRestRequest({
    path: 'rest/{ver}/app/tipologie-contenuti',
    headers: {
      'Content-Type': 'application/json',
      'Content-Language': i18n.language.split('-')[0]
    },
    method: 'GET',
    onError(err) {
      console.log('typesError', err)
    },
    queryString: {
      profiloUtenteUniqueId: localStorage.getItem(key + ".profileId") ?? ''
    }
  })

  useEffect(() => {
    const setupFilter = new URLSearchParams(search).get('filterUrl') ?? '';
    if (selectedFilter === '' && !fromQuery) {
      if (setupFilter && filterType.length > 0) {
        const check = filterType.find(el => el.uniqueId === setupFilter)?.uniqueId;

        if (check) {
          setSelectedFilter(check);
          setFromQuery(true)
        }
      }
    }
  }, [filterType, fromQuery, search, selectedFilter])


  // console.log(filterType)
  useEffect(() => {
    refSubfilterSelections.current = []
  }, [selectedFilter])

  useEffect(() => {
    if (!typesData) {
      void typesFetch()
    }
  }, [typesFetch, typesData])

  useEffect(() => {
    if (typesData !== null && typesData !== undefined) {
      setFilterType((typesData as FilterType[]).reverse())
    }
  }, [typesData])

  const findFilterSelections = (filterName: string, subfilterName: string) => {

    const idx = filtersSubfilters.current?.findIndex(f => f.filterName == filterName && f.subfilter.subfilterName == subfilterName)
    // console.log('filtersubsearch', refSubfilterSelections.current[idx ?? -1], idx, filterName, subfilterName)
    const res = refSubfilterSelections.current[idx ?? -1];
    return res && res.length > 0 ? res : undefined;
  }

  const updateSelectedFilter = (filter: string) => {
    refFilterChanged.current = true;
    setSelectedFilter(filter);
  }

  const updateFilterStates = useCallback(() => {
    setSubFilterState(subfilterState + 1);
  }, [subfilterState])

  const updateFilterConfirmation = useCallback(() => {
    setSubfilterConfirmation(subfilterConfirmation + 1);
  }, [subfilterConfirmation])

  const updateBarVisibility = (visibility: boolean) => {
    setVisible(visibility);
  }

  const EntityToQuery = (query: string | null | undefined) => {
    switch (query) {
      case 'AttivitaCommerciale':
        return 'attivitaCommercialiQuery'

      case 'Esperienza':
        return 'esperienzeQuery'

      case 'Evento':
        return 'eventiQuery'

      case 'Itinerario':
        return 'itinerariQuery'

      case 'Notizia':
        return 'notizieQuery'

      case 'ProdottoTipico':
        return 'prodottiTipiciQuery'

      case 'PuntoDiInteresse':
        return 'puntiDiInteresseQuery'

      default:
        return '';
    }
  }

  useEffect(() => {
    if (isLoggedIn && (searchString === '') && selectedFilter === '') {
      void recentFetch()
      return;
    }
  }, [isLoggedIn, recentFetch, searchString, selectedFilter])

  useEffect(() => {
    // if (searchString == null) {
    //   return;
    // }
    if( data !== undefined || loading){
      return;
    }
    if (selectedFilter !== '' && filterType.length > 0) {

      const datesArray = selectedDates as Date[];

      // console.log('calcolo', EntityToQuery(filterType.find(el => el.uniqueId === selectedFilter)?.nomeEntita));

      const attivitaCommerciali = EntityToQuery(filterType.find(el => el.uniqueId === selectedFilter)?.nomeEntita) == 'attivitaCommercialiQuery' ? {
        tipologie: findFilterSelections(filterType.find(el => el.uniqueId === selectedFilter)?.nomeEntita ?? '', 'tipologie')
      } : undefined;

      const esperienze = EntityToQuery(filterType.find(el => el.uniqueId === selectedFilter)?.nomeEntita) == 'esperienzeQuery' ? {
        tipologie: findFilterSelections(EntityToQuery(filterType.find(el => el.uniqueId === selectedFilter)?.nomeEntita), 'tipologie'),
        durata: findFilterSelections(EntityToQuery(filterType.find(el => el.uniqueId === selectedFilter)?.nomeEntita), 'durata'),
      } : undefined;

      const eventi = EntityToQuery(filterType.find(el => el.uniqueId === selectedFilter)?.nomeEntita) == 'eventiQuery' ? {
        tipologie: findFilterSelections(EntityToQuery(filterType.find(el => el.uniqueId === selectedFilter)?.nomeEntita), 'tipologie'),
      } : undefined;


      const itinerari = EntityToQuery(filterType.find(el => el.uniqueId === selectedFilter)?.nomeEntita) === 'itinerariQuery' ? {
        tipologie: findFilterSelections(EntityToQuery(filterType.find(el => el.uniqueId === selectedFilter)?.nomeEntita) ?? '', 'tipologie'),
        difficolta: findFilterSelections(EntityToQuery(filterType.find(el => el.uniqueId === selectedFilter)?.nomeEntita) ?? '', 'difficolta'),
        durata: findFilterSelections(EntityToQuery(filterType.find(el => el.uniqueId === selectedFilter)?.nomeEntita) ?? '', 'durata'),
        percorribilita: findFilterSelections(EntityToQuery(filterType.find(el => el.uniqueId === selectedFilter)?.nomeEntita) ?? '', 'percorribilita'),
      } : undefined;

      const notizie = EntityToQuery(filterType.find(el => el.uniqueId === selectedFilter)?.nomeEntita) == 'notizieQuery' ? {
        tipologie: findFilterSelections(EntityToQuery(filterType.find(el => el.uniqueId === selectedFilter)?.nomeEntita), 'tipologie'),
      } : undefined;

      const prodottiTipici = EntityToQuery(filterType.find(el => el.uniqueId === selectedFilter)?.nomeEntita) == 'prodottiTipiciQuery' ? {
        tipologie: findFilterSelections(EntityToQuery(filterType.find(el => el.uniqueId === selectedFilter)?.nomeEntita), 'tipologie'),
      } : undefined;

      const puntiDiInteresse = EntityToQuery(filterType.find(el => el.uniqueId === selectedFilter)?.nomeEntita) == 'puntiDiInteresseQuery' ? {
        tipologie: findFilterSelections(EntityToQuery(filterType.find(el => el.uniqueId === selectedFilter)?.nomeEntita) ?? '', 'tipologie'),
      } : undefined;

      // console.log('gli itinerari sono:', itinerari, selectedFilter === 'itinerariQuery')

      const hasParametersSet = (obj: {}) => Object.values(obj).some(v => v != undefined);

      const data: FiltroRicercaDto = {  // FIXME: qualche modo per generalizzare?
        testo: searchString,
        data: selectedDates && datesArray[0] && datesArray[1] ? {
          da: datesArray[0].toISOString(),
          a: datesArray[1].toISOString(),
        } : undefined,
        adattoA: findFilterSelections('tassonomieQuery', 'adattoA'),
        condizioniDiAccesso: findFilterSelections('tassonomieQuery', 'condizioniDiAccesso'),
        attivitaCommerciali: attivitaCommerciali && hasParametersSet(attivitaCommerciali) ? attivitaCommerciali : undefined,
        esperienze: esperienze && hasParametersSet(esperienze) ? esperienze : undefined,
        eventi: eventi && hasParametersSet(eventi) ? eventi : undefined,
        itinerari: itinerari && hasParametersSet(itinerari) ? itinerari : undefined,
        notizie: notizie && hasParametersSet(notizie) ? notizie : undefined,
        prodottiTipici: prodottiTipici && hasParametersSet(prodottiTipici) ? prodottiTipici : undefined,
        puntiDiInteresse: puntiDiInteresse && hasParametersSet(puntiDiInteresse) ? puntiDiInteresse : undefined,
        tipologiaContenutoUniqueId: selectedFilter === '' ? undefined : selectedFilter
      }
      // console.log('FilterRicercaDTO', data);

      void fetch({
        data
      });
    }

  }, [searchString, selectedFilter, selectedDates, filterType, fetch]);

  useEffect(() => {

    // console.log(selectedFilter !== '' || (searchString !== '' && searchString !== null))
    if (selectedFilter !== '' || (searchString !== '' )) {
      const castedData = data as TipologiaContenutoDto[];
      setResults(castedData);
    } else if (isLoggedIn) {
      console.log('recents set', recentData)
      setResults(recentData as TipologiaContenutoDto[])
    } else {
      setResults([])
    }
  }, [data, selectedFilter, recentData, searchString, isLoggedIn]);


  const GET_TASSONOMY_FILTERS = gql(`
  query {
    tassonomieQuery {
      adattoA {
        lista {
          uniqueId
          traduzioni {
            nome
          }
        }
      }
      condizioniDiAccesso {
        lista {
          uniqueId
          traduzioni {
            nome
          }
        }
      }
    }
  }
  `);

  const GET_POI_FILTERS = gql(`
  query ($id: Guid) {
    tassonomieQuery {
      adattoA {
        lista {
          uniqueId
          traduzioni {
            nome
          }
        }
      }
      condizioniDiAccesso {
        lista {
          uniqueId
          traduzioni {
            nome
          }
        }
      }
    }
    puntiDiInteresseQuery {
      tipologie {
        lista (inUsoPerTipoDiContenutoAppUniqueId: $id) {
          uniqueId
          codice
          traduzioni {
            nome
          }
        }
      }
    }
  }
  `);

  const GET_EXPERIENCE_FILTERS = gql(`
  query ($id: Guid) {
    tassonomieQuery {
      adattoA {
        lista {
          uniqueId
          traduzioni {
            nome
          }
        }
      }
      condizioniDiAccesso {
        lista {
          uniqueId
          traduzioni {
            nome
          }
        }
      }
    }
    esperienzeQuery {
      durata {
        lista {
          uniqueId
          traduzioni {
            nome
          }
        }
      }
      tipologie {
        lista (inUsoPerTipoDiContenutoAppUniqueId: $id) {
          uniqueId
          traduzioni {
            nome
          }
        }
      }
    }
  }
  `);

  const GET_CA_FILTERS = gql(`
  query ($id: Guid) {
    tassonomieQuery {
      adattoA {
        lista {
          uniqueId
          traduzioni {
            nome
          }
        }
      }
      condizioniDiAccesso {
        lista {
          uniqueId
          traduzioni {
            nome
          }
        }
      }
    }
    attivitaCommercialiQuery {
      tipologie {
        lista (inUsoPerTipoDiContenutoAppUniqueId: $id) {
          uniqueId
          codice
          traduzioni {
            nome
          }
          figli {
            uniqueId
            traduzioni {
              nome
            }
          }
        }
      }
    }
  }
  `);

  const GET_EVENT_FILTERS = gql(`
  query ($id: Guid) {
    tassonomieQuery {
      adattoA {
        lista {
          uniqueId
          traduzioni {
            nome
          }
        }
      }
      condizioniDiAccesso {
        lista {
          uniqueId
          traduzioni {
            nome
          }
        }
      }
    }
    eventiQuery {
      tipologie {
        lista (inUsoPerTipoDiContenutoAppUniqueId: $id) {
          uniqueId
          codice
          traduzioni {
             nome
          }
        }
      }
    }
  }
  `);

  const GET_ITINERARY_FILTERS = gql(`
  query {
    tassonomieQuery {
      adattoA {
        lista {
          uniqueId
          traduzioni {
            nome
          }
        }
      }
      condizioniDiAccesso {
        lista {
          uniqueId
          traduzioni {
            nome
          }
        }
      }
    }
    itinerariQuery {
      tipologie {
        lista {
          uniqueId
          traduzioni {
            nome
          }
        }
      }
      percorribilita {
        lista {
          uniqueId
          traduzioni {
            nome
          }
        }
      }
      difficolta {
        lista {
          uniqueId
          traduzioni {
            nome
          }
        }
      }
      durata {
        lista {
          uniqueId
          traduzioni {
            nome
          }
        }
      }
    }
  }
  `);

  const GET_NEWS_FILTERS = gql(`
  query {
    tassonomieQuery {
      adattoA {
        lista {
          uniqueId
          traduzioni {
            nome
          }
        }
      }
      condizioniDiAccesso {
        lista {
          uniqueId
          traduzioni {
            nome
          }
        }
      }
    }
    notizieQuery {
      tipologie {
        lista {
          uniqueId
          codice
          traduzioni {
            nome
          }
        }
      }
    }
  }
  `);

  const GET_TP_FILTERS = gql(`
  query {
    tassonomieQuery {
      adattoA {
        lista {
          uniqueId
          traduzioni {
            nome
          }
        }
      }
      condizioniDiAccesso {
        lista {
          uniqueId
          traduzioni {
            nome
          }
        }
      }
    }
    prodottiTipiciQuery {
      tipologie {
        lista {
          uniqueId
          codice
          traduzioni {
            nome
          }
        }
      }
    }
  }
  `);

  const GET_IC_FILTERS = gql(`
  query {
    tassonomieQuery {
      adattoA {
        lista {
          uniqueId
          traduzioni {
            nome
          }
        }
      }
      condizioniDiAccesso {
        lista {
          uniqueId
          traduzioni {
            nome
          }
        }
      }
    }
    contenutiInformativiAppQuery {
      tipologie {
        lista {
          uniqueId
          codice
          traduzioni {
            nome
          }
        }
      }
    }
  }
  `);

  const getFilterQuery = useCallback(() => {
    const entity = filterType.find(el => el.uniqueId === selectedFilter)
    if (entity) {
      switch (entity.nomeEntita) {
        case 'AttivitaCommerciale':
          return GET_CA_FILTERS

        case 'Esperienza':
          return GET_EXPERIENCE_FILTERS

        case 'Evento':
          return GET_EVENT_FILTERS

        case 'Itinerario':
          return GET_ITINERARY_FILTERS

        case 'Notizia':
          return GET_NEWS_FILTERS

        case 'ProdottoTipico':
          return GET_TP_FILTERS

        case 'PuntoDiInteresse':
          return GET_POI_FILTERS

        case 'ContenutoInformativoApp':
          return GET_IC_FILTERS

        default:
          return GET_TASSONOMY_FILTERS
      }
    }
    return GET_TASSONOMY_FILTERS;
  }, [GET_CA_FILTERS, GET_EVENT_FILTERS, GET_EXPERIENCE_FILTERS, GET_IC_FILTERS, GET_ITINERARY_FILTERS, GET_NEWS_FILTERS, GET_POI_FILTERS, GET_TASSONOMY_FILTERS, GET_TP_FILTERS, filterType, selectedFilter])

  const [filtersFetch, { loading: loadingFilters, data: filtersData, error: filtersError }] = useLazyQuery<GraphQLResults>(
    getFilterQuery(),
  );

  useEffect(() => {
    console.log('FETCH');

    void filtersFetch({
      context: {
        headers: {
          'Content-Language': i18n.language.split('-')[0]
        }
      },
      variables: {
        'id': selectedFilter
      },
      onError(error) {
        console.error(error)
      },
    });
  }, [filtersFetch, filtersData, selectedFilter]);

  useEffect(() => {
    // console.log('testFilters', filtersData, selectedFilter)
    if (!filtersData) {
      return;
    }
    setFilters(filtersData);
  }, [filtersData]);

  transformedFilters.current = filters !== undefined ? resultsToFilters(filters) : undefined;
  filtersSubfilters.current = transformedFilters.current?.flatMap(f => f.subfilters.map<FilterSubfilters>(sf => {            // Mappa in un array di combinazioni filtro-sottofiltro
    return {
      filterName: f.filterName,
      subfilter: sf,
    };
  }));

  filtersSubfilters.current?.map(_ => refSubfilterSelections.current.push([]));

  const filterQueryString = decodeURI(new URLSearchParams(search).get('filter') ?? '').toLowerCase().replace(new RegExp(' ', 'g'), ''); // Parametro lower case senza spazi.

  useEffect(() => {
    const filterIndex = filtersSubfilters.current?.findIndex(f => f.filterName.toLowerCase().includes(filterQueryString)); // TODO: cambiare una volta che la query graphQL restituisce i nomi dei filtri.

    if (!refFilterChanged.current && filtersSubfilters.current != undefined && filterQueryString != '' && filterIndex && filterIndex != -1) {
      setSelectedFilter(filtersSubfilters.current[filterIndex].filterName);
      setSearchString('');
    }
  }, [filterQueryString]);

  const value: DiscoverContextType = useMemo(() => {
    return {
      searchResults: results,
      loading: loading,
      error: error,
      filters: transformedFilters.current,
      filtersSubfilters: filtersSubfilters.current,
      loadingFilters: loadingFilters,
      filtersError: filtersError,
      refSubfilterStates: refSubfilterSelections,
      updateSubfilterStates: updateFilterStates,
      updateSubfilterConfirmation: updateFilterConfirmation,
      selectedDates: selectedDates,
      setSelectedDates: setSelectedDates,
      selectedFilter: selectedFilter,
      setSelectedFilter: updateSelectedFilter,
      setSearchString,
      searchString,
      barVisible: barVisible,
      setBarVisible: updateBarVisibility,
      filterType,
      recentLoading
    }
  }, [barVisible, error, filterType, filtersError, loading, loadingFilters, recentLoading, results, searchString, selectedDates, selectedFilter, updateFilterConfirmation, updateFilterStates])

  return (
    <DiscoverContext.Provider value={value}>
      {children}
    </DiscoverContext.Provider>
  );
};

export default DiscoverProvider;