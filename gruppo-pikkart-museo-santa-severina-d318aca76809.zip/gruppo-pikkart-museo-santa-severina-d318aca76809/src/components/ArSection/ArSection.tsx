
import Carousel from "@/components/Carousel";
import { CarouselCardProps } from "@/components/CarouselCard";
import { ContenutoEsperienzeArDto } from "@/services/openapi";
import { ARLayoutTypes, useLayouts } from '@/hooks/useLayout';

const ArSection = ({ content, cardStyled, style }: { content: ContenutoEsperienzeArDto, cardStyled?: boolean, vediTuttiText?: string, style: any }) => {
  const layouts = useLayouts();

  const slidesInCard = layouts.get(content.tipologiaLayout as ARLayoutTypes) === "mini" ? 2 : 1;

  return (
    <>
      <Carousel
        slidesInCard={slidesInCard}
        background={style.backColorPrimario as string}
        titleBar={{
          title: {
            text_key: content.nome ?? "",
            text_size: 'large',
            text_weight: 'bold',
            color: style.textColorPrimario as string
          }
          // link: {
          //     href: '/discover' + (content.nome ? '?filter=' + encodeURI(content?.nome) : ''),
          //     text_key: vediTuttiText !== undefined ? vediTuttiText : t('view_all'),
          //     text_size: 'regular',
          //     color: content.container?.coloreVediTutti as string
          // }
        }}
        slides={
          content?.content?.map((elemento) => {
            return {
              cardType: layouts.get(content.tipologiaLayout as ARLayoutTypes),
              cardStyled: cardStyled !== undefined ? cardStyled : false,
              textColor: "light",
              contentType: elemento.tipologiaContenutoApp.nomeEntita,
              eventText: elemento.tipologiaContenutoApp.traduzioni[0].nome ?? "",
              title: elemento?.traduzioni[0]?.titolo ?? "Titolo",
              description: elemento?.traduzioni[0]?.istruzioni ?? "Istruzioni",
              imgUrl: elemento?.immagineUrl ?? "ImageURL",
              titleColor: /*elemento?.tipologiaContenutoApp?.container?.coloreTitoloItem ??*/ 'white',
              //secondaryInfoColor: (content.container?.coloreDataItem as string) ?? 'white',
              descriptionColor: /*elemento?.tipologiaContenutoApp?.container?.coloreDescrizioneItem ??*/ 'white',
              id: elemento.uniqueId,

            } as CarouselCardProps & { id: string, contentType: string }
          })
        }
      />
    </>
  );
}

export default ArSection;
