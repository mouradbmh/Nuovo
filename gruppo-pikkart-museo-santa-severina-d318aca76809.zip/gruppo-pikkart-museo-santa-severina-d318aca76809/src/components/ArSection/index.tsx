import ArSection from "@/components/ArSection/ArSection";

export default ArSection;
