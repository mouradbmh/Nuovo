import classes from "@/components/PartecipationsOverview/partecipationsOverview.module.css";
import { styled } from "styled-components";

const PartecipationsOverview = ({ boxes }: { boxes: PartecipationsBoxProps[] }) => {
    return (
        <div className={classes.boxes_container}>
            {boxes.map((box, index) => (
                <PartecipationsBox
                    key={index}
                    {...box}
                />
            ))}
        </div>
    );
};

export type PartecipationsBoxProps = {
    number: number;
    label: string;
    backColor?: string;
    textColor?: string;
};

const StyledBox = styled.div<{ backcolor: string, color: string }>`
    background-color: ${props => props.backcolor};
    color: ${props => props.color};
`;

const PartecipationsBox = ({
    number,
    label,
    backColor = "#F1F1F1",
    textColor = "black"
}: PartecipationsBoxProps) => {
    return (
        <StyledBox className={classes.partecipations_box} backcolor={backColor} color={textColor}>
            <div className={classes.partecipations_box_number}>{number}</div>
            <div className={classes.partecipations_box_label}>{label}</div>
        </StyledBox>
    );
};

export default PartecipationsOverview;
export { PartecipationsBox };
