import PartecipationsOverview from "@/components/PartecipationsOverview/PartecipationsOverview";
import { PartecipationsBox, PartecipationsBoxProps } from "@/components/PartecipationsOverview/PartecipationsOverview";

export default PartecipationsOverview;
export { PartecipationsBox };
export type { PartecipationsBoxProps };
