import { styled } from 'styled-components';
import classes from '@/components/ProgressBar/progressBar.module.css'

export interface ProgressBarProps {
  /**
   * Background color of the container.
   */
  backColor?: string;
  /**
   * Background color of the progress bar
   */
  progressBarBackColor?: string;
  /**
   * Color of the progress bar
   */
  progressBarColor?: string;
  /**
   * Width of the progress bar between 0 and 100.
   */
  progress?: number;
};

const StyledBar = styled.div<{ backcolor: string }>`
  background-color: ${props => props.backcolor};
`;

const StyledProgressBar = styled.div<{ backcolor: string, widthperc: number }>`
  background-color: ${props => props.backcolor};
  width: ${props => props.widthperc + '%'}
`;

function toRangeValue(value: number, min: number, max: number) {
  return value < min ? min : (value > max ? max : value);
}

const ProgressBar = ({
  backColor = 'transparent',
  progressBarBackColor = 'var(--zinc-300)',
  progressBarColor = 'var(--emerald-700)',
  progress = 0,
}: ProgressBarProps) => {
  return (
    <StyledBar className={classes.progress_bar_container} backcolor={backColor}>
      <StyledBar className={classes.progress_bar_background} backcolor={progressBarBackColor}>
        <StyledProgressBar className={classes.progress_bar} backcolor={progressBarColor} widthperc={toRangeValue(progress, 0, 100)}>
        </StyledProgressBar>
      </StyledBar>
    </StyledBar>
  )
}

export default ProgressBar;