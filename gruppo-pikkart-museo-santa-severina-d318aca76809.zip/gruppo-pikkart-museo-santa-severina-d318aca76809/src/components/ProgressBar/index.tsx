import ProgressBar, { ProgressBarProps } from "./ProgressBar";

export default ProgressBar;
export type { ProgressBarProps };