import classes from './HrLine.module.css'

const HrLine = () => {
  return (
    <div className={classes.hrLine}>
    </div>
  )
}

export default HrLine
