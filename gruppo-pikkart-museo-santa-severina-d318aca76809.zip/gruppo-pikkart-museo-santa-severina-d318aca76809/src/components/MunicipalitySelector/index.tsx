import MunicipalitySelector from "@/components/MunicipalitySelector/MunicipalitySelector";

export default MunicipalitySelector;
