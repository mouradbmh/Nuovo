import classes from '@/components/MunicipalitySelector/municipalitySelector.module.css';
import IconTextButton from '@/components/IconTextButton';
import TextSubtext from '@/components/TextSubtext';
import { styled } from 'styled-components';

export type MunicipalitySelectorProps = {
  label_text_key?: string;
  label_text_color?: string;
  municipality_text_key?: string;
  municipality_text_color?: string;
  change_municipality_text_key?: string;
  back_color?: string;
  button_back_color?: string;
  button_text_color?: string;
  button_border_color?: string;
  border_color?: string;
  on_change_municipality?: () => void;
};

const StyledDiv = styled.div<{ backcolor?: string, bordercolor?: string }>`
  ${props => props.backcolor !== undefined ? `background-color: ${props.backcolor};` : ''}
  border-top: 1px solid ${props => props.bordercolor};
  border-bottom: 1px solid ${props => props.bordercolor};
`;

const MunicipalitySelector = ({
  label_text_key = "Comune",
  label_text_color = "var(--zinc-900)",
  municipality_text_key = "Nome Comune",
  change_municipality_text_key = "Cambia Comune",
  municipality_text_color = "var(--zinc-900)",
  back_color = "var(--zinc-100)",
  button_back_color = "var(--emerald-700)",
  button_text_color = "var(--outline-bg)",
  button_border_color = "var(--emerald-700)",
  border_color = "var(--zinc-500)",
  on_change_municipality
}: MunicipalitySelectorProps) => {
  return (
    <StyledDiv backcolor={back_color} bordercolor={border_color} className={classes.column_container}>
      <div className={classes.row_container}>
        <TextSubtext
          textProps={{
            text_key: label_text_key,
            text_size: "regular",
            color: label_text_color,
          }}
        />
        <TextSubtext
          textProps={{
            text_key: municipality_text_key,
            text_size: "regular",
            text_weight: "bold",
            color: municipality_text_color,
          }}
        />
      </div>
      <IconTextButton
        buttonMode="normal"
        expanded
        onClick={on_change_municipality}
        padding={{ all: "16px" }}
        textProps={{
          text_key: change_municipality_text_key,
          text_size: "regular",
          color: button_text_color,
          text_weight: "medium"
        }}
        bordercolor={button_border_color}
        backColor={button_back_color}
      />
    </StyledDiv>
  );
};

export default MunicipalitySelector;
