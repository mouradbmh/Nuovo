import ToggleSwitch from "@/components/ToggleSwitch/ToggleSwitch";

export default ToggleSwitch;
