import { useState } from "react";
import Switch from "react-switch";

type ToggleSwitchProps = {
    offColor?: string,
    onColor?: string,
    offHandleColor?: string,
    onHandleColor?: string,
    handleDiameter?: number,
    height?: number,
    width?: number,
    checked?: boolean,
    onChange: (value: boolean) => void,
};

const ToggleSwitch = ({
    offColor = "#a1a1aa",
    onColor = "#047857",
    offHandleColor = "#FFF",
    onHandleColor = "#FFF",
    handleDiameter = 28,
    height = 32,
    width = 56,
    onChange
}: ToggleSwitchProps) => {
    const [checked, setChecked] = useState<boolean>(false);
    const handleOnChange = () => {
        setChecked(!checked);
        onChange(checked);
    };

    return (
        <Switch
            checked={checked}
            onChange={handleOnChange}
            uncheckedIcon={false}
            checkedIcon={false}
            offColor={offColor}
            onColor={onColor}
            offHandleColor={offHandleColor}
            onHandleColor={onHandleColor}
            handleDiameter={handleDiameter}
            height={height}
            width={width}
        />
    );
};

export default ToggleSwitch;
