import PartecipantRow from "@/components/PartecipantRow";
import TextSubtext from "@/components/TextSubtext";
import classes from "@/components/PartecipantsList/partecipantsList.module.css";

type PartecipantType = {
    name: string;
    checked: boolean;
};

type PartecipantsListProps = {
    title?: string;
    partecipants: PartecipantType[];
    color?: string;
    checkColor?: string;
};

const PartecipantsList = ({
    title,
    partecipants,
    color = "var(--zinc-900)",
    checkColor = "var(--emerald-500)",
}: PartecipantsListProps) => {
    return (
        <>
            {title !== undefined && (
                <TextSubtext
                    textProps={{
                        text_key: title,
                        text_size: "title4",
                        text_weight: "bold",
                        color: color,
                    }}
                    className={classes.title}
                />)}
            {partecipants.map((partecipant, index) => (
                <PartecipantRow
                    key={index}
                    count={index + 1}
                    name={partecipant.name}
                    checked={partecipant.checked}
                    color={color}
                    checkColor={checkColor}
                    onCheck={() => { }}
                    onRemove={() => { }}
                />
            ))}
        </>
    );
};

export default PartecipantsList;
