import PartecipantsList from "@/components/PartecipantsList/PartecipantsList";

export default PartecipantsList;
