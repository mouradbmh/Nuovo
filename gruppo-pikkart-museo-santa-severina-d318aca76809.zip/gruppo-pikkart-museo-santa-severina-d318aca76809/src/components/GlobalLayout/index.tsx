import GlobalLayout from "@/components/GlobalLayout/GlobalLayout";

export default GlobalLayout;