import classes from '@/components/SearchResultsList/searchResultsList.module.css';
import { TipologiaContenutoDto } from '@/services/openapi';
import TextComponent from '@/components/TextComponent';
import TextSubtext from '@/components/TextSubtext';
import { useTranslation } from 'react-i18next';
import { DetailsContentsType } from '../DetailsProvider/DetailsProvider';
import React, { useEffect } from 'react';
import Loader from '@/components/Loader';
import {Link} from "react-router-dom";
import LazyImage from '../LazyImage';
import { useSearch } from '@/hooks/useSearch';

export interface SearchResultsListProps {
  searchResults?: TipologiaContenutoDto[];
  loading?: boolean;
  recentLoading?: boolean
}

export type WrapperProps = {
  condition: boolean;
  wrapper: (x: React.JSX.Element) => React.JSX.Element;
  children: React.JSX.Element
}

const SearchResultsList = ({
  searchResults,
  loading,
  recentLoading
  
}: SearchResultsListProps) => {
  const { t } = useTranslation();
  const {selectedFilter} = useSearch()

  const getType = (type: string | undefined | null) => {
    switch (type) {

      case 'Notizia':
      case 'NotiziaTraduzione':
        return DetailsContentsType.NEWS;

      case 'Evento':
      case 'EventoTraduzione':
        return DetailsContentsType.EVENT;

      case 'Esperienza':
      case 'EsperienzaTraduzione':
        return DetailsContentsType.EXPERIENCE;

      case 'PuntoDiInteresse':
      case 'PuntoDiInteresseTraduzione':
        return DetailsContentsType.POINT_OF_INTEREST;

      case 'Itinerario':
      case 'ItinerarioTraduzione':
        return DetailsContentsType.ITINERARY;

      case 'ProdottoTipico':
      case 'ProdottoTipicoTraduzione':
        return DetailsContentsType.TYPICAL_PRODUCT;

      case 'ContenutoInformativoApp':
      case 'ContenutoInformativoAppTraduzione':
        return DetailsContentsType.INFORMATIVE_CONTENT;

      case 'AttivitaCommerciale':
      case 'AttivitaCommercialeTraduzione':
        return DetailsContentsType.COMMERCIAL_ACTIVITY

      default:
        return -1;
    }
  };

  useEffect(() => {
    console.log('search result',searchResults)
  },[searchResults])

  useEffect(() => {
    console.log('loading', loading);
  }, [loading]);

  useEffect(() => {
    console.log('recentLoading', recentLoading);
  }, [recentLoading]);

  const ConditionalWrapper = ({ condition, wrapper, children }: WrapperProps) =>
    condition ? wrapper(children) : children;

  return (
    <div className={classes.results_list}>
      { (!recentLoading || !loading) && searchResults ?
        (
           searchResults && searchResults?.length > 0 ? (
            searchResults?.map((el) => {
              return (
                <div key={el.uniqueId} className={classes.results_list_section}>
                  <div className={classes.result_section_title}>
                    <TextComponent
                      text_key={el.nome ?? t('missing_section_title')}
                      text_line='normal'
                      text_weight='bold' />
                  </div>
                  {el.contenuti !== undefined && el.contenuti.length > 0 ? (
                    el.contenuti.map(c => {
                      return (
                        <ConditionalWrapper
                          key={c.uniqueId}
                          condition={c.uniqueId !== undefined && getType(el.nomeEntita).toString() !== '-1'}
                          wrapper={children => <Link className={classes.result_container} to={location.protocol + '//' + location.host + '/details/?id=' + c.uniqueId!.toString() + '&type=' + getType(el.nomeEntita).toString()}>{children}</Link>}
                        >
                          <div className={classes.result_container} key={c.uniqueId}>
                            <div className={classes.result_image_container}>
                              <LazyImage className={classes.result_image} src={c.urlImmagine ? c.urlImmagine + '&thumbkey=thumbnail' : ''} alt={t('image')} />
                            </div>
                            <TextSubtext className={classes.result}
                              textProps={{
                                text_key: c.titolo ?? t('missing_title'),
                                text_size: 'small',
                                text_line: 'normal',
                                text_weight: 'bold',
                                row_limit: 2,
                                color: 'var(--zinc-800)', // TODO: da configurazione
                              }}
                              subtextProps={{
                                text_key: c.descrizioneBreve ?? t('missing_description'),
                                text_size: 'tiny',
                                text_line: 'normal',
                                row_limit: 1,
                                color: 'var(--zinc-500)', // TODO: da configurazione
                              }}
                              gap={8} />
                          </div>
                        </ConditionalWrapper>
                      )
                    })
                  ) : (<span className={classes.no_results}>{(selectedFilter === '') ? t("no_criteria") : t('no_results')}</span>)}
                </div>
              );
            })
          ) : (
            <span className={classes.no_results}>{(selectedFilter === '') ? t("no_criteria") : t('no_results')}</span>
          )
        ) : (
          <Loader />
        )
    }
    </div>
  )
}

export default SearchResultsList;