import SearchResultsList, { SearchResultsListProps } from "@/components/SearchResultsList/SearchresultsList";

export default SearchResultsList;
export type { SearchResultsListProps };