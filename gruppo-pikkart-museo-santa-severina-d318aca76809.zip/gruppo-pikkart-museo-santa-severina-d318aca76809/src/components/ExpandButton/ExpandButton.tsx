import IconTextButton, { IconTextButtonProps } from "@/components/IconTextButton";
import { useAppContext } from "@/hooks/useAppContext";
import { Dispatch, SetStateAction } from "react";
import { ChevronDown, ChevronUp } from "react-feather";

export interface ExpandButtonProps {
  className?: string;
  expanded: boolean;
  setExpanded: Dispatch<SetStateAction<boolean>>;
  expanded_text: string;
  not_expanded_text: string;
  padding?: IconTextButtonProps['padding']
}

const ExpandButton = ({
  className,
  expanded,
  setExpanded,
  expanded_text,
  not_expanded_text,
  padding,
}: ExpandButtonProps) => {
  const { theme } = useAppContext();

  return (
    <IconTextButton className={className}
      textProps={{
        text_key: expanded ? expanded_text : not_expanded_text
      }}
      icon={expanded ? (
        <ChevronUp strokeWidth={1.5} width={24} height={24} />
        ) : (
          <ChevronDown strokeWidth={1.5} width={24} height={24} />
      )}
      invertContents
      contentsColor={theme?.bottoneSecondario?.coloreFronte ?? undefined}
      backColor={theme?.bottoneSecondario?.coloreSfondo ?? undefined}
      buttonMode='outline_borderless'
      padding={padding}
      onClick={() => setExpanded(!expanded)} />
  );
}

export default ExpandButton;