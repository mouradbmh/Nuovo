import ExpandButton, { ExpandButtonProps } from "@/components/ExpandButton/ExpandButton";

export default ExpandButton;
export type { ExpandButtonProps };