import { styled } from "styled-components";
import classes from "@/components/DateSelector/dateSelector.module.css";
import TextSubtext from "@/components/TextSubtext";
import { Calendar } from "react-feather";

type DateSelectorProps = {
    label?: string;
    placeholder?: string;
    color?: string;
    date?: string;
    setDate: (date: string) => void;
};

const StyledButton = styled.button<{ backcolor: string, color: string, bordercolor: string }>`
    background-color: ${props => props.backcolor};
    color: ${props => props.color};
    border-radius: 48px;
    border: 1px solid ${props => props.bordercolor};
    padding: 8px 8px 8px 16px;
    display: flex;
    flex-direction: row;
    align-items: center;
    gap: 8px;
    cursor: pointer;
`;

const DateSelector = ({
    label = "Data",
    placeholder = "Seleziona data",
    color = "var(--emerald-700)",
    date = "",
    // setDate
}: DateSelectorProps) => {
    const backColor = date ? color : "transparent";
    const textColor = date ? "white" : color;
    const borderColor = date ? "transparent" : color;

    return (
        <div className={classes.row}>
            <TextSubtext
                textProps={{
                    text_key: label,
                    text_size: "regular",
                    color: "var(--zinc-900)",
                }}
            />
            <StyledButton
                color={textColor}
                backcolor={backColor}
                bordercolor={borderColor}
                className={classes.date_selector}
                onClick={() => {}}
            >
                <TextSubtext
                    textProps={{
                        text_key: date ? date : placeholder,
                        text_size: "regular",
                        color: textColor,
                        text_weight: "medium",
                    }}
                />
                <Calendar size={16} color={textColor} />
            </StyledButton>
        </div>
    );
};

export default DateSelector;
