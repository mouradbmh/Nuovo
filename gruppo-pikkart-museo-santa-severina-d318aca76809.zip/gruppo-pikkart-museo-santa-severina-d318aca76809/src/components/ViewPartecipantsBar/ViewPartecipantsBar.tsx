import classes from '@/components/TimeSelector/timeSelector.module.css';
import { ArrowRight, Users } from 'react-feather';
import TextSubtext from '@/components/TextSubtext';
import { styled } from 'styled-components';

type ViewPartecipantsBarProps = {
    text_key: string;
    button_text_key: string;
    backColor?: string;
    color?: string;
    onClick: () => void;
};

const StyledButton = styled.button<{ backcolor: string, color: string }>`
  background-color: ${props => props.backcolor};
  color: ${props => props.color};
`;

const ViewPartecipantsBar = ({
    text_key,
    button_text_key,
    backColor = "var(--emerald-700)",
    color = "white",
    onClick,
}: ViewPartecipantsBarProps) => {
    return (
        <div className={classes.container}>
            <div className={classes.label}>
                <Users size={24} strokeWidth={1.5} color='var(--zinc-900)' />
                <TextSubtext
                    textProps={{
                        text_key: text_key,
                        text_size: "regular",
                        color: "var(--zinc-900)",
                    }}
                />
            </div>
            <div className={classes.time_selector_container}>
                <StyledButton color={color} backcolor={backColor} className={classes.time_selector} onClick={onClick}>
                    <div className={classes.time_selector_content}>
                        <TextSubtext
                            textProps={{
                                text_key: button_text_key,
                            }}
                        />
                        <ArrowRight size={16} />
                    </div>
                </StyledButton>
            </div>
        </div>
    );
};

export default ViewPartecipantsBar;
