import ViewPartecipantsBar from "@/components/ViewPartecipantsBar/ViewPartecipantsBar";

export default ViewPartecipantsBar;
