import TabHeader, { TabHeaderProps } from "@/components/TabHeader";
import { useState } from "react";
import classes from "@/components/TabsBar/tabsBar.module.css"

export type TabsBarProps = {
    tabs?: TabHeaderProps[],
    activeTab?: number,
    onTabChange?: (index: number) => void,
};

const TabsBar = ({
    tabs = [],
    onTabChange = () => { },
}: TabsBarProps) => {
    const [activeTab, setActiveTab] = useState<number>(0);

    const handleOnTabClick = (index: number) => {
        if (index != activeTab) {
            onTabChange(index);
            setActiveTab(index);
        }
    };

    return (
        <div className={classes.tabs_container}>
            {
                tabs.map((tab, index) => {
                    return (
                        <TabHeader {...tab} key={index} active={index == activeTab} onClick={() => handleOnTabClick(index)} />
                    );
                })
            }
        </div>
    );
};

export default TabsBar;
