import TabsBar from "@/components/TabsBar/TabsBar";

export default TabsBar;
