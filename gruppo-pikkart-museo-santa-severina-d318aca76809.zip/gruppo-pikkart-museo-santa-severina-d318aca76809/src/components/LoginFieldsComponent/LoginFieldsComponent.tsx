import { styled } from 'styled-components';

import classes from '@/components/LoginFieldsComponent/loginFieldsComponent.module.css';
import InputComponent from '@/components/InputComponent';
import IconTextButton from '@/components/IconTextButton';
import { Dispatch, SetStateAction } from 'react';
import { useTranslation } from 'react-i18next';

export interface LoginFieldsComponentProps {
  /**
   * The background color for the container.
   */
  backColor?: string,
  setEmail: Dispatch<SetStateAction<string>>,
  setPassword: Dispatch<SetStateAction<string>>
};

const StyledDiv = styled.div<{ backcolor?: string }>`
  ${props => props.backcolor !== undefined ? `background-color: ${props.backcolor};` : '' }
`;

const LoginFieldsComponent = ({
  backColor,
  setEmail,
  setPassword
}: LoginFieldsComponentProps) => {
  const { t } = useTranslation();
  
  return (
    <StyledDiv className={classes.texts_container} backcolor={backColor}>
      <InputComponent
        inputName='email'
        inputType='email'
        inputProps={{
          text_key: '',
          text_size: 'regular',
        }}
        placeholderProps={{
          text_key: t('email'),
          text_size: 'tiny',
          text_weight: 'regular'
        }}
        setOnChange={setEmail}
      />
      <InputComponent
        inputName='password'
        inputType='password'
        inputProps={{
          text_key: '',
          text_size: 'regular',
        }}
        placeholderProps={{
          text_key: t('password'),
          text_size: 'tiny',
          text_weight: 'regular'
        }}
        setOnChange={setPassword}
      />
      <IconTextButton
        textProps={{
          text_key: t('password_forgotten')
        }}
        buttonMode='outline_borderless'
        no_rounded_borders />
    </StyledDiv>
  )
}

export default LoginFieldsComponent;