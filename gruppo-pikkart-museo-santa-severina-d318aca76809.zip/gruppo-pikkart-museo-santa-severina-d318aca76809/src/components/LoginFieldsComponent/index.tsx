import LoginFieldsComponent , { LoginFieldsComponentProps } from "@/components/LoginFieldsComponent/LoginFieldsComponent";

export default LoginFieldsComponent;
export type { LoginFieldsComponentProps };