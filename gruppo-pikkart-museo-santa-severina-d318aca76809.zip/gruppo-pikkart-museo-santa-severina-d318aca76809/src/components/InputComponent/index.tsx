import InputComponent, { InputProps } from "@/components/InputComponent/InputComponent";

export default InputComponent;
export type { InputProps }