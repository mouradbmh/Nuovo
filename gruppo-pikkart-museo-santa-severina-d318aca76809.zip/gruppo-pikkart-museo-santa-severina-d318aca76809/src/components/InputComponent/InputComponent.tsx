import classes from '@/components/InputComponent/inputComponent.module.css';
import textClasses from '@/components/TextComponent/text.module.css';
import { useTranslation } from 'react-i18next';
import styled from 'styled-components';
import TextComponent, { TextProps } from '@/components/TextComponent';
import { Dispatch, HTMLInputTypeAttribute, SetStateAction, useEffect, useState } from 'react';
import { Eye } from 'react-feather';
import { Keyboard } from '@capacitor/keyboard';

export interface InputProps {
  /**
   * Additional classes for the component.
   */
  className?: string;
  /**
   * Type of input element.
   */
  inputType: HTMLInputTypeAttribute;
  /**
   * Name of the input element.
   */
  inputName: string;
  /**
   * Configuration for the label.
   */
  labelProps?: TextProps;
  /**
   * Placeholder text in the input.
   */
  placeholderText_key?: string;
  inputText_key?: string;
  /**
   * Configuration for the text in the input.
   */
  inputProps: TextProps;
  /**
   * Configuration for the placeholder text that appears above the input.
   * If placeholderText_key is not set then the text is also used for the placeholder in the input.
  */
  placeholderProps?: TextProps;
  /**
   * Text displayed in case of input error.
   */
  errorMessageKey?: string;
  /**
   * Icon to the left of the input.
   */
  icon?: JSX.Element;
  /**
   * Disables the input element.
   */
  disabled?: boolean;
  showViewPasswordButton?: boolean;
  setOnChange?: Dispatch<SetStateAction<string>>;
  onEnter?: (value: string) => void;
  enterKeyHint?: "enter" | "done" | "go" | "next" | "previous" | "search" | "send" | undefined;
}

const StyledInput = styled.input<{ color?: string }>`
  ${props => props.color !== undefined ? `color: ${props.color};` : ''}
`;

/**
 * Primary UI component for user interaction
 */
const InputComponent = ({ // TODO: colore/i
  className,
  inputType,
  inputName,
  labelProps,
  placeholderText_key,
  inputText_key,
  inputProps,
  placeholderProps,
  errorMessageKey,
  icon,
  disabled = false,
  showViewPasswordButton = false,
  setOnChange,
  onEnter,
  enterKeyHint = 'done'
}: InputProps) => {
  const { t } = useTranslation();
  const [val, setVal] = useState(inputProps.text_key);
  const [focus, setFocus] = useState(false);
  const [viewPassword, setViewPassword] = useState(false);

  const canViewPassword = inputType === 'password' && showViewPasswordButton;

  useEffect(() => {
    if (inputText_key !== undefined) {
      setVal(inputText_key)
    }
  }, [inputText_key]);

  let cl = [textClasses.text, textClasses['text_' + inputProps.text_size], textClasses['text_weight_' + inputProps.text_weight], classes.input];
  if (inputProps.text_line !== 'none') {
    cl.push(textClasses['line_' + inputProps.text_line])
  }
  if (className !== undefined) {
    cl.push(className)
  }

  let rowClasses = [classes.row_container];
  if (val == "") {
    rowClasses.push(classes.empty_input);
  }
  if (focus) {
    rowClasses.push(classes.focused_input);
  }
  if (disabled) {
    rowClasses.push(classes.disabled_input);
  }
  if (errorMessageKey !== undefined && errorMessageKey != '') {
    rowClasses.push(classes.error_input);
  }

  return (
    <div className={classes.col_container}>
      {
        labelProps !== undefined ? (
          <label htmlFor={inputName}>
            <TextComponent {...labelProps} /> 
          </label>
        ) : (<></>)
      }
      <div className={rowClasses.join(' ')}>
        {icon !== undefined ? <>{icon}</> : (<></>)}
        <div className={val == '' || placeholderProps === undefined ? [classes.input_container, classes.no_placeholder].join(' ') : classes.input_container}>
          {
            placeholderProps !== undefined ? (
              <TextComponent className={val == '' ? classes.placeholder_hidden : undefined} {...placeholderProps} />
            ) : (<></>)
          }
          <StyledInput
            name={inputName}
            className={cl.join(' ')}
            color={inputProps.color}
            type={canViewPassword && viewPassword ? 'text' : inputType}
            onFocus={() => setFocus(true)}
            onBlur={() => setFocus(false)}
            disabled={disabled}
            placeholder={
              placeholderText_key !== undefined ?
                t(placeholderText_key) : (
                  placeholderProps !== undefined ? t(placeholderProps.text_key) : undefined
                )
            }
            value={val}
            onChange={(v) => {
              setVal(v.target.value);
              setOnChange?.(v.target.value)
            }}
            onKeyDown={(e) => {
              if (e.key == 'Enter') {
                onEnter?.(e.currentTarget.value)
                void Keyboard.hide();
              }
            }}
            enterKeyHint={enterKeyHint}
          />
        </div>
        {canViewPassword ? (<Eye size={24} strokeWidth={1.5} color='var(--zinc-900)' className={classes.view_password} onClick={() => setViewPassword(!viewPassword)} />) : (<></>)}
      </div>
      {
        errorMessageKey !== undefined && errorMessageKey != '' ? (
          <TextComponent className={classes.error_message} text_key={t(errorMessageKey)} text_size='small' text_line='normal' color='#FF5247' />
        ) : (<></>)
      }
    </div>

  );
};

export default InputComponent;