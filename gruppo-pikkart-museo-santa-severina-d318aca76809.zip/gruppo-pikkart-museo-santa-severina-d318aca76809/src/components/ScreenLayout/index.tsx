import ScreenLayout from "@/components/ScreenLayout/ScreenLayout";

export default ScreenLayout;