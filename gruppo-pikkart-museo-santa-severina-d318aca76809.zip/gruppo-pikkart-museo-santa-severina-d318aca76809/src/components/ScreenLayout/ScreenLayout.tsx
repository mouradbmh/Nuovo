import React from "react";
import { ScreenTransition, TransitionType } from "@/components/ScreenTransition";
import AppBottomBar from "@/components/AppBottomBar";
import Spacer from "@/components/Spacer";
import classes from "@/components/ScreenLayout/ScreenLayout.module.css"

const ScreenLayout = ({
  transition,
  showBottomBar,
  currentScreen,
  children
}: {
  transition?: TransitionType,
  showBottomBar?: boolean,
  currentScreen?: 'home' | 'discover' | 'profile',
  children: React.ReactNode
}
) => {
  // console.log('currentScreen', currentScreen, transition)
  return (
    <div className={classes.globalPage}>
      <ScreenTransition transition={transition}>
        {children}
      </ScreenTransition>
      {(showBottomBar === undefined || showBottomBar === true) && (
        <div className={classes.bottomContainer}>
          <Spacer />
          <AppBottomBar currentScreen={currentScreen} />
        </div>
      )}
    </div>
  );
}

export default ScreenLayout;