// import React from 'react'
import TextComponent from '../TextComponent'
import classes from './Loader.module.css'

type Props = {
  size?: number,
  percentage?: string,
  message?: string
}

const Loader = ({ size,message,percentage }: Props) => {

  const top = `calc(50vh - ${(size ?? 75) /2}px)`
  const left = `calc(50% - ${(size ?? 75) /2}px)`

  return (
    <div className={classes.loading_overlay} style={{
      position: 'absolute',
      top: top,
      left: left
    }}>
      <TextComponent text_key={percentage ?? ''} className={classes.percentage} />
      <div className={classes.loader} style={{
        height: size ?? 75,
        width: size ?? 75
      }}></div>
      <div className={classes.message} style={{top: (size ?? 75) + 50}}>
        <TextComponent text_key={message ?? ''} />
      </div>
    </div>
  )
}

export default Loader
