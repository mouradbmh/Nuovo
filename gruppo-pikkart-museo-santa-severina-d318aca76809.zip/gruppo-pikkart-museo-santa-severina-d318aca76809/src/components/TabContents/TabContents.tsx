import TextSubtext from "@/components/TextSubtext";
import classes from "@/components/TabContents/tabContents.module.css";
import { styled } from "styled-components";
import LazyImage from "../LazyImage";

type Content = { imgUrl: string, date?: string, text?: string, onClick?: () => void };

export type TabContentsProps = {
    dateColor?: string,
    textColor?: string,
    backColor?: string,
    tabs?: Content[]
};

const StyledDiv = styled.div<{ backcolor: string }>`
  background-color: ${props => props.backcolor};
`;

const TabContents = ({
    dateColor = "var(--emerald-600)",
    textColor = "var(--zinc-800)",
    backColor = "transparent",
    tabs = [],
}: TabContentsProps) => {
    return (
        <StyledDiv backcolor={backColor} className={classes.contents_container}>
            {tabs.map((tab, index) => (
                <TabContent content={tab} dateColor={dateColor} textColor={textColor} key={index} />
            ))}
        </StyledDiv>
    );
};

export const TabContent = ({ content, dateColor, textColor }: { content: Content, dateColor: string, textColor: string }) => {
    return (
        <div className={classes.tab_container} onClick={content.onClick}>
            <LazyImage src={content.imgUrl} className={classes.tab_image} alt="img" />
            <div className={classes.tab_text_container}>
                <TextSubtext
                    textProps={{
                        text_key: content.date ? content.date : "",
                        text_size: "tiny",
                        color: dateColor,
                        className: classes.tab_date,
                    }}
                    subtextProps={{
                        text_key: content.text ? content.text : "",
                        text_size: "small",
                        text_weight: "bold",
                        color: textColor,
                        className: classes.tab_text,
                    }}
                />
            </div>
        </div>
    );
};

export default TabContents;
