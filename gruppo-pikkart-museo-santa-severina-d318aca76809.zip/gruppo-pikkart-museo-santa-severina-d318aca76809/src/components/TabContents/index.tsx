import TabContents from "@/components/TabContents/TabContents";
import { TabContent } from "@/components/TabContents/TabContents";

export default TabContents;
export { TabContent };
