
export type Traduzioni = {
  titolo: string;
  descrizione: string;
};

export type Video = {
  uniqueId: string;
  previewFileUrl: string;
  fileUrl: string;
  urlYoutube: string;
  traduzioni: Traduzioni[];
  tipologia: string; // hmm
}

export type MatterportSpace = {
  uniqueId: string;
  codice: string;
  previewFileUrl: string;
  matterportAccount: {
    chiaveSdk: string;
  };
  traduzioni: Traduzioni[];
};

export type Elementi3D = {
  uniqueId: string;
  traduzioni: Traduzioni[];
  fileUrl: string;
  previewFileUrl: string;
};

export type TourVirtuali = {
  uniqueId: string;
  traduzioni: Traduzioni[];
  previewFileUrl: string;
  codice: string;
}

export type Luoghi = {
  uniqueId: string;
  immagineUrl: string;
  indirizzo: string;
  cAP: string;
  latitudine: string;
  longitudine: string;
  nome: string;
  descrizione: string;
}

/** Dettagli itinerario. */
export type ItineraryDetails = {
  __typename: string;
  uniqueId: string;
  immagineUrl: string;
  immagini: {
    fileUrl: string;
    traduzioni: {
      titolo: string;
      descrizione: string;
    }[];
  }[];
  tipologie: {
    traduzioni: {
      nome: string;
    }[];
  }[];
  traduzioni: {
    nome: string;
    descrizioneBreve: string;
    descrizioneEstesa: string;
    modalitaDiAccesso: string;
    periodoMigliore: string;
    ulterioriInformazioni: string;
  }[];
  adattoA: {
    traduzioni: {
      nome: string;
    }[];
  }[];
  allegati: {
    traduzioni: {
      titolo: string;
      descrizione: string
    }[];
    file: {
      fileExt: string;
      fileLength: string;
      fileUrl: string;
    };
  }[];
  condizioniDiAccesso: {
    traduzioni: {
      nome: string;
    }[];
  }[];
  contenutiCorrelati: {
    uniqueId: string;
    immagineUrl: string;
    traduzioni: {
      titolo: string;
      descrizioneBreve: string;
    }[];
    tipologiaContenutoApp: {
      nomeEntita: string;
      traduzioni: {
        nome: string;
      }[];
    };
  }[];
  difficolta?: {
    traduzioni: {
      nome: string;
    }[];
  };
  durata?: {
    traduzioni: {
      nome: string;
    }[];
  };
  esperienzeAr: ArElementDetails[];
  percorribilita: {
    traduzioni: {
      nome: string;
    }[];
  }[];
  sponsor: {
    denominazione: string;
    immagineUrl: string;
  }[];
  tappe: {
    ordinamento: string;
    destinazione: {
      uniqueId: string;
      nomeEntita: string;
      immagineUrl: string;
      traduzioni: {
        nome: string;
        descrizioneBreve: string;
      }[];
    };
  }[];
  tourVirtuali: TourVirtuali[];
  video: Video[];
  elementi3D: Elementi3D[];
  matterportSpaces: MatterportSpace[];
};

/** Dettagli evento. */
export type EventDetails = {
  __typename: string;
  uniqueId: string;
  immagineUrl: string;
  immagini: {
    fileUrl: string;
    traduzioni: {
      titolo: string;
      descrizione: string;
    }[];
  }[];
  luoghi: Luoghi[],
  tipologie: {
    traduzioni: {
      nome: string;
    }[];
  }[];
  traduzioni: {
    titolo: string;
    sottotitolo: string;
    descrizioneBreve: string;
    descrizioneEstesa: string;
    aChiERivolto: string;
    infoPerIlbooking: string;
    ulterioriInformazioni: string;
  }[];
  appuntamenti: {
    __typename: any;
    uniqueId: string;
    immagineUrl: string;
    traduzioni: {
      titolo: string;
      sottotitolo: string;
      descrizioneBreve: string;
    }[];
  }[];
  eventoGenitore?: {
    __typename: string | undefined;
    uniqueId: string;
    immagineUrl: string;
    traduzioni: {
      titolo: string;
      sottotitolo: string;
      descrizioneBreve: string;
    }[];
    appuntamenti: {
      uniqueId: string;
      immagineUrl: string;
      __typename: string;
      traduzioni: {
        titolo: string;
      }[];
      tipologie: {
        traduzioni: {
          nome: string;
        }[];
      }[];
    }[];
  };
  dataOraInizio: string;
  dataOraFine: string;
  organizzatoDa: {
    denominazione: string;
    immagineUrl: string;
  }[];
  patrocinatoDa: {
    denominazione: string;
    immagineUrl: string;
  }[];
  persone: {
    nome: string;
    cognome: string;
    competenze: string;
    fotoUrl: string;
  }[];
  puntiDiContatto: {
    tipologia: {
      nome: string;
    };
    sottoTipologia: {
      nome: string;
    };
    valore: string;
  }[];
  adattoA: {
    traduzioni: {
      nome: string;
    }[];
  }[];
  allegati: {
    traduzioni: {
      titolo: string;
      descrizione: string;
    }[];
    file: {
      fileExt: string;
      fileLength: string;
      fileUrl: string;
    };
  }[];
  condizioniDiAccesso: {
    traduzioni: {
      nome: string;
    }[];
  }[];
  costo: number;
  urlAcquistoBiglietto: string;
  contenutiCorrelati: {
    uniqueId: string;
    immagineUrl: string;
    traduzioni: {
      titolo: string;
      descrizioneBreve: string;
    }[];
    tipologiaContenutoApp: {
      nomeEntita: string;
      traduzioni: {
        nome: string;
      }[];
    };
  }[];
  esperienzeAr: ArElementDetails[];
  sponsor: {
    denominazione: string;
    immagineUrl: string;
  }[];
  video: Video[];
};

/** Dettagli punto di interesse. */
export type POIDetails = {
  __typename: string;
  uniqueId: string;
  immagineUrl: string;
  immagini: {
    fileUrl: string;
    traduzioni: {
      titolo: string;
      descrizione: string;
    }[];
  }[];
  puntoDiInteresseGenitore: {
    uniqueId: string
    traduzioni: {
      nome: string
      descrizioneBreve: string
    }[]
    immagineUrl: string
    puntiDiInteresse: {
      uniqueId: string
      traduzioni: {
        nome: string
        descrizioneBreve: string
      }[]
      immagineUrl: string
    }[]
  }
  puntiDiInteresse: {
    __typename: string;
    uniqueId: string
    traduzioni: {
      nome: string
      descrizioneBreve: string
    }[]
    immagineUrl: string
  }[]
  tipologie: {
    traduzioni: {
      nome: string;
    }[];
  }[];
  traduzioni: {
    nome: string;
    descrizioneBreve: string;
    orariPerIlPubblico: string;
    descrizione: string;
    modalitaDiAccesso: string;
    ulterioriInformazioni: string;
  }[];
  puntiDiContatto: {
    tipologia: {
      nome: string;
    };
    sottoTipologia: {
      nome: string;
    };
    valore: string;
  }[];
  latitudine: string;
  longitudine: string;
  indirizzo: string;
  cAP: string;
  circoscrizione: string;
  quartiere: string;
  adattoA: {
    traduzioni: {
      nome: string;
    }[];
  }[];
  accessoGratuito: string;
  allegati: {
    traduzioni: {
      titolo: string;
      descrizione: string;
    }[];
    file: {
      fileExt: string;
      fileLength: number;
      fileUrl: string;
    };
  }[];
  condizioniDiAccesso: {
    traduzioni: {
      nome: string;
    }[];
  }[];
  contenutiCorrelati: {
    uniqueId: string;
    immagineUrl: string;
    traduzioni: {
      titolo: string;
      descrizioneBreve: string;
    }[];
    tipologiaContenutoApp: {
      nomeEntita: string;
      traduzioni: {
        nome: string;
      }[];
    };
  }[];
  esperienzeAr: ArElementDetails[];
  tourVirtuali: TourVirtuali[];
  video: Video[];
  elementi3D: Elementi3D[];
  matterportSpaces: MatterportSpace[];
};

/** Dettagli notizia. */
export type NewsDetails = {
  __typename: string;
  uniqueId: string;
  immagineUrl: string;
  immagini: {
    fileUrl: string;
    traduzioni: {
      titolo: string;
      descrizione: string;
    }[];
  }[];
  traduzioni: {
    titolo: string;
    descrizioneBreve: string;
    testoCompleto: string;
  }[];
  persone: {
    nome: string;
    cognome: string;
    competenze: string;
    fotoUrl: string;
  }[];
  allegati: {
    traduzioni: {
      titolo: string;
      descrizione: string;
    }[];
    file: {
      fileExt: string;
      fileLength: string;
      fileUrl: string;
    };
  }[];
  contenutiCorrelati: {
    uniqueId: string;
    immagineUrl: string;
    traduzioni: {
      titolo: string;
      descrizioneBreve: string;
    }[];
    tipologiaContenutoApp: {
      nomeEntita: string;
      traduzioni: {
        nome: string;
      }[];
    };
  }[];
  esperienzeAr: ArElementDetails[];
  video: Video[];
}

/** Dettagli esperienza. */
export type ExperienceDetails = {
  __typename: string;
  uniqueId: string;
  immagineUrl: string;
  immagini: {
    fileUrl: string;
    traduzioni: {
      titolo: string;
      descrizione: string;
    }[];
  }[];
  traduzioni: {
    nome: string;
    descrizioneBreve: string;
    descrizioneEstesa: string;
    ulterioriInformazioni: string;
  }[];
  tipologie: {
    traduzioni: {
      nome: string;
    }[];
  }[];
  adattoA: {
    traduzioni: {
      nome: string;
    }[];
  }[];
  allegati: {
    traduzioni: {
      titolo: string;
      descrizione: string;
    }[];
    file: {
      fileExt: string;
      fileLength: string;
      fileUrl: string;
    };
  }[];
  condizioniDiAccesso: {
    traduzioni: {
      nome: string;
    }[];
  }[];
  contenutiCorrelati: {
    uniqueId: string;
    immagineUrl: string;
    traduzioni: {
      titolo: string;
      descrizioneBreve: string;
    }[];
    tipologiaContenutoApp: {
      nomeEntita: string;
      traduzioni: {
        nome: string;
      }[];
    };
  }[];
  durata: {
    traduzioni: {
      nome: string;
    }[];
  };
  esperienzeAr: ArElementDetails[];
  video: Video[];
}

/** Dettagli attività commerciale. */
export type CADetails = {
  __typename: string;
  uniqueId: string;
  immagineUrl: string;
  immagini: {
    fileUrl: string;
    traduzioni: {
      titolo: string;
      descrizione: string;
    }[];
  }[];
  traduzioni: {
    nome: string;
    descrizioneBreve: string;
    orariPerIlPubblico: string;
    descrizione: string;
    modalitaDiAccesso: string;
    ulterioriInformazioni: string;
  }[];
  tipologie: {
    traduzioni: {
      nome: string;
    }[];
  }[];
  puntiDiContatto: {
    tipologia: {
      nome: string;
    };
    sottoTipologia: {
      nome: string;
    };
    valore: string;
  }[];
  sitoWeb: string;
  latitudine: string;
  longitudine: string;
  indirizzo: string;
  cAP: string;
  circoscrizione: string;
  quartiere: string;
  adattoA: {
    traduzioni: {
      nome: string;
    }[];
  }[];
  accessoGratuito: string;
  condizioniDiAccesso: {
    traduzioni: {
      nome: string;
    }[];
  }[];
  contenutiCorrelati: {
    uniqueId: string;
    immagineUrl: string;
    traduzioni: {
      titolo: string;
      descrizioneBreve: string;
    }[];
    tipologiaContenutoApp: {
      nomeEntita: string;
      traduzioni: {
        nome: string;
      }[];
    };
  }[];
  esperienzeAr: ArElementDetails[];
  tourVirtuali: TourVirtuali[];
  video: Video[];
  elementi3D: Elementi3D[];
  matterportSpaces: MatterportSpace[];
}

/** Dettagli contenuto informativo. */
export type ICDetails = {
  __typename: string;
  uniqueId: string;
  immagineUrl: string;
  immagini: {
    fileUrl: string;
    traduzioni: {
      titolo: string;
      descrizione: string;
    }[];
  }[];
  traduzioni: {
    nome: string;
    descrizioneBreve: string;
    descrizioneEstesa: string;
  }[];
  tipologie: {
    traduzioni: {
      nome: string;
    }[];
  }[];
  adattoA: {
    traduzioni: {
      nome: string;
    }[];
  }[];
  allegati: {
    traduzioni: {
      titolo: string;
      descrizione: string;
    }[];
    file: {
      fileExt: string;
      fileLength: string;
      fileUrl: string;
    };
  }[];
  condizioniDiAccesso: {
    traduzioni: {
      nome: string;
    }[];
  }[];
  contenutiCorrelati: {
    uniqueId: string;
    immagineUrl: string;
    traduzioni: {
      titolo: string;
      descrizioneBreve: string;
    }[];
    tipologiaContenutoApp: {
      nomeEntita: string;
      traduzioni: {
        nome: string;
      }[];
    };
  }[];
  esperienzeAr: ArElementDetails[];
  video: Video[];
}

/** Dettagli prodotto tipico. */
export type TPDetails = {
  __typename: string;
  uniqueId: string;
  immagineUrl: string;
  immagini: {
    fileUrl: string;
    traduzioni: {
      titolo: string;
      descrizione: string;
    }[];
  }[];
  traduzioni: {
    nome: string;
    descrizioneBreve: string;
    descrizioneEstesa: string;
  }[];
  tipologie: {
    traduzioni: {
      nome: string;
    }[];
  }[];
  allegati: {
    traduzioni: {
      titolo: string;
      descrizione: string;
    }[];
    file: {
      fileExt: string;
      fileLength: string;
      fileUrl: string;
    };
  }[];
  contenutiCorrelati: {
    uniqueId: string;
    immagineUrl: string;
    traduzioni: {
      titolo: string;
      descrizioneBreve: string;
    }[];
    tipologiaContenutoApp: {
      nomeEntita: string;
      traduzioni: {
        nome: string;
      }[];
    };
  }[];
  video: Video[];
}

export type ArElementDetails = {
  allegati: {
    file: {
      fileExt: string
      fileLength: number
      fileUrl: string
    }
    traduzioni: {
      uniqueId: string
      titolo: string
      descrizione: string
    }[]
  }[]
  uniqueId: string,
  tipologiaContenutoApp: {
    container: {
      backColor: string
      coloreDescrizioneItem: string
      coloreTitoloItem: string
      coloreTitoloTipologia: string
    }
    traduzioni:
    {
      nome: string
    }[]
  },
  consigliata: boolean,
  tecnologiaAr: string,
  traduzioni:
  {
    titolo: string,
    istruzioni: string
  }[],
  immagineUrl: string
  immagini: {
    uniqueId: string
    fileUrl: string
    traduzioni: {
      titolo: string,
      descrizione: string
    }[],
  }[],
  arCmsElementId: string
  visibileOnlineDa: string
  visibileOnlineA: string
  __typename: string
}

