import DetailsProvider, { DetailsContext, DetailsContextType, DetailsProviderProps } from "@/components/DetailsProvider/DetailsProvider";
import { ItineraryDetails, EventDetails, POIDetails, NewsDetails, ExperienceDetails, CADetails, ICDetails, TPDetails, ArElementDetails } from "@/components/DetailsProvider/DetailsTypes";

export default DetailsProvider;
export { DetailsContext };
export type { DetailsContextType, DetailsProviderProps };
export type { ItineraryDetails, EventDetails, POIDetails, NewsDetails, ExperienceDetails, CADetails, ICDetails, TPDetails, ArElementDetails  };