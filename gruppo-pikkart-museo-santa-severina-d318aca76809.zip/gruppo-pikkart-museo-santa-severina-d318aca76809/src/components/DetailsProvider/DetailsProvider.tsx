import { useAuth } from "@/hooks/useAuth";
import { AddContenutoVistoRequestDto } from "@/services/openapi";
import { gql, useDataRequest } from "@ai4/data-request";
import { ReactNode, createContext, useCallback, useEffect, useMemo, useState } from "react";
import { useTranslation } from "react-i18next";
import { useLocation } from "react-router-dom";
import { useKey } from "@/hooks/useKeyContext.tsx";

export type DetailsContextType = {
  type: DetailsContentsType;
  uid: string;
  experience: string;
  data: any;
  previewUrl: string;
  loading: boolean;
  isFavourite: boolean;
  addFavourite: (entity: string) => Promise<void>;
  removeFavourite: (entity: string) => Promise<void>;
  appTerritoriale: string;
};

export type ContentType = {
  dataOraFine: string;
  dataOraInizio: string;
  descrizioneBreve: string;
  lat: number;
  lng: number;
  nomeEntita: string;
  titolo: string;
  uniqueId: string;
  urlImmagine: string;
}

export type DetailsProviderProps = {
  children: JSX.Element | ReactNode;
};

export enum DetailsContentsType {
  NONE, ITINERARY, POINT_OF_INTEREST, EVENT, NEWS, EXPERIENCE, COMMERCIAL_ACTIVITY, INFORMATIVE_CONTENT, TYPICAL_PRODUCT, AR_ELEMENT, IMMERSIVE_CONTENT, LOCATION
}

export const DetailsContext = createContext<DetailsContextType>({} as DetailsContextType);

const DetailsProvider = ({ children }: DetailsProviderProps) => {
  const search = useLocation().search;
  const queryStringId = decodeURI(new URLSearchParams(search).get('id') ?? '');
  const queryExperience = decodeURI(new URLSearchParams(search).get('experience') ?? '');
  const queryStringType = Number(decodeURI(new URLSearchParams(search).get('type') ?? ''));
  const queryPreviewUrl = decodeURI(new URLSearchParams(search).get('preview') ?? '');
  const [isFavourite, setFavourite] = useState<boolean>(false)
  const { i18n } = useTranslation()
  const { isLoggedIn } = useAuth();

  const { key, configs } = useKey();

  const { useLazyQuery, useRestRequest } = useDataRequest();

  const [results, setResults] = useState<any>({});

  const ITINERARY_QUERY = gql(`
  query ($id: Guid) {
    itinerariQuery {
      itinerari {
        lista(filtri: { uniqueId: { _eq: $id } }) {
          uniqueId
          immagineUrl
          immagini {
            fileUrl
            traduzioni {
              titolo
              descrizione
            }
          }
          tipologie {
            traduzioni {
              nome
            }
          }
          traduzioni {
            nome
            descrizioneBreve
            descrizioneEstesa
            modalitaDiAccesso
            periodoMigliore
            ulterioriInformazioni
          }
          adattoA {
            traduzioni {
              nome
            }
          }
          allegati {
            traduzioni {
              titolo
              descrizione
            }
            file {
              fileExt
              fileLength
              fileUrl
            }
          }
          condizioniDiAccesso {
            traduzioni {
              nome
            }
          }
          contenutiCorrelati {
            uniqueId
            immagineUrl
            traduzioni {
              titolo
              descrizioneBreve
            }
            tipologiaContenutoApp {
              nomeEntita
              traduzioni {
                nome
              }
            }
          }
          difficolta {
            traduzioni {
              nome
            }
          }
          durata {
            traduzioni {
              nome
            }
          }
          esperienzeAr {
            uniqueId
            traduzioni {
              titolo
            }
            immagineUrl
            arCmsElementId
            tipologiaContenutoApp {
              traduzioni {
                nome
              }
            }
          }
          percorribilita {
            traduzioni {
              nome
            }
          }
          sponsor {
            denominazione
            immagineUrl
          }
          tappe {
            ordinamento
            destinazione {
              uniqueId
              nomeEntita
              immagineUrl
              traduzioni {
                nome
                descrizioneBreve
              }
            }
          }
          tourVirtuali {
            uniqueId
            traduzioni {
              titolo
              descrizione
            }
            previewFileUrl
            codice
          }
          video {
            uniqueId
            previewFileUrl
            fileUrl
            urlYoutube
            traduzioni {
              titolo
              descrizione
            }
            tipologia
          }
          elementi3D {
            uniqueId
            traduzioni {
              titolo
              descrizione
            }
            fileUrl
            previewFileUrl
          }
          matterportSpaces {
            uniqueId
            codice
            previewFileUrl
            matterportAccount {
              chiaveSdk
            }
            traduzioni {
              titolo
              descrizione
            }
          }
        }
      }
    }
  }
          `);

  const EVENT_QUERY = gql(`
query ($id: Guid) {
  eventiQuery {
    eventi {
      lista(filtri: { uniqueId: { _eq: $id } }) {
        uniqueId
        immagineUrl
        immagini {
          fileUrl
          traduzioni {
            titolo
            descrizione
          }
        }
        tipologie {
          traduzioni {
            nome
          }
        }
        luoghi{
          uniqueId
          nome
          indirizzo
          cAP
          descrizione
          immagineUrl
          latitudine
          longitudine
        }
        traduzioni {
          titolo
          sottotitolo
          descrizioneBreve
          descrizioneEstesa
          aChiERivolto
          infoPerIlbooking
          ulterioriInformazioni
        }
        appuntamenti {
          uniqueId
          immagineUrl
          traduzioni {
            titolo
            sottotitolo
            descrizioneBreve
          }
        }
        eventoGenitore {
          uniqueId
          immagineUrl
          traduzioni {
            titolo
            sottotitolo
            descrizioneBreve
          }
          appuntamenti {
            uniqueId
            immagineUrl
            traduzioni {
              titolo
            }
            tipologie {
              traduzioni {
                nome
              }
            }
          }
        }
        dataOraInizio
        dataOraFine
        organizzatoDa {
          denominazione
          immagineUrl
        }
        patrocinatoDa {
          denominazione
          immagineUrl
        }
        persone {
          nome
          cognome
          competenze
          fotoUrl
        }
        puntiDiContatto {
          tipologia {
            nome
          }
          sottoTipologia {
            nome
          }
          valore
        }
        adattoA {
          traduzioni {
            nome
          }
        }
        allegati {
          traduzioni {
            titolo
            descrizione
          }
          file {
            fileExt
            fileLength
            fileUrl
          }
        }
        condizioniDiAccesso {
          traduzioni {
            nome
          }
        }
        costo
        urlAcquistoBiglietto
        contenutiCorrelati {
          uniqueId
          immagineUrl
          traduzioni {
            titolo
            descrizioneBreve
          }
          tipologiaContenutoApp {
            nomeEntita
            traduzioni {
              nome
            }
          }
        }
        esperienzeAr {
          uniqueId
          traduzioni {
            titolo
          }
          immagineUrl
          arCmsElementId
          tipologiaContenutoApp {
              traduzioni {
                nome
              }
            }
        }
        sponsor {
          denominazione
          immagineUrl
        }
        video {
          uniqueId
          previewFileUrl
          fileUrl
          urlYoutube
          traduzioni {
            titolo
            descrizione
          }
          tipologia
        }
      }
    }
  }
}
          `);

  const POI_QUERY = gql(`
query ($id: Guid) {
  puntiDiInteresseQuery {
    puntiDiInteresse {
      lista(
        filtri: { uniqueId: { _eq: $id } }
      ) {
        uniqueId
        immagineUrl
        immagini {
          fileUrl
          traduzioni {
            titolo
            descrizione
          }
        }
        tipologie {
          traduzioni {
            nome
          }
        }
        traduzioni {
          nome
          descrizioneBreve
          orariPerIlPubblico
          descrizione
          modalitaDiAccesso
          ulterioriInformazioni
        }
        puntoDiInteresseGenitore {
					uniqueId
					traduzioni {
						nome
						descrizioneBreve
					}
					immagineUrl
					puntiDiInteresse {
						uniqueId
						traduzioni {
							nome
							descrizioneBreve
						}
						immagineUrl
					}
				}
        puntiDiInteresse {
          uniqueId
          traduzioni {
            nome
            descrizioneBreve
          }
          immagineUrl
        }
        puntiDiContatto {
          tipologia {
            nome
          }
          sottoTipologia {
            nome
          }
          valore
        }
        latitudine
        longitudine
        indirizzo
        cAP
        circoscrizione
        quartiere
        adattoA {
          traduzioni {
            nome
          }
        }
        accessoGratuito
        allegati {
          traduzioni {
            titolo
            descrizione
          }
          file {
            fileExt
            fileLength
            fileUrl
          }
        }
        condizioniDiAccesso {
          traduzioni {
            nome
          }
        }
        contenutiCorrelati {
          uniqueId
          immagineUrl
          traduzioni {
            titolo
            descrizioneBreve
          }
          tipologiaContenutoApp {
            nomeEntita
            traduzioni {
              nome
            }
          }
        }
        esperienzeAr {
          uniqueId
          traduzioni {
            titolo
          }
          immagineUrl
          arCmsElementId
          tipologiaContenutoApp {
              traduzioni {
                nome
              }
            }
        }
        tourVirtuali {
          uniqueId
          traduzioni {
            titolo
            descrizione
          }
          previewFileUrl
          codice
        }
        video {
          uniqueId
          previewFileUrl
          fileUrl
          urlYoutube
          traduzioni {
            titolo
            descrizione
          }
          tipologia
        }
        elementi3D {
          uniqueId
          traduzioni {
            titolo
            descrizione
          }
          fileUrl
          previewFileUrl
        }
        matterportSpaces {
          uniqueId
          codice
          previewFileUrl
          matterportAccount {
            chiaveSdk
          }
          traduzioni {
              titolo
              descrizione
            }
        }
      }
    }
  }
}
  `);

  const NEWS_QUERY = gql(`
  query ($id: Guid) {
  notizieQuery {
    notizie {
      lista(
        filtri: { uniqueId: { _eq: $id } }
      ) {
        uniqueId
        immagineUrl
        immagini {
          fileUrl
          traduzioni {
            titolo
            descrizione
          }
        }
        traduzioni {
          titolo
          descrizioneBreve
          testoCompleto
        }
        persone {
          nome
          cognome
          competenze
          fotoUrl
        }
        allegati {
          traduzioni {
            titolo
            descrizione
          }
          file {
            fileExt
            fileLength
            fileUrl
          }
        }
        contenutiCorrelati {
          uniqueId
          immagineUrl
          traduzioni {
            titolo
            descrizioneBreve
          }
          tipologiaContenutoApp {
            nomeEntita
            traduzioni {
              nome
            }
          }
        }
        esperienzeAr {
          uniqueId
          traduzioni {
            titolo
          }
          immagineUrl
          arCmsElementId
          tipologiaContenutoApp {
              traduzioni {
                nome
              }
            }
        }
        video {
          uniqueId
          previewFileUrl
          fileUrl
          urlYoutube
          traduzioni {
            titolo
            descrizione
          }
          tipologia
        }
      }
    }
  }
}
  `);

  const EXPERIENCE_QUERY = gql(`
query ($id: Guid) {
  esperienzeQuery {
    esperienze {
      lista(filtri: { uniqueId: { _eq: $id } }) {
        uniqueId
        immagineUrl
        immagini {
          fileUrl
          traduzioni {
            titolo
            descrizione
          }
        }
        tipologie {
          traduzioni {
            nome
          }
        }
        traduzioni {
          nome
          descrizioneBreve
          descrizioneEstesa
          ulterioriInformazioni
        }
        adattoA {
          traduzioni {
            nome
          }
        }
        allegati {
          traduzioni {
            titolo
            descrizione
          }
          file {
            fileExt
            fileLength
            fileUrl
          }
        }
        condizioniDiAccesso {
          traduzioni {
            nome
          }
        }
        contenutiCorrelati {
          uniqueId
          immagineUrl
          traduzioni {
            titolo
            descrizioneBreve
          }
          tipologiaContenutoApp {
            nomeEntita
            traduzioni {
              nome
            }
          }
        }
        durata {
          traduzioni {
            nome
          }
        }
        esperienzeAr {
          uniqueId
          traduzioni {
            titolo
          }
          immagineUrl
          arCmsElementId
          tipologiaContenutoApp {
              traduzioni {
                nome
              }
            }
        }
        video {
          uniqueId
          previewFileUrl
          fileUrl
          urlYoutube
          traduzioni {
            titolo
            descrizione
          }
          tipologia
        }
      }
    }
  }
}
  `);

  const COMMERCIAL_ACTIVITY_QUERY = gql(`
query ($id: Guid) {
  attivitaCommercialiQuery {
    attivitaCommerciali {
      lista(
        filtri: { uniqueId: { _eq: $id } }
      ) {
        uniqueId
        immagineUrl
        immagini {
          fileUrl
          traduzioni {
            titolo
            descrizione
          }
        }
        traduzioni {
          nome
          descrizioneBreve
          orariPerIlPubblico
          descrizione
          modalitaDiAccesso
          ulterioriInformazioni
        }
        tipologie {
          traduzioni {
            nome
          }
        }
        puntiDiContatto {
          tipologia {
            nome
          }
          sottoTipologia {
            nome
          }
          valore
        }
        sitoWeb
        latitudine
        longitudine
        indirizzo
        cAP
        circoscrizione
        quartiere
        adattoA {
          traduzioni {
            nome
          }
        }
        accessoGratuito
        condizioniDiAccesso {
          traduzioni {
            nome
          }
        }
        contenutiCorrelati {
          uniqueId
          immagineUrl
          traduzioni {
            titolo
            descrizioneBreve
          }
          tipologiaContenutoApp {
            nomeEntita
            traduzioni {
              nome
            }
          }
        }
        esperienzeAr {
          uniqueId
          traduzioni {
            titolo
          }
          immagineUrl
          arCmsElementId
          tipologiaContenutoApp {
              traduzioni {
                nome
              }
            }
        }
        tourVirtuali { 
          uniqueId
          traduzioni {
            titolo
            descrizione
          }
          previewFileUrl
          codice
        }
        video {
          uniqueId
          previewFileUrl
          fileUrl
          urlYoutube
          traduzioni {
            titolo
            descrizione
          }
          tipologia
        }
        elementi3D {
          uniqueId
          traduzioni {
            titolo
            descrizione
          }
          fileUrl
          previewFileUrl
        }
        matterportSpaces {
          uniqueId
          codice
          previewFileUrl
          matterportAccount {
            chiaveSdk
          }
          traduzioni {
              titolo
              descrizione
            }
        }
      }
    }
  }
}
  `);

  const INFORMATIVE_CONTENT_QUERY = gql(`
query ($id: Guid) {
  contenutiInformativiAppQuery {
    contenutiInformativiApp {
      lista(
        filtri: { uniqueId: { _eq: $id } }
      ) {
        uniqueId
        immagineUrl
        immagini {
          fileUrl
          traduzioni {
            titolo
            descrizione
          }
        }
        traduzioni {
          nome
          descrizioneBreve
          descrizioneEstesa
        }
        tipologie {
          traduzioni {
            nome
          }
        }
        adattoA {
          traduzioni {
            nome
          }
        }
        allegati {
          traduzioni {
            titolo
            descrizione
          }
          file {
            fileExt
            fileLength
            fileUrl
          }
        }
        condizioniDiAccesso {
          traduzioni {
            nome
          }
        }
        contenutiCorrelati {
          uniqueId
          immagineUrl
          traduzioni {
            titolo
            descrizioneBreve
          }
          tipologiaContenutoApp {
            nomeEntita
            traduzioni {
              nome
            }
          }
        }
        esperienzeAr {
          uniqueId
          traduzioni {
            titolo
          }
          immagineUrl
          arCmsElementId
          tipologiaContenutoApp {
              traduzioni {
                nome
              }
            }
        }
        video {
          uniqueId
          previewFileUrl
          fileUrl
          urlYoutube
          traduzioni {
            titolo
            descrizione
          }
          tipologia
        }
      }
    }
  }
}
  `);

  const TYPICAL_PRODUCT_QUERY = gql(`
query ($id: Guid) {
  prodottiTipiciQuery {
    prodottiTipici {
      lista(
        filtri: { uniqueId: { _eq: $id } }
      ) {
        uniqueId
        immagineUrl
        immagini {
          fileUrl
          traduzioni {
            titolo
            descrizione
          }
        }
        traduzioni {
          nome
          descrizioneBreve
          descrizioneEstesa
        }
        tipologie {
          traduzioni {
            nome
          }
        }
        allegati {
          traduzioni {
            titolo
            descrizione
          }
          file {
            fileExt
            fileLength
            fileUrl
          }
        }
        contenutiCorrelati {
          uniqueId
          immagineUrl
          traduzioni {
            titolo
            descrizioneBreve
          }
          tipologiaContenutoApp {
            nomeEntita
            traduzioni {
              nome
            }
          }
        }
        video {
          uniqueId
          previewFileUrl
          fileUrl
          urlYoutube
          traduzioni {
            titolo
            descrizione
          }
          tipologia
        }
      }
    }
  }
}
  `);

  const AR_ELEMENT_QUERY = gql(`
  query($id: Guid) {
    esperienzeArQuery {
    esperienzeAR {
    lista (filtri : { uniqueId: {_eq: $id}}){
          uniqueId
          tipologiaContenutoApp {
            tipologiaLayout
            container{
              backColor
              coloreTitoloItem
              coloreDescrizioneItem
              coloreTitoloTipologia
              }
            traduzioni {
              nome
            }
          }
          consigliata
          tecnologiaAr
          traduzioni {
            titolo
            istruzioni
          }
          immagineUrl
          immagini {
            uniqueId
            fileUrl
            traduzioni {
              uniqueId
              titolo
              descrizione
            }
          }
          arCmsElementId
          allegati {
            traduzioni {
              uniqueId
              titolo
              descrizione
            }
            file {
              fileExt
              fileLength
              fileUrl
            }
          }
          immagini {
            traduzioni {
              titolo
              descrizione
            }
            file {
              fileExt
              fileLength
              fileUrl
            }
          }
          visibileOnlineDa
          visibileOnlineA
        }
      }
    }
  }`);

  const AR_CONTENT_QUERY = gql(`
    query ($id: String) {
      esperienzeArQuery {
        esperienzeAR {
          lista (
            filtri: { arCmsElementId: { _eq: $id } }
          ) {
            uniqueId
            tipologiaContenutoApp {
              traduzioni {
                nome
              }
            }
            consigliata
            tecnologiaAr
            traduzioni {
              titolo
              istruzioni
            }
            immagineUrl
            immagini {
              traduzioni {
                titolo
                descrizione
              }
              fileUrl
            }
            arCmsElementId
            allegati {
              traduzioni {
                titolo
                descrizione
              }
              file {
                fileExt
                fileLength
                fileUrl
              }
            }
            immagini {
              traduzioni {
                titolo
                descrizione
              }
              file {
                fileExt
                fileLength
                fileUrl
              }
            }
          }
        }
      }
    }
  `)


  const getQuery = () => {
    switch (queryStringType) {
      case DetailsContentsType.ITINERARY:
        return ITINERARY_QUERY;
      case DetailsContentsType.EVENT:
        return EVENT_QUERY;
      case DetailsContentsType.POINT_OF_INTEREST:
        return POI_QUERY;
      case DetailsContentsType.NEWS:
        return NEWS_QUERY;
      case DetailsContentsType.EXPERIENCE:
        return EXPERIENCE_QUERY;
      case DetailsContentsType.COMMERCIAL_ACTIVITY:
        return COMMERCIAL_ACTIVITY_QUERY;
      case DetailsContentsType.INFORMATIVE_CONTENT:
        return INFORMATIVE_CONTENT_QUERY;
      case DetailsContentsType.TYPICAL_PRODUCT:
        return TYPICAL_PRODUCT_QUERY;
      case DetailsContentsType.AR_ELEMENT:
        return AR_ELEMENT_QUERY;
      case DetailsContentsType.IMMERSIVE_CONTENT:
        return AR_CONTENT_QUERY


      default:
        return ITINERARY_QUERY;
    }
  };

  const [fetch, { loading, data }] = useLazyQuery<any>(getQuery());

  const [addNewFavourite] = useRestRequest({
    path: 'rest/{ver}/app/contenuti-preferiti',
    headers: {
      'Content-Type': 'application/json',
      'Content-Language': i18n.language.split('-')[0]
    },
    method: 'POST',
    jwt: true
  });

  const [removeNewFavourite] = useRestRequest({
    path: 'rest/{ver}/app/contenuti-preferiti',
    headers: {
      'Content-Type': 'application/json',
      'Content-Language': i18n.language.split('-')[0]
    },
    method: 'DELETE',
    jwt: true
  });

  const [favourite, { data: favouriteData }] = useRestRequest({
    path: 'rest/{ver}/app/contenuti-preferiti',
    headers: {
      'Content-Type': 'application/json',
      'Content-Language': i18n.language.split('-')[0]
    },
    method: 'GET',
    jwt: true
  });

  const appTerritoriale = useMemo(() => {

    if(configs?.AppTerritoriale && configs?.AppTerritoriale === "true"){
      return configs?.AppTerritoriale
    } else {
      return 'false'
    }
      
  }, [configs])


  useEffect(() => {
    if (isLoggedIn) {
      void favourite()
    }
  }, [favourite, queryStringId, isLoggedIn])

  useEffect(() => {
    if (favouriteData) {
      // console.log('favoriti', favouriteData, queryStringId)
      const favData = favouriteData as (AddContenutoVistoRequestDto & { contenuti: ContentType[] })[]
      for (const el of favData) {
        if (el.contenuti.find(f => f.uniqueId === queryStringId)) {
          setFavourite(true)
          break;
        }
      }
    }
  }, [favouriteData, queryStringId])

  const addFavourite = useCallback(async (entity: string) => {
    if (isLoggedIn) {
      const body = {
        data: {
          codiceLingua: i18n.language,
          contenutoUniqueId: queryStringId,
          nomeEntita: entity
        } as AddContenutoVistoRequestDto
      }
      await addNewFavourite(body).then(() => { setFavourite(true) }).catch(err => console.log(err))
    }
  }, [addNewFavourite, i18n.language, queryStringId, isLoggedIn])

  const removeFavourite = useCallback(async (entity: string) => {
    if (isLoggedIn) {
      const body = {
        data: {
          codiceLingua: i18n.language,
          contenutoUniqueId: queryStringId,
          nomeEntita: entity
        } as AddContenutoVistoRequestDto
      }
      await removeNewFavourite(body).then(() => { setFavourite(false) }).catch(err => console.log(err))
    }
  }, [i18n.language, isLoggedIn, queryStringId, removeNewFavourite])

  useEffect(() => {
    if (data || isNaN(queryStringType) || queryStringId == '') {
      return;
    }
    console.log('queryStringId', queryStringId)
    void fetch({
      context: {
        headers: {
          'Content-Language': i18n.language.split('-')[0], // FIXME: da configurazione
          'x-api-key': key
        }
      },
      variables: {
        'id': queryStringId,
      },
    });
  }, [fetch, data, queryStringType, queryStringId, i18n.language, key]);

  useEffect(() => {
    if (!data) {
      return;
    }
    console.log(data)
    setResults(data);
  }, [data]);


  const value: DetailsContextType = useMemo(() => {
    return {
      type: queryStringType,
      uid: queryStringId,
      experience: queryExperience,
      previewUrl: queryPreviewUrl,
      data: results,
      loading,
      isFavourite,
      addFavourite,
      removeFavourite,
      appTerritoriale
    }
  }, [addFavourite, isFavourite, loading, queryExperience, queryPreviewUrl, queryStringId, queryStringType, removeFavourite, results, appTerritoriale])

  return (
    <DetailsContext.Provider value={value}>
      {children}
    </DetailsContext.Provider>
  );
};

export default DetailsProvider;

