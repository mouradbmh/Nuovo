import { useAppContext } from "@/hooks/useAppContext";
import { useProfile } from "@/hooks/useProfile";
import { createContext, useEffect, useState } from "react";

export type OnboardingContextType = {
  showOnboarding?: boolean;
  onViewOnboarding?: () => void;
};

export const OnboardingContext = createContext<OnboardingContextType>({} as OnboardingContextType);

type Props = {
  children: JSX.Element | React.ReactNode;
};

const OnboardingProvider = ({ children }: Props) => {
  const [showOnboarding, setShowOnboarding] = useState<boolean>(false);
  const { config } = useAppContext()
  const { saveProfile } = useProfile();

  useEffect(() => {
    setShowOnboarding(localStorage.getItem("showOnboarding") !== "false")
  }, []);

  useEffect(() => {
    if ((config?.messaggiOnBoarding && config?.messaggiOnBoarding?.length === 0)) {
      onViewOnboarding();
      saveProfile();
    }
  }, [config?.messaggiOnBoarding, saveProfile])

  const onViewOnboarding = () => {
    localStorage.setItem("showOnboarding", "false");
    setShowOnboarding(false);
  };

  return (
    <OnboardingContext.Provider
      value={{
        showOnboarding: showOnboarding,
        onViewOnboarding: onViewOnboarding,
      }}
    >
      {children}
    </OnboardingContext.Provider>
  );
};

export default OnboardingProvider;
