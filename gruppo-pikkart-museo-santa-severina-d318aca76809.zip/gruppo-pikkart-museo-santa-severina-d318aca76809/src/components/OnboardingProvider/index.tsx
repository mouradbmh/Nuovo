import OnboardingProvider from "@/components/OnboardingProvider/OnboardingProvider";
import { OnboardingContext } from "@/components/OnboardingProvider/OnboardingProvider";
import { OnboardingContextType } from "@/components/OnboardingProvider/OnboardingProvider";

export default OnboardingProvider;
export { OnboardingContext };
export type { OnboardingContextType };
