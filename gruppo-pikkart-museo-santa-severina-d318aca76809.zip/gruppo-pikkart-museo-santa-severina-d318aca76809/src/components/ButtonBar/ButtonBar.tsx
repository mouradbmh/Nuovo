import classes from '@/components/ButtonBar/buttonBar.module.css';
import { ArrowRight, Users } from 'react-feather';
import TextSubtext from '@/components/TextSubtext';
import { styled } from 'styled-components';

type ButtonBarProps = {
    text_key: string;
    text_color?: string;
    text_subtext_key?: string;
    text_subtext_color?: string;
    button_text_key: string;
    icon?: JSX.Element;
    backColor?: string;
    button_text_color?: string;
    showArrow?: boolean;
    onClick: () => void;
};

const StyledButton = styled.button<{ backcolor: string, color: string }>`
  background-color: ${props => props.backcolor};
  color: ${props => props.color};
`;

const ButtonBar = ({
    text_key,
    text_color = "var(--zinc-900)",
    text_subtext_key = "",
    text_subtext_color = "var(--zinc-500)",
    button_text_key,
    icon = <Users size={24} strokeWidth={1.5} color='var(--zinc-900)' />,
    backColor = "var(--emerald-700)",
    button_text_color = "white",
    showArrow = true,
    onClick,
}: ButtonBarProps) => {
    return (
        <div className={classes.container}>
            <div className={classes.label}>
                {icon}
                <TextSubtext
                    textProps={{
                        text_key: text_key,
                        text_size: "regular",
                        color: text_color,
                    }}
                    subtextProps={{
                        text_key: text_subtext_key,
                        text_size: "small",
                        color: text_subtext_color,
                    }}
                />
            </div>
            <div>
                <StyledButton color={button_text_color} backcolor={backColor} className={classes.button} onClick={onClick}>
                    <div className={classes.button_text_container}>
                        <TextSubtext
                            textProps={{
                                text_key: button_text_key,
                                text_weight: "medium"
                            }}
                        />
                        {showArrow && <ArrowRight size={16} />}
                    </div>
                </StyledButton>
            </div>
        </div>
    );
};

export default ButtonBar;
