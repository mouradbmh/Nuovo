import CheckBox, {InputProps} from "@/components/Checkbox/Checkbox";

export default CheckBox;

export type { InputProps };