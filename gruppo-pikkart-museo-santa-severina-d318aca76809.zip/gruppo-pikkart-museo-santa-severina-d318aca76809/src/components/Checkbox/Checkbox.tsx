import classes from '@/components/Checkbox/checkbox.module.css';
import { Check } from 'react-feather';
import { styled } from 'styled-components';

const StyledDiv = styled.div<{ bordercolor: string }>`
    border: 1px solid ${props => props.bordercolor};
`;

export type InputProps = {
    size?: number,
    checked: boolean,
    onChange: () => void,
    borderColor?: string,
    label?: JSX.Element
}

const Checkbox = ({ size = 15, checked, onChange, borderColor = "var(--sky-base)", label }: InputProps) => {
    const checkBoxClasses = [classes.container];

    if (checked) {
        checkBoxClasses.push(classes.active);
    }

    return (
        <StyledDiv bordercolor={"white"} className={classes.container} onClick={() => onChange()}>
            {label}
            <StyledDiv bordercolor={borderColor} className={checkBoxClasses.join(' ')}>
                <Check size={size} color="var(--outline-bg)" strokeWidth={3} />
            </StyledDiv>

        </StyledDiv>
    );
};

export default Checkbox;