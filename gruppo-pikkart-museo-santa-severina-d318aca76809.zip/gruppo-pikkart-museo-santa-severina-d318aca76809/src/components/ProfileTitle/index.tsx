import ProfileTitle from "@/components/ProfileTitle/ProfileTitle";

export default ProfileTitle;
