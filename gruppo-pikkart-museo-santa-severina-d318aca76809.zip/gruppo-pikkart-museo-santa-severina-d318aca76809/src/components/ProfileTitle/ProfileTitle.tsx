import { styled } from "styled-components";
import classes from "@/components/ProfileTitle/profileTitle.module.css";
import TextSubtext from "../TextSubtext";

export type ProfileTitleProps = {
    user_full_name?: string;
    user_email?: string;
    back_color?: string;
    color?: string;
};

const StyledDiv = styled.div<{ backcolor?: string }>`
  ${props => props.backcolor !== undefined ? `background-color: ${props.backcolor};` : ''}
`;

const ProfileTitle = ({
    user_full_name = "Nome Cognome",
    user_email = "email@email.com",
    back_color = "transparent",
    color = "var(--zinc-900)"
}: ProfileTitleProps) => {
    return (
        <StyledDiv backcolor={back_color} className={classes.column_container}>
            <div className={classes.row_container}>
                <div className={classes.title_container}>
                    <TextSubtext
                        textProps={{
                            text_key: user_full_name,
                            text_size: "title3",
                            text_weight: "bold",
                            color: color,
                        }}
                    />
                    <TextSubtext
                        textProps={{
                            text_key: user_email,
                            text_size: "regular",
                            color: color,
                        }}
                    />
                </div>
            </div>
        </StyledDiv>
    );
};

export default ProfileTitle;
