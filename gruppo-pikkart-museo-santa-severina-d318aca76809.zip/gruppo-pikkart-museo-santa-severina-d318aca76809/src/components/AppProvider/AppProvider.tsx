import { useDataRequest } from "@ai4/data-request";
import { Dispatch, ReactNode, SetStateAction, createContext, useEffect, useState } from "react";
import { ArGeoCoordDto, ConfigurazioneAppDto, MessaggioOnBoardingDto, ProfiloAppDto } from "@/services/openapi";
import { useKey } from "@/hooks/useKeyContext";
import i18n from "i18next";
import { ScreenType } from "../ProfileProvider";


export type AppConfiguration = {
    nome?: string | null;
    payoff?: string | null;
    urlLogo?: string | null
    messaggioHome?: string | null;
    mostraAllertaMeteo?: boolean;
    urlAllertaMeteo?: string | null;
    messaggiOnBoarding?: Array<MessaggioOnBoardingDto> | null;
    arGeoCoords?: Array<ArGeoCoordDto> | null;
    profiliUtente?: Array<ProfiloAppDto> | null;
    urlApplicazioneWeb?: string | null;
    applicationAuth?: string,
    urlTerminiDiServizio?: string,
    urlPrivacyPolicy?: string;
    registrazioneUtente?: boolean;
    autenticazioneTramiteIdentitaDigitale?: boolean;
    autenticazioneBasic?: boolean;
};

export type TenantArKey = {
    tenantId: string;
    arCmsClientAccessKey: string
}

export type ThemeConfiguration = Omit<ConfigurazioneAppDto, keyof AppConfiguration>;

export type AppContextType = {
    config?: AppConfiguration
    theme?: ThemeConfiguration,
    toScreen?: ScreenType,
    loading: boolean,
    error?: any,
    videos: any,
    addVideoRef: (x: any) => void,
    stopPlayback: () => void,
    arKey: TenantArKey[];
    setArKey: Dispatch<SetStateAction<TenantArKey[]>>,
    contentOrderId: string[],
    setContentOrder: Dispatch<SetStateAction<string[]>>
};

const defaultConfig: AppConfiguration = {
    nome: null,
    payoff: null,
    urlLogo: null,
    messaggioHome: null,
    mostraAllertaMeteo: false,
    urlAllertaMeteo: null,
    messaggiOnBoarding: null,
    arGeoCoords: null,
    profiliUtente: null,
    urlApplicazioneWeb: null,
    applicationAuth: undefined,
    urlPrivacyPolicy: undefined,
    urlTerminiDiServizio: undefined,
    registrazioneUtente: undefined,
    autenticazioneTramiteIdentitaDigitale: undefined,
    autenticazioneBasic: undefined,
};

const isAppConfigurationKey = (key: string): key is keyof AppConfiguration => {
    return defaultConfig.hasOwnProperty(key);
};

export const AppContext = createContext<AppContextType>({} as AppContextType);


type Props = {
    children: JSX.Element | ReactNode;
};

const AppProvider = ({ children }: Props) => {
    const { key } = useKey()
    const [theme, setTheme] = useState<ThemeConfiguration>();
    const [config, setConfig] = useState<AppConfiguration>(defaultConfig);
    const [videoRef, setVideoRef] = useState<HTMLVideoElement[]>([])
    const [arKey, setArKey] = useState<TenantArKey[]>([])
    const [contentOrderId, setContentOrder] = useState<string[]>([])
    const { useRestRequest } = useDataRequest();

    const [goToScreen, setGoToScreen] = useState<ScreenType>('location')

    const [fetch, { data, loading, error }] = useRestRequest({
        path: 'rest/{ver}/app/configurazioni',
        headers: {
            'Content-Type': 'application/json',
            'Content-Language': i18n.language.split('-')[0]
        },
        method: 'GET',
        xAPIKey: key
    });

    // useEffect(() => {
    //     if(authDomain === ''){
            
    //     }
    // }, [authDomain, data]);

    const addVideoRef = (x: HTMLVideoElement) => {
        const arr = [...videoRef]
        arr.push(x);
        setVideoRef(arr)
    }

    const stopPlayback = () => {
        videoRef.forEach(vid => {
            vid.pause()
        })
    }

    useEffect(() => {
        if (data) {
            console.log(data)
            return;
        }
        void fetch();
    }, [data, fetch]);

    useEffect(() => {
        if (!data) {
            return;
        }
        const dataDto = data as ConfigurazioneAppDto;
        Object.keys(dataDto).forEach((key) => {
            if (isAppConfigurationKey(key)) {
                setConfig((prev) => ({
                    ...prev,
                    [key]: dataDto[key],
                }));
            } else {
                setTheme((prev) => ({
                    ...prev,
                    [key]: dataDto[key as keyof ThemeConfiguration],
                }));
            }

        });
        // console.log('data', data);
    }, [data]);

    useEffect(() => {
        if(data){
            if(localStorage.getItem('showOnboarding') !== 'false'){
                if(data?.profiliUtente?.length == 1){
                    if(data?.messaggiOnBoarding?.length > 0){ //>
                        //SHOW ONBOARDING
                        // setGoToScreen('profile')
                        setGoToScreen("profile")
                    } else {
                        //DONT SHOW ONBOARDING
                        setGoToScreen("onboarding")
                        
                    }
                } else {
                    if(data?.messaggiOnBoarding?.length > 0){
                        setGoToScreen("onboarding")
                        // console.log("goToOnboarding")
                    } else {

                        //HOME
                        // setGoToScreen('home')
                    }
                }
            } else {
                // console.log("onBoarding = true")
            }
        }
        
    },[data])

    const value: AppContextType = {
        config: config,
        theme: theme,
        toScreen: goToScreen,
        loading,
        error,
        addVideoRef,
        videos: videoRef,
        stopPlayback,
        arKey,
        setArKey,
        contentOrderId,
        setContentOrder
    };

    return (
        <AppContext.Provider value={value}>
            {children}
        </AppContext.Provider>
    )
}

export default AppProvider;
