import AppProvider from "@/components/AppProvider/AppProvider";
import { AppContextType, AppContext } from "@/components/AppProvider/AppProvider";

export default AppProvider;
export { AppContext };
export type { AppContextType };
