import FiltersList, { FiltersListProps } from '@/components/FiltersList/FiltersList';

export default FiltersList;
export type { FiltersListProps };