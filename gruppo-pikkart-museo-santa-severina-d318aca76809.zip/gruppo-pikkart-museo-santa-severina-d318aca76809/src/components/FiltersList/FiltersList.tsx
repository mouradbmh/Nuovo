import { Swiper, SwiperSlide } from 'swiper/react';
import { Pagination } from 'swiper/modules';

import Skeleton from 'react-loading-skeleton'
import 'react-loading-skeleton/dist/skeleton.css'

import 'swiper/css';
import 'swiper/css/pagination';
import "react-sliding-pane/dist/react-sliding-pane.css";

import DottyIcons from '@/components/DottyIcons';
import classes from '@/components/FiltersList/filtersList.module.css';
import TextComponent from '@/components/TextComponent';
import { useCallback, useMemo, useRef, useState } from 'react';
import IconTextButton from '@/components/IconTextButton';
import { ChevronDown } from 'react-feather';
import DatePickerPane from '@/components/DatePickerPane';
import OptionsListPane from '@/components/OptionsListPane';
import { useSearch } from '@/hooks/useSearch';
import { useTranslation } from 'react-i18next';
import LazyImage from '../LazyImage';
import { useKey } from '@/hooks/useKeyContext';

export interface FiltersListProps {
  className?: string;
  collapsed?: boolean;
}

const FiltersList = ({
  className,
  collapsed
}: FiltersListProps) => {
  const { filters, loadingFilters, selectedDates, setSelectedDates, selectedFilter, setSelectedFilter, filtersSubfilters, refSubfilterStates, filterType } = useSearch();
  const { t } = useTranslation();
  const [openPane, setOpenPane] = useState<number>(-1);
  const changedSelection = useRef(false);
  const { configs } = useKey()

  const getDefaultIcon = useCallback((name: string) => {
    switch (name) {
      case 'ProdottoTipico':
        return DottyIcons.Mangiare

      case 'Esperienza':
        return DottyIcons.Esperienze

      case 'Itinerario':
        return DottyIcons.Itinerario

      case 'PuntoDiInteresse':
        return DottyIcons.PuntiInteresse

      case 'Notizia':
        return DottyIcons.News

      case 'AttivitaCommerciale':
        return DottyIcons.Shop

      case 'Evento':
        return DottyIcons.Eventi

      case 'ContenutoInformativoApp':
        return DottyIcons.News

      default:
        return DottyIcons.Dormire
    }
  }, [filterType])

  const iconMap = useMemo(() => {
    if (!filterType || (filterType && filterType.length === 0)) {
      return []
    }
    console.log('filtertype', filterType)
    return filterType.map(el => {
      return {
        name: el.nome,
        Icon: getDefaultIcon(el.nomeEntita),
        iconUrl: el.urlIcona,
        id: el.uniqueId
      }
    })
  }, [filterType])

  if (filterType.length === 0) {
    console.log('loadingfilterstate', loadingFilters, !filters, !filtersSubfilters);

    return <div className={className}>
      <div className={classes.filters_container_skeleton}>
        <div className={[classes.filters_skeletons, classes.slider_above].join(' ')}>
          {
            [...Array(6).keys()].map((_, i) => {
              return <div className={classes.filter_skeleton} key={i}>
                <Skeleton width={72} height={72} circle />
                <Skeleton height={16} />
              </div>
            })
          }
        </div>
        <div className={classes.subfilters_skeleton}>
          {
            [...Array(3).keys()].map((_, i) => {
              return <Skeleton containerClassName={classes.empty_subfilter} height={32} borderRadius={'50vh'} key={i} />
            })
          }
        </div>
      </div>
    </div>
  }

  console.log('filters', filters)

  // const iconMap = filters != undefined ? [
  //   { name: filters[1].filterName, Icon: DottyIcons.Itinerario },  // TODO: chiavi da tradurre
  //   { name: filters[2].filterName, Icon: DottyIcons.Esperienze },
  //   { name: filters[3].filterName, Icon: DottyIcons.Shop },
  //   { name: filters[4].filterName, Icon: DottyIcons.PuntiInteresse },
  //   { name: filters[5].filterName, Icon: DottyIcons.Mangiare },
  //   { name: filters[6].filterName, Icon: DottyIcons.News },
  //   { name: filters[7].filterName, Icon: DottyIcons.Eventi },
  // ] : [];

  const selectedFilterIndex = filters?.findIndex(f => f.filterName == selectedFilter);

  const dateInterval = () => {
    const dates = selectedDates as Array<Date | null>;
    if (dates != null && dates[0] && dates[1]) {
      const oneDay = 24 * 60 * 60 * 1000; // hours*minutes*seconds*milliseconds
      return `(${Math.max(Math.round(Math.abs((dates[1].getTime() - dates[0].getTime()) / oneDay)), 1)})`;
    }
    return null;
  }

  const getName = (str: string) => {  // FIXME: non buono per altre lingue, serve che i nomi siano passati dalla query iniziale.
    const pieces = str.split('Query')[0].split(/(?=[A-Z])/).map(s => s.toLowerCase());
    pieces[0] = pieces[0].charAt(0).toUpperCase() + pieces[0].slice(1);
    return pieces.join(' ');
  }

  return (
    <div className={className}>
      {!collapsed &&
        <div className={classes.slider_container}>
          <div className={classes.pad}></div>
          <Swiper className={[classes.slider_above, classes.slider].join(' ')}
            slidesPerView='auto'
            spaceBetween={6}
            observeSlideChildren
            modules={[Pagination]}>
            {
              iconMap.map(({ name, Icon, iconUrl, id }) => {
                return (
                  <SwiperSlide className={classes.slide} key={name}>
                    <div className={classes.slide_inner}>
                      {!iconUrl && <Icon width={54} height={54} className={selectedFilter == id ? [classes.icon, classes.selected].join(' ') : classes.icon} onClick={() => {
                        changedSelection.current = true;
                        console.log('filtro selezionato', name);
                        selectedFilter != name ? setSelectedFilter(id) : setSelectedFilter('')
                      }} /> ||
                        <div style={{ width: 54, height: 54 }} className={selectedFilter == id ? [classes.icon, classes.selected].join(' ') : classes.icon} onClick={() => {
                          changedSelection.current = true;
                          console.log('filtro selezionato', name);
                          selectedFilter != name ? setSelectedFilter(id) : setSelectedFilter('')
                        }}>
                          <LazyImage style={{ width: 54, height: 54 }} src={iconUrl ?? ''} />
                        </div>
                      }
                      <TextComponent className={classes.slide_text}
                        text_key={getName(name)}
                        text_size='tiny'
                        text_line='normal' />
                    </div>
                  </SwiperSlide>
                );
              })
            }
          </Swiper>
          <div className={classes.pad}></div>
        </div>
      }
      <div className={classes.slider_container}>
        <div className={classes.pad}></div>
        <Swiper className={classes.slider}
          slidesPerView='auto'
          spaceBetween={6}
          observeSlideChildren
          modules={[Pagination]}>

          {
            configs?.AppTerritoriale !== "true" ? 
            (filters && filters.filter(el => el.filterName === 'eventiQuery' || el.filterName === 'notizieQuery').map(el => {
              console.log("filterName", el.filterName)
              return (<SwiperSlide className={classes.slide}>
                <IconTextButton textProps={{ text_key: `${t('date')} ${dateInterval() ?? ''}` }}  // FIXME: tradurre è complicato dato che sono testi generati, l'idea di avere la traduzione dentro TextComponent va ri-vista.
                  buttonMode='outline'
                  backColor={dateInterval() ? 'var(--emerald-700)' : undefined}
                  contentsColor={dateInterval() ? 'white' : undefined}
                  padding={{ vertical: 8, horizontal: 16 }}
                  onClick={() => setOpenPane(0)} />
              </SwiperSlide>)
            })) 
            : 
            <SwiperSlide className={classes.slide}>
              <IconTextButton textProps={{ text_key: `${t('date')} ${dateInterval() ?? ''}` }}  // FIXME: tradurre è complicato dato che sono testi generati, l'idea di avere la traduzione dentro TextComponent va ri-vista.
                buttonMode='outline'
                backColor={dateInterval() ? 'var(--emerald-700)' : undefined}
                contentsColor={dateInterval() ? 'white' : undefined}
                padding={{ vertical: 8, horizontal: 16 }}
                onClick={() => setOpenPane(0)} />
            </SwiperSlide>
          }
          {
            filters && filters.filter(el => el.filterName !== 'tassonomieQuery').map(el => {
              return el.subfilters.map((sf) => {
                const subFilterIndex = filtersSubfilters?.findIndex(fsf => fsf.filterName === el.filterName && sf.subfilterName === fsf.subfilter.subfilterName) ?? 0
                const filterState = refSubfilterStates.current[subFilterIndex];
                console.log('filterState', filters)

                console.log("filterName", sf.subfilterName)
                if(configs?.AppTerritoriale !== "true" && (sf.subfilterName === "percorribilita" || sf.subfilterName === "difficolta")){
                  return;
                }
                return (
                  <SwiperSlide className={classes.slide} key={sf.subfilterName}>
                    <IconTextButton textProps={{ text_key: `${getName(sf.subfilterName)} ${filterState.length > 0 ? '(' + filterState.length + ')' : ''}` }}
                      icon={<ChevronDown strokeWidth={2} width={16} height={16} />}
                      buttonMode='outline'
                      backColor={filterState.length > 0 ? 'var(--emerald-700)' : undefined}
                      contentsColor={filterState.length > 0 ? 'white' : undefined}
                      padding={{ vertical: 8, horizontal: 16 }}
                      onClick={() => setOpenPane(subFilterIndex + 1)}
                      invertContents />
                  </SwiperSlide>
                );
              })
            })
          }

          {
            configs?.AppTerritoriale === "true" && filters && filters.filter(el => el.filterName === 'tassonomieQuery').map(el => {

              return el.subfilters.map((sf) => {
                const subFilterIndex = filtersSubfilters?.findIndex(fsf => fsf.filterName === el.filterName && sf.subfilterName === fsf.subfilter.subfilterName) ?? 0
                const filterState = refSubfilterStates.current[subFilterIndex];
                console.log('filterState', filters)
                return (
                  <SwiperSlide className={classes.slide} key={sf.subfilterName}>
                    <IconTextButton textProps={{ text_key: `${getName(sf.subfilterName)} ${filterState.length > 0 ? '(' + filterState.length + ')' : ''}` }}
                      icon={<ChevronDown strokeWidth={2} width={16} height={16} />}
                      buttonMode='outline'
                      backColor={filterState.length > 0 ? 'var(--emerald-700)' : undefined}
                      contentsColor={filterState.length > 0 ? 'white' : undefined}
                      padding={{ vertical: 8, horizontal: 16 }}
                      onClick={() => setOpenPane(subFilterIndex + 1)}
                      invertContents />
                  </SwiperSlide>
                );
              })
            })
          }
          {
            configs?.AppTerritoriale === "true" && (filters && selectedFilterIndex && filtersSubfilters) && filters[selectedFilterIndex]?.subfilters.map(sf => {
              const subFilterIndex = filtersSubfilters.findIndex(_sf => _sf.filterName == selectedFilter && _sf.subfilter.subfilterName == sf.subfilterName);
              const filterState = refSubfilterStates.current[subFilterIndex];
              return (
                <SwiperSlide className={classes.slide} key={sf.subfilterName}>
                  <IconTextButton textProps={{ text_key: `${getName(sf.subfilterName)} ${filterState.length > 0 ? '(' + filterState.length + ')' : ''}` }}
                    icon={<ChevronDown strokeWidth={2} width={16} height={16} />}
                    buttonMode='outline'
                    backColor={filterState.length > 0 ? 'var(--emerald-700)' : undefined}
                    contentsColor={filterState.length > 0 ? 'white' : undefined}
                    padding={{ vertical: 8, horizontal: 16 }}
                    onClick={() => setOpenPane(subFilterIndex + 1)}
                    invertContents />
                </SwiperSlide>
              );
            })
          }
        </Swiper>
        <div className={classes.pad}></div>
      </div>
      <DatePickerPane paneNum={0}
        openPane={openPane}
        setOpenPane={setOpenPane}
        val={selectedDates}
        setVal={setSelectedDates} />
      {
        filtersSubfilters && filtersSubfilters.map((sf, subFilterIndex) => {
          const filterState = refSubfilterStates.current[subFilterIndex];
          const options = sf.subfilter.values.flatMap(v =>
            v.figli !== undefined ? (
              v.figli.length > 0 ? [
                {
                  uniqueId: v.uniqueId,
                  name: '| ' + v.text
                }, ...(v.figli?.map<{
                  uniqueId: string,
                  name: string
                }>(f => {
                  return {
                    uniqueId: f.uniqueId,
                    name: f.text
                  }
                }))
              ] : []
            ) : {
              uniqueId: v.uniqueId,
              name: v.text
            });

          return (
            <OptionsListPane key={sf.filterName + '_' + sf.subfilter.subfilterName}
              title_key={sf.subfilter.subfilterName}
              groupName={sf.subfilter.subfilterName}
              paneNum={subFilterIndex + 1}            // Pannello 0 è quello per la data
              openPane={openPane}
              setOpenPane={setOpenPane}
              options={options}
              maxDisplayedOptions={3}
              selectedOptions={filterState}
              setSelectedOptions={(selOptions => {
                console.log('imposto', selOptions, subFilterIndex)
                refSubfilterStates.current[subFilterIndex] = selOptions;
              })}
              multiSelection />
          )
        })
      }
    </div>
  );
};

export default FiltersList;