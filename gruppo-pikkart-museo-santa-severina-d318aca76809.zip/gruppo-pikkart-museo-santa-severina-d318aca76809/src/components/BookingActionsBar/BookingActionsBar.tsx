import { Calendar, MapPin, Share2, Trash2 } from "react-feather";
import IconTextButton from "@/components/IconTextButton";
import classes from "@/components/BookingActionsBar/bookingActions.module.css";
import TextSubtext from "@/components/TextSubtext";

const BookingActionsBar = () => {
    return (
        <div className={classes.container}>
            <BookingAction
                icon={<Trash2 size={24} color="white" />}
                text="delete booking"
            />
            <BookingAction
                icon={<Share2 size={24} color="white" />}
                text="share"
            />
            <BookingAction
                icon={<Calendar size={24} color="white" />}
                text="remember_me"
            />
            <BookingAction
                icon={<MapPin size={24} color="white" />}
                text="position"
            />
        </div>
    );
};

const BookingAction = ({
    icon,
    text = "",
    onClick,
    backColor = 'var(--emerald-700)',
    textColor = 'black',
    padding = {
        all: "12px",
    },
}: {
    icon: JSX.Element;
    text?: string;
    onClick?: () => void;
    backColor?: string;
    textColor?: string;
    padding?: {
        all: string;
    };
}) => {
    return (
        <div className={classes.action_button_container} onClick={onClick}>
            <IconTextButton
                icon={icon}
                backColor={backColor}
                padding={padding}
            />
            <TextSubtext
                textProps={{
                    text_key: text,
                    text_size: "tiny",
                    text_weight: "bold",
                    color: textColor,
                }}
                className={classes.action_button_text}
            />
        </div>
    );
}

export default BookingActionsBar;