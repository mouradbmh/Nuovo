import classes from '@/components/CardImageContainer/cardImageContainer.module.css'
import { CarouselCardProps } from '@/components/CarouselCard';
import IconTextButton from '@/components/IconTextButton';
import TextComponent from '@/components/TextComponent'
import { useAppContext } from '@/hooks/useAppContext';
import { useNavigation } from '@/hooks/useNavigation';
import { useMemo } from 'react';
import * as Icon from 'react-feather'
import { useTranslation } from 'react-i18next';

import "swiper/css/zoom"
import LazyImage from '../LazyImage';


export interface CardImageContainerProps {
    cardType: CarouselCardProps['cardType'];
    eventText?: string;
    hasArButton?: boolean;
    hasPlayButton?: boolean
    url?: string;
    children?: React.ReactNode;
    urlYoutube?: string;
    zoom?: boolean;
}

const CardImageContainer = ({
    cardType = 'small',
    eventText,
    hasArButton = false,
    hasPlayButton = false,
    url = "src/assets/react.svg",
    urlYoutube,
    zoom,
    children
}: CardImageContainerProps) => {
    const { t } = useTranslation();
    const { theme } = useAppContext()
    const { go } = useNavigation()

    const sizedImg = useMemo(() => {
        switch (cardType) {
            case 'smaller':
            case 'small':
            case 'mini':
                return url + '&thumbkey=thumbnail'

            case 'medium':
                return url + '&thumbkey=medium'

            case 'large':
                return url + '&thumbkey=medium_large'

            case 'larger':
                return url + '&thumbkey=large'

            case 'largesquare':
            case 'largetall':
                return url + '&thumbkey=extra_large'

            default:
                return url
        }
    }, [url, cardType])

    const goToYoutube = () => {
        if (urlYoutube) {
            go(urlYoutube)
        }
    }

    return (
        <div className={classes['card_image_container_' + cardType] + (zoom ? ' swiper-zoom-container' : '')}>
            <LazyImage className={classes.img} src={sizedImg} alt={t('image')} />
            {children && <div className={classes.imageOvelay}>
                {children}
            </div>}
            {
                eventText !== undefined ? (
                    <TextComponent className={classes.card_image_event} text_key={eventText} text_size='small' />
                ) : (<></>)
            }
            {
                hasArButton ? (
                    <IconTextButton
                        className={classes.card_image_button}
                        buttonMode='outline_borderless'
                        icon={
                            <Icon.Smartphone size={16} />
                        }
                        padding={{ all: 4 }} />
                ) : (<></>)
            }

            {
                hasPlayButton ? (
                    <IconTextButton
                        className={classes.card_image_play_button}
                        buttonMode='outline_borderless'
                        icon={
                            <>
                                <Icon.PlayCircle size={45} color={theme?.bottonePrimario?.coloreSfondo ?? 'black'} />
                                <div style={{
                                    position: 'absolute',
                                    top: 2.5,
                                    left: 2.5,
                                    width: 38,
                                    height: 38,
                                    borderRadius: 50,
                                    background: theme?.bottonePrimario?.coloreFronte ?? 'white',
                                    zIndex: 0
                                }} />
                            </>
                        }
                        //padding={{ all: 0 }}
                        onClick={() => goToYoutube()}
                        backColor={'transparent'}
                    />
                ) : (<></>)
            }
        </div>
    )
}

export default CardImageContainer;
