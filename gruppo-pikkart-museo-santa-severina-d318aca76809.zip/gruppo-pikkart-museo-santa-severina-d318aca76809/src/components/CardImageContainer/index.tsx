import CardImageContainer from "@/components/CardImageContainer/CardImageContainer";
import { CardImageContainerProps } from "@/components/CardImageContainer/CardImageContainer";

export default CardImageContainer;
export type { CardImageContainerProps };