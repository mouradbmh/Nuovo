import FoldableSection from "@/components/FoldableSection/FoldableSection";

export default FoldableSection;
