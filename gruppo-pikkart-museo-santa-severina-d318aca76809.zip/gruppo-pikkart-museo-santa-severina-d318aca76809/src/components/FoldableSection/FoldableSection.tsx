import { useState } from "react";
import OptionBar, { OptionBarProps } from "@/components/OptionBar";
import { ChevronDown, ChevronUp } from "react-feather";
import Separator from "@/components/Separator";

type FoldableSectionProps = {
    textLeft_key: string,
    textLeft_subtext_key?: string,
    options?: OptionBarProps[],
    className?: string,
};

const FoldableSection = ({ textLeft_key, textLeft_subtext_key, options, className }: FoldableSectionProps) => {
    const [open, setOpen] = useState<boolean>(false);

    return (
        <div className={className}>
            <OptionBar
                textLeft_key={textLeft_key}
                titleWeight="bold"
                textLeft_subtext_key={textLeft_subtext_key}
                onClick={() => setOpen(!open)}
                iconRight={open ? <ChevronUp height="24" strokeWidth={1.5} width="24" /> :
                    <ChevronDown height="24" strokeWidth={1.5} width="24" />}
            />
            {open &&
                options?.map((option, index) => {
                    return (
                        <OptionBar
                            key={index}
                            {...option}
                        />
                    );
                })
            }
            {open && (
                <div className={className}>
                    <Separator />
                </div>
            )}
        </div>
    );
};

export default FoldableSection;
