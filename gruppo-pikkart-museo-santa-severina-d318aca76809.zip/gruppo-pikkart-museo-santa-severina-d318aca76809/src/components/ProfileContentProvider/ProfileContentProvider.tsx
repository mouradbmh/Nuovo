import { AddContenutoVistoRequestDto } from "@/services/openapi";
import { gql, useDataRequest } from "@ai4/data-request";
import { createContext, useEffect, useState } from "react";
import { ContentType } from "../DetailsProvider/DetailsProvider";
import { useAuth } from "@/hooks/useAuth";
import { GraphQLServicesEnte } from "../DiscoverProvider/GraphQLResults";

export type ProfileEvent = {
    id: string;
    title?: string;
    date?: string;
    imgUrl: string;
    contentType: string;
}

export interface IServicesEnte {
  __typename: string;
  uniqueId: string;
}

export type ProfileContentContextType = {
    bookedEvents: ProfileEvent[];
    savedEvents: ProfileEvent[];
    currentScreen: ProfileScreens;
    setCurrentScreen: (screen: ProfileScreens) => void;
    servicesEnte: Array<IServicesEnte>;
};



type ProfileScreens = 'profile' | 'notification-settings' | 'user-settings' | 'change-password' | 'manage-access' | 'reports';

export const ProfileContentContext = createContext<ProfileContentContextType>({} as ProfileContentContextType);

const TMP_BOOKED_EVENTS: ProfileEvent[] = [
    {
        id: '1',
        title: 'Booked event 1',
        date: '2021-06-01',
        imgUrl: 'https://picsum.photos/200/300',
        contentType: ''
    },
    {
        id: '2',
        title: 'Booked event 2',
        date: '2021-06-02',
        imgUrl: 'https://picsum.photos/200/300',
        contentType: ''
    },
    {
        id: '3',
        title: 'Booked event 3',
        date: '2021-06-03',
        imgUrl: 'https://picsum.photos/200/300',
        contentType: ''
    },
];

const ProfileContentProvider = ({ children }: { children: JSX.Element }) => {
    const [bookedEvents, setBookedEvents] = useState<ProfileEvent[]>([]);
    const [savedEvents, setSavedEvents] = useState<ProfileEvent[]>([]);
    const [currentScreen, setCurrentScreen] = useState<ProfileScreens>('profile');
    const [servicesEnte, setServicesEnte] = useState<Array<IServicesEnte>>([])
    const {isLoggedIn} = useAuth()

    const { useRestRequest, useLazyQuery } = useDataRequest();

    const [getSavedEvents] = useRestRequest({
        path: 'rest/{ver}/app/contenuti-preferiti',
        method: 'GET',
        jwt: true
    });

    
    const GET_SERVICES_ENTE = gql`
        query GET_SERVICES_ENTE{
            cartaDeiServiziQuery {
                serviziEnti {
                    lista (filtri: {
                        codice: {
                        _eq: "SEGNALAZIONI"
                        }
                    }){
                        uniqueId
                    }
                }
            }
        }
    `;

    const [getServicesEnte, { data: servicesEnteData, /*loading: servicesEnteLoading, error: servicesEnteError*/ }] = useLazyQuery<GraphQLServicesEnte>(GET_SERVICES_ENTE);

    useEffect(() => {
        if (isLoggedIn){
            setBookedEvents(TMP_BOOKED_EVENTS);
            void getSavedEvents().then((res) => {
                const response = res as (AddContenutoVistoRequestDto & { contenuti: ContentType[] })[];
                if (response.length === 0) {
                    setSavedEvents([]);
                    return;
                }
                console.log(response)
                const events = response.flatMap((ev) => {
                    return ev.contenuti.map(el => {
                        const startDate = new Date(el.dataOraInizio).getDate().toString() + '-' + new Date(el.dataOraInizio).getMonth().toString() + '-' + new Date(el.dataOraInizio).getFullYear().toString()
                        const endDate = new Date(el.dataOraFine).getDate().toString() + '-' + new Date(el.dataOraFine).getMonth().toString() + '-' + new Date(el.dataOraFine).getFullYear().toString()
                        return {
                            id: el.uniqueId,
                            title: el.titolo,
                            date: el.dataOraInizio ? startDate + (el.dataOraFine ? ' / ' + endDate : '') : '',
                            imgUrl: el.urlImmagine,
                            contentType: el.nomeEntita
                        };
                    })
                });
                setSavedEvents(events);
            });
            
            void getServicesEnte()
            // .then((res)=>{
            //     console.log('enti',res)
            //     setServicesEnte(res.data?.cartaDeiServiziQuery.serviziEnti.lista??[])
            // })
            .catch((err)=>{
                console.error(err)
            })
    }
    }, [getSavedEvents, isLoggedIn,getServicesEnte]);

    useEffect(() => {
        if (!servicesEnteData) {
            return
        }
        console.log('enti',servicesEnteData.cartaDeiServiziQuery.serviziEnti.lista)
        const res = servicesEnteData.cartaDeiServiziQuery.serviziEnti.lista as unknown as Array<IServicesEnte>
        setServicesEnte(res)
    },[servicesEnteData])

    const value: ProfileContentContextType = {
        bookedEvents,
        servicesEnte,
        savedEvents,
        currentScreen,
        setCurrentScreen
    };

    return (
        <ProfileContentContext.Provider value={value}>
            {children}
        </ProfileContentContext.Provider>
    );
};

export default ProfileContentProvider;
