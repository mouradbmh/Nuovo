import ProfileContentProvider from "@/components/ProfileContentProvider/ProfileContentProvider";
import { ProfileContentContext, ProfileContentContextType, ProfileEvent } from "@/components/ProfileContentProvider/ProfileContentProvider";

export default ProfileContentProvider;
export { ProfileContentContext };
export type { ProfileContentContextType, ProfileEvent };
