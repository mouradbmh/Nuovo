import classes from '@/components/SelectComponent/selectComponent.module.css';
import textClasses from '@/components/TextComponent/text.module.css';
import { useTranslation } from 'react-i18next';
import styled from 'styled-components';
import TextComponent, { TextProps } from '@/components/TextComponent';
import { useState } from 'react';

export interface SelectProps {
  /**
   * Additional classes for the component.
   */
  className?: string;
  /**
   * Name of the select element.
   */
  selectName: string;
  /**
   * Configuration for the label.
   */
  labelProps?: TextProps;
  /**
   * Configuration for the text in the select.
   */
  textProps: TextProps;
  /**
   * Placeholder option for the select.
   */
  placeholderOption_key?: string;
  /**
   * Options for the select.
   */
  option_keys?: string[];
  /**
   * Disables the select element.
   */
  disabled?: boolean;
}

const StyledSelect = styled.select<{ color: string }>`
  color: ${props => props.color};
`;

/**
 * Primary UI component for user interaction
 */
const SelectComponent = ({
  className,
  selectName,
  labelProps,
  textProps,
  placeholderOption_key,
  option_keys,
  disabled = false,
}: SelectProps) => {
  const { t } = useTranslation();
  const [focus, setFocus] = useState(false);

  let cl = [textClasses.text, textClasses['text_' + textProps.text_size], textClasses['text_weight_' + textProps.text_weight], classes.select];
  if (textProps.text_line !== 'none') {
    cl.push(textClasses['line_' + textProps.text_line])
  }
  if (className !== undefined) {
    cl.push(className)
  }

  let rowClasses = [classes.row_container];
  if (focus) {
    rowClasses.push(classes.focused_select);
  }
  if (disabled) {
    rowClasses.push(classes.disabled_select);
  }

  return (
    <div className={classes.col_container}>
      {
        labelProps !== undefined ? (
          <label htmlFor={selectName}>
            <TextComponent {...labelProps} />
          </label>
        ) : (<></>)
      }
      <div className={rowClasses.join(' ')}>
        <div className={classes.select_container}>
          <StyledSelect name={selectName} className={cl.join(' ')} color={textProps.color ?? 'inherit'} onFocus={() => setFocus(true)} onBlur={() => setFocus(false)} disabled={disabled}>
            {
              (placeholderOption_key !== undefined) ? (
                <option selected disabled>{t(placeholderOption_key)}</option>
              ) : (<></>)
            }
            {
              option_keys?.map((opt) => {
                return (
                  <option value={opt}>{t(opt)}</option>
                );
              })
            }
          </StyledSelect>
        </div>
      </div>
    </div>
  );
};

export default SelectComponent;