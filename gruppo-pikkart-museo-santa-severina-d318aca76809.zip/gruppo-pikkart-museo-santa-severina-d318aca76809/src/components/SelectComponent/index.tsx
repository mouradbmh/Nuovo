import SelectComponent, { SelectProps } from "@/components/SelectComponent/SelectComponent";

export default SelectComponent;
export type { SelectProps };