import classes from '@/components/PartecipantRow/partecipantRow.module.css';
import { CheckCircle, Circle, Trash2, User } from 'react-feather';
import TextSubtext from '@/components/TextSubtext';

type PartecipantRowProps = {
    count: number;
    name: string;
    checked: boolean;
    color?: string;
    checkColor?: string;
    onCheck: () => void;
    onRemove: () => void;
};

const PartecipantRow = ({
    count,
    name,
    checked,
    color = "var(--zinc-900)",
    checkColor = "var(--emerald-500)",
    onCheck,
    onRemove,
}: PartecipantRowProps) => {
    return (
        <div className={classes.row}>
            <div className={classes.left}>
                <User size={24} strokeWidth={1.5} color={color} />
                <div className={classes.text_container}>
                    <TextSubtext
                        textProps={{
                            text_key: count < 10 ? `0${count}` : count.toString(),
                            text_size: "regular",
                            color: color,
                        }}
                        className={classes.text}
                    />
                    <TextSubtext
                        textProps={{
                            text_key: name,
                            text_size: "regular",
                            color: color,
                        }}
                        className={classes.text}
                    />
                </div>
            </div>
            <div className={classes.right}>
                {checked ?
                    <CheckCircle size={24} strokeWidth={1.5} color={checkColor} onClick={onCheck} /> :
                    <Circle size={24} strokeWidth={1.5} color={color} onClick={onCheck} />}
                <Trash2 size={24} strokeWidth={1.5} color={color} onClick={onRemove} />
            </div>
        </div>
    );
};

export default PartecipantRow;
