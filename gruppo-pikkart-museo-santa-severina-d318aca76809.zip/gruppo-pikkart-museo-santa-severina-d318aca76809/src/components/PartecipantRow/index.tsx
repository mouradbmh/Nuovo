import PartecipantRow from "@/components/PartecipantRow/PartecipantRow";

export default PartecipantRow;
