import { GraphQLResults, GraphQLSegnalazione } from "@/components/DiscoverProvider/GraphQLResults";
import { useAuth } from "@/hooks/useAuth";
import useAxiosRequest from "@/hooks/useAxiosRequest";
import { useKey } from "@/hooks/useKeyContext";
import { useProfile } from "@/hooks/useProfile";
import { useProfileContent } from "@/hooks/useProfileContent";
import { gql, useDataRequest } from "@ai4/data-request";
import { Directory } from '@capacitor/filesystem';
import write_blob from "capacitor-blob-writer";


import { Dispatch, SetStateAction, createContext, useCallback, useEffect, useState } from "react";

export type Message = {
  date?: string;
  text?: string;
};

export type ActivityStatus = "Non avviato" | "SOSPESA" | "CONCLUSA" | "IN CORSO";

export type Status = {
  uniqueId?: string;
  nome: ActivityStatus;
}

export type Activity = {
  allegati?: string[];
  codice?: string;
  descrizione?: string;
  indirizzo?: string;
  latitudine?: number;
  longitudine?: number;
  messaggi?: Message[];
  stato?: Status;
  tipologia?: { nome: string, uniqueId: string };
  titolo?: string;
  uniqueId?: string;
  imagesUrl?: string[];
  status?: ActivityStatus;
  statusDescription?: string;
  autoreNome?: string;
  autoreCognome?: string;
  autoreEmail?: string;
  autoreTelefono?: string;
  date?: string;
  receiptUrl?: string;
};

export type ReportsContextType = {
  activities: Activity[];
  typologies: { uniqueId: string, nome: string }[];
  currentReportScreen?: "overview" | "create";
  setCurrentReportScreen: (screen: "overview" | "create") => void;
  create: (startingActivity?: Activity) => void;
  startingActivity?: Activity;
  defaultStatus?: Status;
  createReport: () => Promise<{ ok: boolean, uniqueId?: string }>;
  setTitle: Dispatch<SetStateAction<string>>;
  setDescription: Dispatch<SetStateAction<string>>;
  setTypeId: Dispatch<SetStateAction<string>>;
  setStatusId: Dispatch<SetStateAction<string>>;
  setLocation: Dispatch<SetStateAction<string>>;
  setTypeName: Dispatch<SetStateAction<string>>;
  title: string;
  description: string;
  typeId: string;
  statusId: string;
  location: string;
  typeName: string;
  uploadImage: (args?: any) => Promise<unknown>
  setImagesList: Dispatch<SetStateAction<File[] | undefined>>;
  imagesList: File[] | undefined;
  handleUpload: (x: File) => Promise<void | string | undefined>
  handleConfirmSendReport: (selelctedReport: string) => Promise<unknown>
  handleDownloadReceipt: (selectedActivity: Activity) => Promise<unknown>
  createLoading: boolean;
  editLoading: boolean;
  clearActivity: () => void,
  confirmLoading: boolean,
  setConfirmLoading: Dispatch<SetStateAction<boolean>>,
  latitude: number | undefined,
  setLatitude: Dispatch<SetStateAction<number | undefined>>,
  longitude: number | undefined,
  setLongitude: Dispatch<SetStateAction<number | undefined>>
};

export const ReportsContext = createContext<ReportsContextType>({} as ReportsContextType);

const ReportsProvider = ({ children }: { children: JSX.Element }) => {

  const [activities, setActivities] = useState<Activity[]>([]);
  const [currentReportScreen, setCurrentReportScreen] = useState<"overview" | "create">("overview");
  const [startingActivity, setStartingActivity] = useState<Activity | undefined>(undefined);
  const [defaultStatus, setDefaultStatus] = useState<Status>();
  const { useLazyQuery, useMutation, useRestRequest } = useDataRequest();
  const { profileId } = useProfile()
  const { user } = useAuth()
  const { configs } = useKey()
  const [typologies, setTypologies] = useState<{ uniqueId: string, nome: string }[]>([]);
  const [title, setTitle] = useState('')
  const [description, setDescription] = useState('')
  const [typeId, setTypeId] = useState('')
  const [typeName, setTypeName] = useState('')
  const [statusId, setStatusId] = useState('')
  const [location, setLocation] = useState('')
  const [latitude, setLatitude] = useState<number>();
  const [longitude, setLongitude] = useState<number>()
  const [imagesList, setImagesList] = useState<File[]>();
  const [imagesId, setImageIds] = useState<string[]>([])
  const { axiosPostFormData } = useAxiosRequest()
  const [confirmLoading, setConfirmLoading] = useState<boolean>(false)
  const { servicesEnte } = useProfileContent()

  //------------------------Upload FUNZIONANTE ---------------------------------------------
  // const { key } = useKey();
  // const { get } = useAuthToken();
  // const uploadImagePost = useCallback((file:File)=>{

  //     const accessToken = `Bearer ${get()!.token}`;
  //     // const file = new File([''], 'nessuna-foto-o-icona-.jpg', { type: 'image/jpeg' });

  //     const formData = new FormData();
  //     formData.append('formFile', file);

  //     const config = {
  //         headers: {
  //             'Content-Type': 'multipart/form-data; boundary=X-INSOMNIA-BOUNDARY',
  //             'accept': '*',
  //             'x-api-key': key,
  //             'Authorization': accessToken,
  //         },
  //     };

  //     axios.post('https://api.wp.ai4smartcity.ai/rest/v1/storage/filestorage/storageindexrelation-filestorage', formData, config)
  //     .then((response) => {
  //         console.log('Risposta dal server:', response.data);

  //     })
  //     .catch((error) => {
  //         console.error('Errore durante la chiamata:', error);

  //     });
  // },[get, key])
  //------------------------Upload FUNZIONANTE ---------------------------------------------


  const [uploadImage, { data: uploadData, /*loading: uploadingLoading, error: uploadError*/ }] = useRestRequest({
    path: 'rest/v1/storage/filestorage/storageindexrelation-filestorage',
    method: 'POST',
    jwt: true,
  })
  const [confirmSendReport] = useRestRequest({
    path: "",
    method: 'POST',
    data: {
      codice: "IC",
      messaggio: ""
    },
    jwt: true,
  })

  const [downloadRecipt] = useRestRequest({
    path: "",
    method: 'GET',
    jwt: true,
  })

  // const [saveReport, /*{data: reportData}*/] = useRestRequest({
  //     path: '/rest/{ver}/segnalazioni/' + (selectedReport ?? '') + '/cambia-stato',
  //     method: 'POST',
  //     jwt: true
  // })

  // const [getReceipt, /*{data: receiptData}*/] = useRestRequest({
  //     path: '/rest/{ver}/segnalazioni/' + (selectedReport ?? '') + '/stampa-ricevuta',
  //     method: 'GET',
  //     jwt: true
  // })

  const GET_REPORTS = gql`
        query GET_REPORTS($id: Guid) {
            segnalazioniQuery {
                segnalazioni {
                    lista (filtri: {
                        autoreUniqueId: { _eq: $id }
                    }) {
                        uniqueId
                        autoreUniqueId
                        codice
                        titolo
                        tipologia {
                            uniqueId
                            nome
                        }
                        stato {
                            nome
                        }
                        descrizione
                        indirizzo
                        allegati {
                            fileExt
                            fileLength
                            fileUrl
                            fileName
                        }
                        immagini {
                            fileExt
                            fileLength
                            fileUrl
                            fileName
                        }
                        messaggi {
                            data
                            testo
                        }
                    }
                }
            }
        }
    `;

  const [getActivities, { data: activitiesData, /*loading: activitiesLoading, error: activitiesError*/ }] = useLazyQuery<GraphQLResults>(GET_REPORTS);

  const GET_TYPOLOGIES = gql`
        query GET_TYPOLOGIES{
            segnalazioniQuery {
                tipologie {
                    lista {
                        uniqueId
                        nome
                    }
                }
            }
            praticheQuery {
                statiPratiche {
                    lista(filtri: {
                        codice: {
                            _eq: "NA"
                        }
                    }) {
                        uniqueId
                        nome
                    }
                }
            }
        }
    `;

  const [getTypologies, { data: typologiesData, /*loading: typologiesLoading, error: typologiesError*/ }] = useLazyQuery<GraphQLResults>(GET_TYPOLOGIES);

  const CREATE_REPORT = gql`
        mutation CREATE_REPORT($titolo: String, $descrizione: String, $tipologiaUniqueId: Guid!, $statoUniqueId: Guid!,$servizioEnteUniqueId:Guid!, $idImmagini:[Guid!], $indirizzo: String, $lat: Decimal, $lng: Decimal) {
            segnalazioniMutation {
                segnalazioni {
                    salva(segnalazione: {
                        titolo: $titolo
                        descrizione: $descrizione
                        tipologiaUniqueId: $tipologiaUniqueId
                        statoUniqueId: $statoUniqueId
                        servizioEnteUniqueId:$servizioEnteUniqueId
                        consensoPrivacy: true,
                        indirizzo: $indirizzo,
                        latitudine: $lat,
                        longitudine: $lng
                    },
                        immagini: $idImmagini,
                        allegati: []
                    ){
                        uniqueId
                        codice
                        titolo
                        tipologia {
                            uniqueId
                            nome
                        }
                        stato {
                            nome
                        }
                        descrizione
                        indirizzo
                        latitudine
                        longitudine
                        allegati {
                            fileExt
                            fileLength
                            fileUrl
                            fileName
                        }
                        immagini {
                            fileExt
                            fileLength
                            fileUrl
                            fileName
                        }
                        messaggi {
                            data
                            testo
                        }
                    }
                }
            }
        }
    `;

  const EDIT_REPORT = gql`
        mutation EDIT_REPORT($titolo: String, $descrizione: String, $tipologiaUniqueId: Guid!, $statoUniqueId: Guid!,$servizioEnteUniqueId:Guid!, $idImmagini:[Guid!], $indirizzo: String, $id: Guid, $autoreId: Guid) {
            segnalazioniMutation {
                segnalazioni {
                    salva(segnalazione: {
                        titolo: $titolo
                        descrizione: $descrizione
                        tipologiaUniqueId: $tipologiaUniqueId
                        statoUniqueId: $statoUniqueId
                        servizioEnteUniqueId:$servizioEnteUniqueId
                        consensoPrivacy: true,
                        indirizzo: $indirizzo,
                        uniqueId: $id,
                        autoreUniqueId: $autoreId
                    },
                        immagini: $idImmagini,
                        allegati: []
                    ){
                        uniqueId
                        codice
                        titolo
                        tipologia {
                            uniqueId
                            nome
                        }
                        stato {
                            nome
                        }
                        descrizione
                        indirizzo
                        allegati {
                            fileExt
                            fileLength
                            fileUrl
                            fileName
                        }
                        immagini {
                            fileExt
                            fileLength
                            fileUrl
                            fileName
                        }
                        messaggi {
                            data
                            testo
                        }
                    }
                }
            }
        }
    `;

  const [createMutation, { data: createData, loading: createLoading, /*error: typologiesError */ }] = useMutation<GraphQLSegnalazione>(CREATE_REPORT);

  const [editMutation, { /*data: editData,*/ loading: editLoading, /*error: typologiesError */ }] = useMutation<GraphQLSegnalazione>(EDIT_REPORT);

  const handleUpload = useCallback(async (img: File) => {

    return await axiosPostFormData({
      path: (configs?.URL_AI4CLOUD_ENDPOINT as string) + 'rest/v1/storage/filestorage/storageindexrelation-filestorage',
      file: img
    }).then((res) => {
      const ids = [...imagesId]
      ids.push(res?.data?.fileUniqueId ?? '')
      setImageIds(ids)
      return res.data?.fileUniqueId
    }).catch((error) => {
      console.error(error)
    })
  }, [axiosPostFormData, configs?.URL_AI4CLOUD_ENDPOINT, imagesId])

  const handleConfirmSendReport = useCallback(async (selectedReport: string) => {
    setConfirmLoading(true)
    return await confirmSendReport({
      path: 'rest/v1/segnalazioni/' + selectedReport + '/cambia-stato'
    })
  }, [confirmSendReport])

  const handleDownloadReceipt = useCallback(async (selectedActivity: Activity) => {
    try {
      const response = await downloadRecipt({
        path: 'rest/v1/segnalazioni/' + (selectedActivity.uniqueId!) + '/stampa-ricevuta'
      });

      const pdfBlob = new Blob([response as BlobPart], { type: 'application/pdf' });

      // Generate a unique file name for the PDF
      const fileName = 'Ricevuta_segnalazione_' + (selectedActivity?.codice ?? '') + '.pdf';

      await write_blob({
        blob: pdfBlob,
        path: fileName,
        directory: Directory.Documents,
      })

      // Display a message indicating the file has been saved
      alert('File downloaded to Documents: ' + fileName);
      // console.log('File saved at:', savedFile.uri);
    } catch (error) {
      console.error('Error downloading and saving file:', error);
    }
  }, [downloadRecipt]);

  const createReport = async () => {

    // imagesList?.map(async (el) => {
    //     await handleUpload(el)

    // })
    const imgIds = []

    if (imagesList !== undefined) {
      for (const img of imagesList) {
        const res = await handleUpload(img)
        if (res !== undefined) {
          imgIds.push(res)
        }
      }
    }
    if (servicesEnte.length > 0) {
      if (startingActivity?.uniqueId && startingActivity.uniqueId !== '') {
        return await editMutation({
          variables: {
            'titolo': title,
            'descrizione': description,
            'tipologiaUniqueId': typeId,
            'statoUniqueId': defaultStatus!.uniqueId!,
            'servizioEnteUniqueId': servicesEnte[0].uniqueId,
            'idImmagini': imgIds,
            'indirizzo': location,
            'id': startingActivity.uniqueId,
            'autoreId': user?.id,
            'lat': latitude ?? 0,
            'lng': longitude ?? 0
          }
        }).then(res => {
          setStartingActivity({
            allegati: res.data?.segnalazioniMutation.segnalazioni.salva.allegati,
            autoreCognome: user?.lastName ?? '',
            autoreEmail: user?.email ?? '',
            autoreNome: user?.firstName ?? '',
            autoreTelefono: user?.phoneNumber ?? '',
            codice: res.data?.segnalazioniMutation.segnalazioni.salva.codice,
            descrizione: res.data?.segnalazioniMutation.segnalazioni.salva.descrizione,
            indirizzo: res.data?.segnalazioniMutation.segnalazioni.salva.indirizzo,
            //stato: editData?.segnalazioniMutation.segnalazioni.salva.stato
            tipologia: res.data?.segnalazioniMutation.segnalazioni.salva.tipologia,
            titolo: res.data?.segnalazioniMutation.segnalazioni.salva.titolo,
            uniqueId: res.data?.segnalazioniMutation.segnalazioni.salva.uniqueId,
          })

          return { ok: true, uniqueId: createData?.segnalazioniMutation.segnalazioni.salva.uniqueId }
        }).catch(err => {
          console.log(err)
          return { ok: false, uniqueId: undefined }
        })

      } else {
        return await createMutation({
          variables: {
            'titolo': title,
            'descrizione': description,
            'tipologiaUniqueId': typeId,
            'statoUniqueId': defaultStatus!.uniqueId!,
            'servizioEnteUniqueId': servicesEnte[0].uniqueId,
            'idImmagini': imgIds,
            'indirizzo': location,
            'lat': latitude ?? 0,
            'lng': longitude ?? 0
          }
        }).then((res) => {
          setStartingActivity({
            allegati: res.data?.segnalazioniMutation.segnalazioni.salva.allegati,
            autoreCognome: user?.lastName ?? '',
            autoreEmail: user?.email ?? '',
            autoreNome: user?.firstName ?? '',
            autoreTelefono: user?.phoneNumber ?? '',
            codice: res.data?.segnalazioniMutation.segnalazioni.salva.codice,
            descrizione: res.data?.segnalazioniMutation.segnalazioni.salva.descrizione,
            indirizzo: res.data?.segnalazioniMutation.segnalazioni.salva.indirizzo,
            latitudine: res.data?.segnalazioniMutation.segnalazioni.salva.latitudine,
            longitudine: res.data?.segnalazioniMutation.segnalazioni.salva.longitudine,
            //stato: createData?.segnalazioniMutation.segnalazioni.salva.stato
            tipologia: res.data?.segnalazioniMutation.segnalazioni.salva.tipologia,
            titolo: res.data?.segnalazioniMutation.segnalazioni.salva.titolo,
            uniqueId: res.data?.segnalazioniMutation.segnalazioni.salva.uniqueId,
          })
          void getActivities()
          return { ok: true, uniqueId: res.data?.segnalazioniMutation.segnalazioni.salva.uniqueId }
        }).catch(err => {
          console.log(err)
          return { ok: false, uniqueId: undefined }
        })
      }
    }
    return { ok: false, uniqueId: undefined }
    // setSelectedReport(createData?.segnalazioniMutation.segnalazioni.uniqueId)       //da controllare
  }

  // const save = async () => {
  //     await saveReport({
  //         data: {
  //             codice: "IC",
  //             messaggio: ""
  //         }
  //     })
  // }

  // const receipt = async () => {
  //     await getReceipt()
  // }

  useEffect(() => {
    console.log(startingActivity)
    setLocation(startingActivity?.indirizzo ?? '')
    setTypeId(startingActivity?.tipologia?.uniqueId ?? '')
    setTitle(startingActivity?.titolo ?? '')
    setDescription(startingActivity?.descrizione ?? '')
  }, [startingActivity])

  useEffect(() => {
    if (currentReportScreen === "overview") {
      void getActivities({
        variables: {
          'id': user?.id
        }
      });
    } else if (currentReportScreen === "create") {
      void getTypologies();
    }
  }, [currentReportScreen, getActivities, getTypologies, profileId, user?.id]);

  useEffect(() => {
    if (activitiesData) {
      console.log(activitiesData.segnalazioniQuery);
      setActivities(activitiesData.segnalazioniQuery.segnalazioni.lista)
      if (activitiesData.segnalazioniQuery.segnalazioni.lista.length === 0) {
        setCurrentReportScreen("create");
      }
    }
  }, [activitiesData]);

  useEffect(() => {
    console.log(activities);
  }, [activities]);

  useEffect(() => {
    if (typologiesData) {
      setTypologies(typologiesData.segnalazioniQuery.tipologie.lista);
      setDefaultStatus({
        nome: typologiesData.praticheQuery.statiPratiche.lista[0].nome,
        uniqueId: typologiesData.praticheQuery.statiPratiche.lista[0].uniqueId,
      });
    }
  }, [typologiesData]);

  useEffect(() => {
    if (createData) {
      setStartingActivity(createData.segnalazioniMutation.segnalazioni.salva as Activity)
    }
  }, [createData])

  useEffect(() => {
    if (uploadData) {
      const ids = [...imagesId]
      ids.push(uploadData.uniqueId)
      setImageIds(ids)
    }
  }, [imagesId, uploadData])



  const create = (startingActivity?: Activity) => {
    setCurrentReportScreen("create");
    if (startingActivity) {
      setStartingActivity(startingActivity);
    }
  };

  const clearActivity = () => {
    setStartingActivity(undefined)
  }

  const options: ReportsContextType = {
    activities,
    typologies,
    create,
    startingActivity,
    currentReportScreen,
    setCurrentReportScreen,
    defaultStatus,
    createReport,
    setDescription,
    setStatusId,
    setTitle,
    setTypeId,
    description,
    statusId,
    title,
    typeId,
    location,
    setLocation,
    setTypeName,
    typeName,
    uploadImage,
    imagesList,
    setImagesList,
    handleUpload,
    handleConfirmSendReport,
    handleDownloadReceipt,
    createLoading,
    editLoading,
    clearActivity,
    confirmLoading,
    setConfirmLoading,
    latitude,
    longitude,
    setLatitude,
    setLongitude
  }

  return (
    <ReportsContext.Provider value={options}>
      {children}
    </ReportsContext.Provider>
  );
};

export default ReportsProvider;
