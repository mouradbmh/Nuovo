import ReportActivityDetails from "@/components/Reports/ReportActivityDetails/ReportActivityDetails";

export default ReportActivityDetails;
