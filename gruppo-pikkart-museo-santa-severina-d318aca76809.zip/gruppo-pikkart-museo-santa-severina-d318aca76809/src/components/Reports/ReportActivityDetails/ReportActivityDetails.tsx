import { Activity } from "@/components/Reports/ReportsProvider";
import { styled } from "styled-components";
import classes from "@/components/Reports/ReportActivityDetails/reportActivityDetails.module.css";
import { File } from "react-feather";
import TextSubtext from "@/components/TextSubtext";
import { useReports } from "@/hooks/useReports";
import LazyImage from "@/components/LazyImage";

type ReportActivityDetailsProps = {
  backColor?: string;
  textColor?: string;
  accentColor?: string;
  activity: Activity;
};

const StyledDiv = styled.div<{ backcolor: string }>`
    background-color: ${props => props.backcolor};
`;

const ReportActivityDetails = ({
  backColor = "var(--zinc-base)",
  textColor = "var(--zinc-800)",
  accentColor = "var(--emerald-700)",
  activity,
}: ReportActivityDetailsProps) => {
  const { create, handleDownloadReceipt } = useReports();

  return (
    <StyledDiv backcolor={backColor} className={classes.container}>
      {activity.stato && activity.stato.nome === "Non avviato" &&
        <div className={classes.modify} onClick={() => create(activity)}>
          <TextSubtext
            textProps={{
              text_key: "Modifica",
              text_size: "small",
              text_weight: "bold",
              color: accentColor,
              className: classes.modify_text,
            }}
          />
        </div>
      }
      {activity.stato && activity.stato.nome !== "Non avviato" &&
        <div className={classes.receipt_container} onClick={() => {
          void handleDownloadReceipt(activity)
        }}>
          <File color={textColor} size={24} />
          <TextSubtext
            textProps={{
              text_key: "Scarica la ricevuta",
              text_size: "small",
              text_weight: "bold",
              color: textColor,
            }}
          />
        </div>
      }
      {activity.imagesUrl &&
        <div className={classes.images_wrapper}>
          <TextSubtext
            textProps={{
              text_key: "Immagini della segnalazione",
              text_size: "small",
              text_weight: "regular",
              color: "var(--zinc-500)",
            }}
          />
          <div className={classes.images_container}>
            {activity.imagesUrl?.map((url, index) => (
              <LazyImage className={classes.image} key={index} src={url} alt="Immagine segnalazione" />
            ))}
          </div>
        </div>
      }
      {activity.statusDescription &&
        <TextSubtext
          textProps={{
            text_key: activity.statusDescription || "La tua segnalazione è stata presa in carico dal comune.",
            text_size: "small",
            text_weight: "regular",
            color: accentColor,
          }}
        />
      }
      {activity.messaggi && activity.messaggi.length > 0 &&
        <div className={classes.messages_wrapper}>
          <TextSubtext
            textProps={{
              text_key: "Messaggi",
              text_size: "small",
              text_weight: "bold",
              color: accentColor,
            }}
          />
          {activity.messaggi.map((message, index) => (
            <div className={classes.message_container} key={index}>
              <TextSubtext
                textProps={{
                  text_key: message.date || "",
                  text_size: "tiny",
                  text_weight: "bold",
                  color: textColor,
                }}
              />
              <TextSubtext
                textProps={{
                  text_key: message.text || "",
                  text_size: "small",
                  text_weight: "regular",
                  color: textColor,
                }}
              />
            </div>
          ))}
        </div>
      }
    </StyledDiv>
  );
};

export default ReportActivityDetails;
