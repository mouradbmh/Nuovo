import LazyImage from "@/components/LazyImage";
import TextSubtext from "@/components/TextSubtext";
import { useAppContext } from "@/hooks/useAppContext";
import classes from "@/screens/Profile/Reports/CreateReportSteps/createReportSteps.module.css";

const RecapSection = ({ label, description, imageUrls, showBorder = true }: { label: string, description: string, imageUrls?: string[], showBorder?: boolean }) => {
    const { theme } = useAppContext();
    const sectionClass = [classes.author_section];

    if (showBorder) {
        sectionClass.push(classes.author_section_border);
    }

    return (
        <div className={sectionClass.join(' ')}>
            <TextSubtext
                textProps={{
                    text_key: label,
                    text_size: "small",
                    text_weight: "regular",
                    color: "var(--ink-lighter)",
                }}
                subtextProps={{
                    text_key: description,
                    text_size: "small",
                    text_weight: "bold",
                    color: theme?.stile?.coloreFronte || undefined,
                }}
                gap={5}
            />
            {imageUrls && (
                <div className={classes.images_container}>
                    {imageUrls.map((url, index) => (
                        <LazyImage className={classes.image} key={index} src={url} alt="Immagine segnalazione" />
                    ))}
                </div>
            )}
        </div>
    );
};

export default RecapSection;