import TextSubtext from "@/components/TextSubtext";
import { useAppContext } from "@/hooks/useAppContext";
import { Dispatch, SetStateAction } from "react";
import { ChevronUp } from "react-feather";
import { RecapSection } from "@/components/Reports/CreateReport";
import classes from "@/screens/Profile/Reports/CreateReportSteps/createReportSteps.module.css";
import { useAuth } from "@/hooks/useAuth";

const AuthorRecap = ({ setShowAll }: { setShowAll?: Dispatch<SetStateAction<boolean>> }) => {
    const { theme } = useAppContext();
    const {user} = useAuth();

    return (
        <>
            <TextSubtext
                textProps={{
                    text_key: (user?.firstName && user?.lastName) ? user.firstName + ' ' + user.lastName : 'Nome Cognome',
                    text_size: "title4",
                    text_weight: "bold",
                    color: theme?.stile?.coloreFronte || undefined,
                }}
            />
            <div className={classes.recap_sections_container}>
                <RecapSection
                    label="Codice Fiscale"
                    description={user?.cf ?? ''}
                />
                <RecapSection
                    label="Telefono"
                    description={user?.phoneNumber ?? ''}
                />
                <RecapSection
                    label="Email"
                    description={user?.email ?? ''}
                    showBorder={false}
                />
            </div>
            {setShowAll && <div className={classes.show_all} onClick={() => setShowAll(false)}>
                <TextSubtext
                    textProps={{
                        text_key: "Mostra meno",
                        text_size: "small",
                        text_weight: "regular",
                        color: theme?.bottonePrimario?.coloreSfondo || undefined,
                    }}
                />
                <ChevronUp size={20} color={theme?.bottonePrimario?.coloreSfondo ?? undefined} strokeWidth={1.5} />
            </div>}
        </>
    );
};

export default AuthorRecap;
