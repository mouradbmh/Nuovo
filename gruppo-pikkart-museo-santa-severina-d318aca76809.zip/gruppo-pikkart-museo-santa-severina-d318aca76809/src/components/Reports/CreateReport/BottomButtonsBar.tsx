import IconTextButton from "@/components/IconTextButton";
// import TextSubtext from "@/components/TextSubtext";
import { useAppContext } from "@/hooks/useAppContext";
import classes from "@/screens/Profile/Reports/CreateReportSteps/createReportSteps.module.css";
// import { ChevronLeft } from "react-feather";

type BottomButtonsBarProps = {
    onBack?: () => void;
    onSave?: () => void;
    onNext?: () => void;
};

const BottomButtonsBar = ({ onBack, /*onSave,*/ onNext }: BottomButtonsBarProps) => {
    const { theme } = useAppContext();
    return (
        <div className={classes.button_container}>
            {/* <div className={classes.go_back} onClick={onBack}>
                <ChevronLeft strokeWidth={2} color={theme?.bottonePrimario?.coloreSfondo || undefined} size={14} />
                <TextSubtext
                    textProps={{
                        text_key: "Indietro",
                        text_size: "small",
                        text_weight: "bold",
                        color: theme?.bottonePrimario?.coloreSfondo || undefined,
                    }}
                />
            </div> */}
            <div className={classes.buttons}>
                {/* {onSave && <IconTextButton
                    buttonMode="outline"
                    padding={{
                        vertical: 16,
                        horizontal: 50
                    }}
                    textProps={{
                        text_key: "Salva",
                        text_size: "regular",
                        text_weight: "medium",
                    }}
                    onClick={onSave}
                />} */}
                {onBack && <IconTextButton
                    buttonMode="outline"
                    padding={{
                        vertical: 16,
                        horizontal: 50
                    }}
                    textProps={{
                        text_key: "Indietro",
                        text_size: "regular",
                        text_weight: "medium",
                    }}
                    onClick={onBack}
                />}
                <IconTextButton
                    buttonMode="outline_borderless"
                    padding={{
                        vertical: 16,
                        horizontal: 50
                    }}
                    backColor={theme?.bottonePrimario?.coloreSfondo || undefined}
                    textProps={{
                        text_key: "Avanti",
                        text_size: "regular",
                        text_weight: "medium",
                        color: theme?.bottonePrimario?.coloreFronte || undefined,
                    }}
                    onClick={onNext}
                />
            </div>
        </div>
    );
};

export default BottomButtonsBar;
