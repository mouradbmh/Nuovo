import classes from "@/components/Reports/ReportActivity/reportActivity.module.css";
import { Activity, ActivityStatus } from "@/components/Reports/ReportsProvider";
import TextSubtext from "@/components/TextSubtext";
import React, { useEffect, useState } from "react";
import { AlertTriangle, CheckCircle, ChevronDown, ChevronUp, Clock } from "react-feather";
import { styled } from "styled-components";
import ReportActivityDetails from "@/components/Reports/ReportActivityDetails";

type ReportActivityProps = {
  textColor?: string;
  accentColor?: string;
  backColor?: string;
  activity: Activity;
};

const StyledDiv = styled.div<{ backcolor: string }>`
    background-color: ${props => props.backcolor};
`;

type StatusIconsType = {
  [key in ActivityStatus]: JSX.Element;
};

const StatusIcons: StatusIconsType = {
  "Non avviato": <Clock size={16} color="" />,
  "IN CORSO": <Clock size={16} color="" />,
  "CONCLUSA": <CheckCircle size={16} color="" />,
  "SOSPESA": <AlertTriangle size={16} color="" />,
};

const ReportActivity = ({
  textColor = "var(--zinc-800)",
  accentColor = "var(--emerald-700)",
  backColor = "transparent",
  activity,
}: ReportActivityProps) => {
  const [showDetails, setShowDetails] = useState<boolean>(false);
  const styledIcon = React.cloneElement(StatusIcons[activity.status ?? "IN CORSO"], { color: accentColor });

  useEffect(() => {
    console.log('activity', activity);
  }, [activity]);

  return (
    <StyledDiv className={classes.container} backcolor={backColor}>
      <div className={classes.intro}>
        <TextSubtext
          textProps={{
            text_key: activity?.date || "",
            text_size: "tiny",
            text_weight: showDetails ? "bold" : "regular",
            color: showDetails ? textColor : "var(--ink-lighter)",
          }}
        />
        <TextSubtext
          textProps={{
            text_key: "Segnalazione " + (activity.codice || ""),
            text_size: "small",
            text_weight: "bold",
            color: textColor,
          }}
          subtextProps={{
            text_key: activity.titolo || "",
            text_size: "small",
            text_weight: "regular",
            color: textColor,
          }}
        />
        <div className={classes.status_container}>
          {styledIcon}
          <TextSubtext
            textProps={{
              text_key: activity.stato?.nome || "",
              text_size: "small",
              text_weight: "bold",
              color: accentColor,
            }}
          />
        </div>
        <div className={classes.show_details_container} onClick={() => setShowDetails(!showDetails)}>
          <TextSubtext
            textProps={{
              text_key: "Dettagli",
              text_size: "small",
              text_weight: "bold",
              color: textColor,
            }}
          />
          {showDetails ?
            <ChevronUp color={textColor} size={16} />
            :
            <ChevronDown color={textColor} size={16} />
          }
        </div>
        {showDetails &&
          <ReportActivityDetails
            activity={activity}
          />
        }
      </div>
    </StyledDiv>
  );
};

export default ReportActivity;
