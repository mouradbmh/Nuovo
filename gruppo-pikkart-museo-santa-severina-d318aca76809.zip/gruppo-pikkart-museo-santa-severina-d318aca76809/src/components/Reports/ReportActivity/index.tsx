import ReportActivity from "@/components/Reports/ReportActivity/ReportActivity";

export default ReportActivity;
