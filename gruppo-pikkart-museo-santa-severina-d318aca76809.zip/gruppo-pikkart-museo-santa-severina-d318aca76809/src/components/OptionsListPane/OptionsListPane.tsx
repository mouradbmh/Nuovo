import classes from "@/components/OptionsListPane/optionsListPane.module.css";
import SlidingPane from "@/components/SlidingPaneComponent";
import { Dispatch, SetStateAction, useRef, useState } from "react";
import TextComponent from "../TextComponent";
// import IconTextButton from "../IconTextButton";
// import { ChevronDown, ChevronUp } from "react-feather";
import Checkbox, { InputProps } from "../Checkbox/Checkbox";
import RadioButton from "../RadioButton";
import { useSearch } from "@/hooks/useSearch";
import { useTranslation } from "react-i18next";
import ExpandButton from "../ExpandButton";

export interface OptionsListPaneProps {
  title_key: string;
  paneNum: number;
  openPane: number;
  setOpenPane: Dispatch<SetStateAction<number>>; groupName: string;
  options: { uniqueId: string, name: string }[];
  maxDisplayedOptions?: number;
  multiSelection?: boolean;
  selectedOptions: string[];
  setSelectedOptions: (selectedOptions: string[]) => void;
}

const OptionsListPane = ({
  title_key,
  paneNum,
  openPane,
  setOpenPane,
  groupName,
  options,
  maxDisplayedOptions = Infinity,
  multiSelection,
  selectedOptions,
  setSelectedOptions,
}: OptionsListPaneProps) => {
  const canExpand = options.length > maxDisplayedOptions;
  const [expanded, setExpanded] = useState(false);
  const updated = useRef(false);

  const { updateSubfilterStates, updateSubfilterConfirmation } = useSearch();
  const { t } = useTranslation();

  return (
    <SlidingPane
      title_key={t(title_key)}
      paneNum={paneNum}
      openPane={openPane}
      setOpenPane={setOpenPane}
      adaptiveHeight
      disableConfirmButtonCondition={selectedOptions.length == 0}
      confirmButtonText_key={t('confirm_selection')}
      onConfirmClick={updateSubfilterConfirmation}
      onResetClick={() => {
        setSelectedOptions([]);
        updateSubfilterStates();
      }}
      onRequestClose={() => {
        if (updated.current) {
          updated.current = false;
          updateSubfilterConfirmation();
        }
      }}>
      <div className={classes.option_wrapper}>
        <div className={classes.options_list}>
          {
            options.map((opt, index) => { // TODO: preferire id a nome per controllo selezione?
              const props: InputProps & { label?: JSX.Element, name: string, readOnly?: boolean, onClick?: () => void } = {
                label: <TextComponent className={classes.option_text}
                  text_key={opt.name} />,
                name: groupName,
                checked: selectedOptions.includes(opt.uniqueId),
                readOnly: true,
                onChange: () => {
                  updated.current = true;
                  console.log('entro')
                  if (multiSelection) {
                    console.log('multiselection')
                    if (selectedOptions.includes(opt.uniqueId)) {
                      selectedOptions.splice(selectedOptions.indexOf(opt.uniqueId), 1);
                      console.log('splice', selectedOptions)
                    } else {
                      selectedOptions.push(opt.uniqueId)
                      console.log('push', selectedOptions)
                    }
                    setSelectedOptions([...selectedOptions]);
                    updateSubfilterStates();
                  } else {
                    if (selectedOptions[0] != opt.uniqueId) {
                      setSelectedOptions([opt.uniqueId])
                      updateSubfilterStates();
                    } else {
                      setSelectedOptions([]);
                      updateSubfilterStates();
                    }
                  }
                },
              }

              return (
                <div className={[classes.option, (canExpand && !expanded && index >= maxDisplayedOptions) ? classes.option_hidden : undefined].join(' ')} key={opt.uniqueId}>
                  {
                    multiSelection ? (
                      <Checkbox {...props} key={opt.uniqueId} />
                    ) : (
                      <RadioButton {...props} key={opt.uniqueId} />
                    )
                  }
                </div>
              );
            })
          }
        </div>
        {
          canExpand ?
            <ExpandButton
              expanded={expanded}
              setExpanded={setExpanded}
              className={classes.clear}
              expanded_text={t('show_less_opt')}
              not_expanded_text={t('show_more_opt')}
              padding={{ all: 6 }} />
            : null
        }
      </div>
    </SlidingPane>
  );
};

export default OptionsListPane;