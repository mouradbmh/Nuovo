import OptionsListPane, { OptionsListPaneProps } from "@/components/OptionsListPane/OptionsListPane";

export default OptionsListPane;
export type { OptionsListPaneProps };