import classes from '@/components/CardVideoContainer/cardVideoContainer.module.css'
import { CarouselCardProps } from '@/components/CarouselCard';
import { useMemo, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import LazyImage from '../LazyImage';

export interface CardVideoContainerProps {
    cardType: CarouselCardProps['cardType'];
    eventText?: string;
    hasArButton?: boolean;
    url?: string;
    urlPreview: string;
    playVideo?: boolean;
    autoplay?: boolean
}

const CardVideoContainer = ({
    cardType = 'small',
    url,
    urlPreview,
    playVideo,
    autoplay = false
}: CardVideoContainerProps) => {
    const { t } = useTranslation();
    const vidRef = useRef<HTMLVideoElement>(null)

    const sizedImg = useMemo(() => {
        switch (cardType) {
            case 'smaller':
            case 'small':
            case 'mini':
                return urlPreview + '&thumbkey=thumbnail'

            case 'medium':
                return urlPreview + '&thumbkey=medium'

            case 'large':
                return urlPreview + '&thumbkey=medium_large'

            case 'larger':
                return urlPreview + '&thumbkey=large'

            case 'largesquare':
            case 'largetall':
                return urlPreview + '&thumbkey=extra_large'

            default:
                return urlPreview
        }
    }, [cardType, urlPreview])

    // useEffect(() => {
    //     if (vidRef.current) {
    //         addVideoRef(vidRef.current)
    //     }
    // }, [addVideoRef])

    console.log("hey")
    return (
        <div className={classes['card_image_container_' + cardType]}>

            {!playVideo ? (<LazyImage className={classes.img} src={sizedImg} alt={t('image')} />) : (
                <video ref={vidRef} className={classes.img} src={url} controls autoFocus autoPlay={autoplay}>
                    <source src={url} type="video/mp4" />
                </video>
            )
            }

            {/* {
                eventText !== undefined ? (
                    <TextComponent className={classes.card_image_event} text_key={eventText} text_size='small' />
                ) : (<></>)
            } */}

            {/* {
                showPreview ? (
                    <IconTextButton
                        className={classes.card_image_play_button}
                        buttonMode='outline_borderless'
                        icon={
                            <Icon.PlayCircle size={32} />
                        }
                        padding={{ all: 4 }}
                        onClick={() => setShowPreview(!showPreview)}
                    />
                ) : (<></>)
            } */}


        </div>
    )
}

export default CardVideoContainer;
