import CardVideoContainer from "@/components/CardVideoContainer/CardVideoContainer";
import { CardVideoContainerProps } from "@/components/CardVideoContainer/CardVideoContainer";

export default CardVideoContainer;
export type { CardVideoContainerProps };