import { useNavigation } from "@/hooks/useNavigation"

const Navbar = () => {
    const navigation = useNavigation();

    return (
        <nav style={{border: "1px solid orange"}}>
            <h1>Navbar</h1>
            <a onClick={() => navigation.go("/")}>Home</a>
            <a onClick={() => navigation.go("/discover")}>Discover</a>
        </nav>
    )
}

export default Navbar