import classes from "@/components/RadioButton/radioButton.module.css";
import { InputProps } from "@/components/Checkbox";

const RadioButton = (
  props: InputProps & {label?: JSX.Element}) => {
  return (
    <>
      <label className={classes.radio_container}>
        {props.label}
        <input className={classes.hidden_radio} type='radio' {...props} />
        <span className={classes.radio}></span>
      </label>
    </>
  );
};

export default RadioButton;