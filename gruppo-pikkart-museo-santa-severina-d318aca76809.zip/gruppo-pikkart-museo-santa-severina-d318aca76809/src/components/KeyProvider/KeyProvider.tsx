import { getJSON } from "@/utils/getJSON";
import { Dispatch, ReactNode, SetStateAction, createContext, useCallback, useEffect, useMemo, useState } from "react";

export type KeyContextType = {
  key: string;
  setKey: Dispatch<SetStateAction<string>>;
  keyLoc: string;
  setKeyLoc: Dispatch<SetStateAction<string>>
  configs?: Record<string, string>;
  authDomain: string;
  setAuthDomain: (dom: string | undefined | null) => void
};

export const KeyContext = createContext<KeyContextType>({} as KeyContextType)

type Props = {
  children: JSX.Element | ReactNode;
};

const KeyProvider = ({ children }: Props) => {
  const [key, setKey] = useState('')
  const [location, setLocation] = useState('')
  const [authDomain, setAuthDomain] = useState('')

  const [configs, setConfigs] = useState<Record<string, string>>();

  useEffect(() => {
    // fetch data
    const dataFetch = async () => {
      const conf = await getJSON(
        './config.json'
      );
      console.log('config', conf)
      // set state when the data received
      setConfigs(conf);
    };

    void dataFetch();
  }, []);

  useEffect(() => {
    const k = localStorage.getItem('xApiKey')
    if (k) {
      setKey(localStorage.getItem('xApiKey')!)
    }
  }, [])

  const setDomain = useCallback((dom: string | undefined | null) => {
    if (dom === undefined || dom === null) {
      if (configs) {
        setAuthDomain(configs.URL_AI4CLOUD_ENDPOINT);
      }else{
        setAuthDomain("---");
      }
    } else {
      setAuthDomain(dom)
    }
  }, [configs?.URL_AI4CLOUD_ENDPOINT])


  const value: KeyContextType = useMemo(() => {
    return {
      key,
      setKey,
      keyLoc: location,
      setKeyLoc: setLocation,
      configs,
      authDomain,
      setAuthDomain: setDomain
    }
  }, [authDomain, configs, key, location, setDomain]);

  if (configs === undefined) {
    return <></>;
  }

  return (
    <KeyContext.Provider value={value}>
      {children}
    </KeyContext.Provider>
  );
};

export default KeyProvider;