import classes from "@/components/ProfileOptionsList/profileOptionsList.module.css";
import OptionBar, { OptionBarProps } from "@/components/OptionBar";
import { styled } from "styled-components";
import TextSubtext from "../TextSubtext";

export type ProfileOptionsListProps = {
    backColor?: string,
    profileOptions?: OptionBarProps[],
    title_key?: string,
};

const StyledDiv = styled.div<{ backcolor?: string }>`
  ${props => props.backcolor !== undefined ? `background-color: ${props.backcolor};` : ''}
`;

const ProfileOptionsList = ({
    backColor = "transparent",
    profileOptions,
    title_key = "Account",
}: ProfileOptionsListProps) => {
    return (
        <StyledDiv backcolor={backColor} className={classes.column_container}>
            <div className={classes.title_container}>
                <TextSubtext
                    textProps={{
                        text_key: title_key,
                        text_size: "large",
                        text_weight: "bold",
                        color: "var(--zinc-900)",
                    }}
                />
            </div>
            <div>
                {
                    profileOptions?.map((opt, index) => {
                        return (
                            <OptionBar key={index} {...opt} />
                        );
                    })
                }
            </div>
        </StyledDiv>
    );
};

export default ProfileOptionsList;
