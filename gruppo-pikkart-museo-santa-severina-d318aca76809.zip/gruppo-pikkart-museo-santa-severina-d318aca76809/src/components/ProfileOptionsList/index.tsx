import ProfileOptionsList from "@/components/ProfileOptionsList/ProfileOptionsList";

export default ProfileOptionsList;
