import { useAppContext } from '@/hooks/useAppContext';
import { useNavigation } from '@/hooks/useNavigation';
import classes from './ParentChild.module.css'
import { styled } from 'styled-components';
import { EventDetails, POIDetails } from '../DetailsProvider/DetailsTypes';
import DottyIcons from '../DottyIcons';
import TextSubtext from '../TextSubtext';
import IconTextButton from '../IconTextButton';
import { ArrowRight } from 'react-feather';
import Carousel from '../Carousel';
import { useTranslation } from 'react-i18next';
import { useCallback, useMemo } from 'react';

export interface ParentChildProps {
    POIContent?: POIDetails
    EventContent?: EventDetails
    // uniqueId: string,
    // contents: Partial<EventDetails & POIDetails>
}

const StyledDiv = styled.div<{ backcolor?: string }>`
${props => props.backcolor !== undefined ? `background-color: ${props.backcolor};` : ''}
`;

const ParentChild = ({ POIContent, EventContent }: ParentChildProps) => {

    const { go } = useNavigation();
    const { theme } = useAppContext();
    const { t } = useTranslation();



    const content = useMemo(() => {
        if (POIContent && POIContent.uniqueId != POIContent.puntoDiInteresseGenitore?.uniqueId) {
            return { parentPOI: POIContent.puntoDiInteresseGenitore, childPOI: POIContent.puntiDiInteresse, type: 'POI' };
        } else if (EventContent && EventContent.uniqueId != EventContent.eventoGenitore?.uniqueId) {
            return { parentEvent: EventContent.eventoGenitore, childEvent: EventContent.appuntamenti, type: 'Event' }
        } else return {};
    }, [POIContent, EventContent])

    const goToDetail = useCallback(() => {
        if (POIContent && content.parentPOI?.uniqueId) {
            go('/details/?id=' + content.parentPOI.uniqueId + '&type=2')
        } else if (EventContent && content.parentEvent?.uniqueId) {
            go('/details/?id=' + content.parentEvent?.uniqueId + '&type=3')
        }

    }, [content])

    return (
        <div className={classes.column}>
            {
                (content?.parentPOI || content?.parentEvent) &&
                <StyledDiv className={classes.event_info_container}
                    backcolor={content.type === 'Event' ? (theme?.contenuto?.evento?.sezioneEventoGenitore?.coloreSfondo ?? undefined) : (theme?.contenuto?.puntoDiInteresse?.sezionePOIGenitore?.coloreSfondo ?? undefined)}>
                    {
                        content.type === 'Event' ?
                        <DottyIcons.Eventi width={32} height={32} strokeWidth={1.5}
                        stroke={theme?.contenuto?.evento?.sezioneEventoGenitore?.coloreFronte ?? undefined} />
                        :
                        <DottyIcons.PuntiInteresse width={32} height={32} strokeWidth={1.5}
                        stroke={theme?.contenuto?.puntoDiInteresse?.sezionePOIGenitore?.coloreFronte ?? undefined} />
                    }
                    <TextSubtext className={classes.stretch}
                        textProps={{
                            text_key: content.type === 'Event' ? t('event_part_of') : t('part_of'),
                            text_size: 'tiny',
                            text_line: 'normal',
                            color: content.type === 'Event' ? (theme?.contenuto?.evento?.sezioneEventoGenitore?.coloreFronte ?? undefined) : (theme?.contenuto?.puntoDiInteresse?.sezionePOIGenitore?.coloreFronte ?? undefined)
                        }}
                        subtextProps={{
                            // text_key: contents.eventoGenitore.traduzioni[0].titolo,
                            text_key: content.type === 'Event' ? (content.parentEvent?.traduzioni[0].titolo ?? '') : (content.parentPOI?.traduzioni[0].nome ?? ''),
                            text_size: 'tiny',
                            text_weight: 'bold',
                            text_line: 'normal',
                            color: content.type === 'Event' ? (theme?.contenuto?.evento?.sezioneEventoGenitore?.coloreFronte ?? undefined) : (theme?.contenuto?.puntoDiInteresse?.sezionePOIGenitore?.coloreFronte ?? undefined)
                        }} />
                    <IconTextButton
                        textProps={{
                            text_key: t('discover'),
                            color: theme?.bottoneSecondario?.coloreFronte ?? undefined
                        }}
                        icon={
                            <ArrowRight width={16} height={16} strokeWidth={1.5}
                                stroke={theme?.bottoneSecondario?.coloreFronte ?? undefined} />
                        }
                        backColor={theme?.bottoneSecondario?.coloreSfondo ?? undefined}
                        bordercolor={theme?.bottoneSecondario?.coloreBordo ?? undefined}
                        padding={{ vertical: 8, horizontal: 16 }}
                        buttonMode="outline_borderless"
                        invertContents
                        onClick={goToDetail} />
                </StyledDiv>
            }
            {
                ((content?.childPOI && content?.childPOI.length > 0) || (content?.childEvent && content?.childEvent.length > 0)) &&
                <Carousel
                    titleBar={{
                        title: {
                            text_key: content.type === 'Event' ? t('from_same_show') : t('what_you_will_find'),
                            text_size: 'large',
                            text_weight: 'bold',
                            color: content.type === 'Event' ? (theme?.contenuto?.evento?.containerEventiCorrelati?.coloreTitoloTipologia ?? undefined) : (theme?.contenuto?.puntoDiInteresse?.containerPOICorrelati?.coloreTitoloTipologia ?? undefined)
                        },
                    }}
                    background={content.type === 'Event' ? (theme?.contenuto?.evento?.containerEventiCorrelati?.backColor ?? undefined) : (theme?.contenuto?.puntoDiInteresse?.containerPOICorrelati?.backColor ?? undefined)}
                    slidesPerView='auto'
                    slides={
                        content.type === 'Event' ?
                            content.childEvent?.filter(a => a.uniqueId != content.parentEvent?.uniqueId).map(a => {
                                return {
                                    cardType: 'medium',
                                    id: a.uniqueId,
                                    imgUrl: a.immagineUrl,
                                    title: a.traduzioni[0].titolo,
                                    eventText: a.__typename,
                                    titleColor: theme?.contenuto?.evento?.sezioneEventoGenitore?.coloreFronte ?? undefined,
                                    secondaryInfoColor: theme?.contenuto?.evento?.sezioneEventoGenitore?.coloreFronte ?? undefined,
                                    descriptionColor: theme?.contenuto?.evento?.sezioneEventoGenitore?.coloreFronte ?? undefined,
                                    contentType: a.__typename
                                }
                            })
                            :
                            content.childPOI?.filter(a => a.uniqueId != content.parentPOI?.uniqueId).map(a => {
                                return {
                                    cardType: 'medium',
                                    id: a.uniqueId,
                                    imgUrl: a.immagineUrl,
                                    title: a.traduzioni[0].nome,
                                    eventText: a.__typename,
                                    titleColor: theme?.contenuto?.puntoDiInteresse?.containerPOICorrelati?.coloreTitoloItem ?? undefined,
                                    secondaryInfoColor: theme?.contenuto?.puntoDiInteresse?.containerPOICorrelati?.coloreDescrizioneItem ?? undefined,
                                    descriptionColor: theme?.contenuto?.puntoDiInteresse?.containerPOICorrelati?.coloreDescrizioneItem ?? undefined,
                                    contentType: a.__typename
                                }
                            })
                    } />
            }

        </div>
    )
}

export default ParentChild
