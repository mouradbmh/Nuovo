import TextSubtext, { TextSubtextProps } from '@/components/TextSubtext/TextSubtext';

export default TextSubtext;
export type { TextSubtextProps };