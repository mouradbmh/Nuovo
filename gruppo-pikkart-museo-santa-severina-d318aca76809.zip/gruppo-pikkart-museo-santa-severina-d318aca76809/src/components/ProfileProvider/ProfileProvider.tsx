import { ReactNode, createContext, useEffect, useState } from "react";
import { LocationComponentProps } from "@/components/LocationComponent";
import { useDataRequest } from "@ai4/data-request";
import { useKey } from "@/hooks/useKeyContext";
import i18n from "i18next";
import { useAppContext } from "@/hooks/useAppContext";

export type ScreenType = 'location' | 'profile' | 'onboarding';

const screens: ScreenType[] = [
  'location',
  'profile',
  'onboarding',
];

export type ProfileContextType = {
  ready: boolean,
  profileId?: string;
  locations?: LocationComponentProps[];
  location?: string;
  screen: ScreenType;
  setLocation: (location: string) => void;
  chooseProfile: (profileId: string) => void;
  saveProfile: () => void;
  prevScreen: () => void;
  nextScreen: () => void;
  clearProfile: () => void;
};

export const ProfileContext = createContext<ProfileContextType>({} as ProfileContextType);

type Props = {
  children: JSX.Element | ReactNode;
}

const ProfileProvider = ({ children }: Props) => {
  const [ready, setReady] = useState(false);
  const { key, keyLoc, configs, setAuthDomain } = useKey();
  const { toScreen, config } = useAppContext();

  const [screen, setScreen] = useState<ScreenType>(configs?.MULTITENANT === 'true' && key === '' ? screens[0] : screens[1]);
  // const [screen, setScreen] = useState<ScreenType>(toScreen ?? "location");
  const [profileId, setProfileId] = useState<string>();
  const [location, setLocation] = useState<string>(keyLoc);

  const { useRestRequest } = useDataRequest();

  const [fetch, { data }] = useRestRequest({
    path: 'rest/{ver}/apps/' + (configs?.ID ?? '') + '/tenants',    // TODO: schema è string.
    headers: {
      'Content-Type': 'application/json',
      'Content-Language': i18n.language.split('-')[0]
    },
    method: 'GET',
  });

  const [locations, setLocations] = useState<LocationComponentProps[]>([]);

  useEffect(() => {
    console.log("change")
  }, [toScreen])

  useEffect(() => {
    if (data || !configs) {
      return;
    }
    void fetch();
  }, [fetch, configs]);

  useEffect(() => {
    if (!data) {
      return;
    }
    setLocations((data as Array<{
      tenantId: string,
      tenantName: string,
      arCustomerCode: string,
      wpAppUrl: string,
    }>).map(e => {
      if (e.tenantId === key) {
        setAuthDomain(e.wpAppUrl)
      }
      return {
        text_key: e.tenantName,
        subtext_key: '---',
        tenantId: e.tenantId,
        authDomain: e.wpAppUrl
      }
    }));
  }, [data, key, setAuthDomain]);

  useEffect(() => {
    setProfileId(localStorage.getItem(key + ".profileId") ?? undefined);
    setReady(true);
  }, [key]);

  const clearProfile = () => {
    localStorage.removeItem(key + "profileId");
    setProfileId(undefined);
    setScreen(screens[0]);
  };

  const chooseProfile = (profileId: string) => {
    setProfileId(profileId);
  };

  const saveProfile = (prf?: string) => {
    localStorage.setItem(key + ".profileId", prf ?? profileId as string);
  }

  const prevScreen = () => {
    setScreen(screens[Math.max(screens.indexOf(screen) - 1, 0)]);
  }

  const nextScreen = () => {
    if (config && config.messaggiOnBoarding && config.profiliUtente) {
      if (config.messaggiOnBoarding.length > 0 && config.profiliUtente.length === 1) {
        setProfileId(config.profiliUtente[0].id)
        saveProfile()
        setScreen('onboarding')
      }
      else {
        setScreen(screens[Math.min(screens.indexOf(screen) + 1, screens.length - 1)]);
      }

    }
  }

  const value: ProfileContextType = {
    ready,
    profileId,
    locations,
    location,
    screen,
    setLocation,
    chooseProfile,
    saveProfile,
    prevScreen,
    nextScreen,
    clearProfile
  };

  return (
    <ProfileContext.Provider value={value}>
      {children}
    </ProfileContext.Provider>
  );
};

export default ProfileProvider;
