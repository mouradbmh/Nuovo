import ProfileProvider from "@/components/ProfileProvider/ProfileProvider";
import { ProfileContextType, ScreenType } from "@/components/ProfileProvider/ProfileProvider";
import { ProfileContext } from "@/components/ProfileProvider/ProfileProvider";

export {ProfileProvider, ProfileContext};
export type {ProfileContextType, ScreenType};
