import SlidingPane, { SlidingPaneProps } from "@/components/SlidingPaneComponent/SlidingPaneComponent";

export default SlidingPane;
export type { SlidingPaneProps };