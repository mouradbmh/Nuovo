import { Dispatch, SetStateAction } from "react";
import ReactSlidingPane, { ReactSlidingPaneProps } from "react-sliding-pane";

import classes from '@/components/SlidingPaneComponent/slidingPane.module.css';
import TextComponent from "@/components/TextComponent";
import IconTextButton from "@/components/IconTextButton";
import { useTranslation } from "react-i18next";

export interface SlidingPaneProps {
  className?: string;
  title_key: string;
  confirmButtonText_key: string,
  paneNum: number;
  openPane: number;
  setOpenPane: Dispatch<SetStateAction<number>>;
  adaptiveHeight?: boolean;
  onRequestClose?: ReactSlidingPaneProps['onRequestClose'];
  disableConfirmButtonCondition: boolean;
  onConfirmClick?: () => void,
  onResetClick?: () => void;
  children?: React.ReactNode;
}

const SlidingPane = ({
  className,
  title_key,
  confirmButtonText_key,
  paneNum,
  openPane,
  setOpenPane,
  adaptiveHeight = false,
  onRequestClose,
  disableConfirmButtonCondition,
  onConfirmClick,
  onResetClick,
  children,
}: SlidingPaneProps) => {
  const { t } = useTranslation();

  return (
    <ReactSlidingPane
      className={[classes.sliding_pane, className].join(' ')}
      overlayClassName={adaptiveHeight ? classes.adaptive_height : undefined}
      isOpen={paneNum == openPane}
      from='bottom'
      width='100%'
      hideHeader
      onRequestClose={() => {
        onRequestClose?.();
        setOpenPane(-1);
      }}>
      <div className={classes.pane_contents}>
        <TextComponent
          text_key={title_key}
          text_size='title3'
          text_weight='bold'
          className={classes.clear_padding}
        />
        {children}
        <div className={classes.datepicker_controls}>
          <IconTextButton
            textProps={{
              text_key: confirmButtonText_key
            }}
            padding={{ vertical: 16 }}
            buttonMode='normal'
            backColor='var(--emerald-700)'
            contentsColor='white'
            expanded
            disabled={disableConfirmButtonCondition}
            onClick={() => {
              onConfirmClick?.();
              setOpenPane(-1);
            }}
          />
          <IconTextButton
            textProps={{
              text_key: t('reset')
            }}
            padding={{ vertical: 16 }}
            buttonMode='outline_borderless'
            expanded
            onClick={onResetClick}
          />
        </div>
      </div>
    </ReactSlidingPane>
  );
};

export default SlidingPane;