import { ReactNode, createContext, useEffect, useState } from "react";
import { gql, useDataRequest } from "@ai4/data-request";
import { VideataHomeDto } from "@/services/openapi";
import { useProfile } from "@/hooks/useProfile";
import i18n from "i18next";
import { ArExperience } from "../ArProvider/ArTypes";

export type HomeContextType = {
    inEvidenza: VideataHomeDto['inEvidenza'],
    tipologieContenuto: VideataHomeDto['tipologieContenuto'],
    loading?: boolean,
    error?: any,
    ArActive: boolean
};

export const HomeContext = createContext<HomeContextType>({} as HomeContextType);

type Props = {
    children: JSX.Element | ReactNode;
};

const HomeProvider = ({ children }: Props) => {
    const { useRestRequest, useLazyQuery } = useDataRequest();
    const { profileId } = useProfile();
    const [fetch, { data, loading, error }] = useRestRequest({
        path: 'rest/{ver}/app/home',
        headers: {
            'Content-Type': 'application/json',
            'Content-Language': i18n.language.split('-')[0]
        },
        method: 'GET',
        queryString: {
            profiloUniqueId: profileId as string
        }
    });
    const [inEvidenza, setInEvidenza] = useState<VideataHomeDto['inEvidenza']>();
    const [ArActive, setArActive] = useState<boolean>(false)
    const [tipologieContenuto, setTipologieContenuto] = useState<VideataHomeDto['tipologieContenuto']>();
    
    const AR_QUERY = gql(`
    query {
      esperienzeArQuery {
        esperienzeAR {
          lista {
            uniqueId
          }
        }
      }
    }`);

  const [ArFetch, { data: arData}] = useLazyQuery<ArExperience>(AR_QUERY);

    useEffect(() => {
        if (arData || !profileId) {
            return;
        }
        void ArFetch();
    }, [ArFetch, profileId])

    useEffect(() => {
        if (!arData) {
            return;
        }
        setArActive(arData.esperienzeArQuery.esperienzeAR.lista.length > 0 ? true : false)
    }, [arData]);

    useEffect(() => {
        if (data || !profileId) {
            return;
        }
        void fetch();
    }, [fetch, profileId]);

    useEffect(() => {
        if (!data) {
            return;
        }
        setInEvidenza(data.inEvidenza);
        setTipologieContenuto(data.tipologieContenuto);
        console.log(data);
    }, [data]);

    const value: HomeContextType = {
        inEvidenza: inEvidenza,
        tipologieContenuto: tipologieContenuto,
        loading,
        error,
        ArActive
    };

    return (
        <HomeContext.Provider value={value}>
            {children}
        </HomeContext.Provider>
    );
};

export default HomeProvider;