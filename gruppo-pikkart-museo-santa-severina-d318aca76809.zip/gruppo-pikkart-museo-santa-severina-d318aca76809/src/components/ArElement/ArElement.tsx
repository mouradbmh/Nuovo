import { useDetails } from "@/hooks/useDetails"
import { useKey } from "@/hooks/useKeyContext"
import NavigationTopBar from "../NavigationTopBar"
import IconTextButton from "../IconTextButton"
import { ChevronLeft } from "react-feather"
import { t } from "i18next"
import { useNavigation } from "@/hooks/useNavigation"
import classes from './arElement.module.css'
import Loader from "../Loader"


const ArElement = () => {
    const { authDomain } = useKey()
    const { uid, experience, previewUrl } = useDetails()
    const { goBack } = useNavigation()

    if (!authDomain) {
        return <Loader />
    }

    console.log(uid)

    return (
        <div
            style={{
                height: '100vh',
                display: "flex",
                flexDirection: 'column'
            }}
        >
            <NavigationTopBar className={classes.overlapping_topbar}
                button_left={
                    <IconTextButton
                        backColor="transparent"
                        contentsColor="white"
                        buttonMode="outline_borderless"
                        icon={<ChevronLeft height="24" strokeWidth={1.5} width="24" onClick={() => goBack()} />} />
                }
                title_key={t(experience)}
                textColor="white"
                backColor="black"
                button_right={
                    <IconTextButton
                        backColor="transparent"
                        contentsColor="white"
                        buttonMode="outline_borderless" />
                } />
            {experience === 'MatterportSpace' && <iframe
                allow="vr,gyroscope,accelerometer,fullscreen"
                allowFullScreen
                frameBorder={0}
                style={{

                }}
                src={"https://my.matterport.com/show/?m=" + uid + '&play=1'}
                width={'100%'}
                height={'100%'}
            /> ||
                experience === 'TourVirtuale' && <iframe
                    allow="vr,gyroscope,accelerometer,fullscreen"
                    allowFullScreen
                    frameBorder={0}
                    style={{

                    }}
                    src={"https://kuula.co/share/" + uid + '?logo=0&info=0&fs=1&vr=0&sd=1&thumbs=1'}
                    width={'100%'}
                    height={'100%'}
                /> ||
                experience === 'Video360' && <iframe
                    allow="vr,gyroscope,accelerometer,fullscreen"
                    allowFullScreen
                    frameBorder={0}
                    style={{

                    }}
                    src={authDomain + '/wp-content/plugins/ai4-krpano/assets/krpano/?fileUrl=' + uid + '&previewFileUrl=' + previewUrl}
                    width={'100%'}
                    height={'100%'}
                /> ||
                experience === 'Elemento3D' && <iframe
                    allow="vr,gyroscope,accelerometer,fullscreen"
                    allowFullScreen
                    frameBorder={0}
                    style={{

                    }}
                    src={authDomain + '/wp-content/plugins/AI4-WP/public/page-templates/blank-iframe.php/?fileUrl=' + uid}
                    width={'100%'}
                    height={'100%'}
                /> ||
                <div>Unknown content</div>
            }
        </div>
    )
}

export default ArElement