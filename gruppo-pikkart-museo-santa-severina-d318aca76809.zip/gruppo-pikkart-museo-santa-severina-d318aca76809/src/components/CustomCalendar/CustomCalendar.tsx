import Calendar, { CalendarProps } from "react-calendar";

import '@/components/CustomCalendar/customCalendar.css';

const CustomCalendar = ({...props}: CalendarProps & React.RefAttributes<unknown>) => {
    return (
        <Calendar {...props}/>
    )
}

export default CustomCalendar