import classes from '@/components/AppBottomBar/appBottomBar.module.css'
import styled from 'styled-components';
import IconTextButton from '@/components/IconTextButton';
import * as Icon from 'react-feather';
import { useAppContext } from '@/hooks/useAppContext';
import { useNavigation } from '@/hooks/useNavigation';
import { useTranslation } from 'react-i18next';

export interface AppBottomBarProps {
  /**
   * Background color for the container.
   */
  backColor?: string;
  /**
   * Current screen in which the bar is appearing.
   */
  currentScreen?: 'home' | 'discover' | 'profile';  // FIXME: tipo preso dal tipo dei props di ScreenLayout, che è da creare.
}

const StyledBottomBar = styled.div<{ backcolor: string }>`
  background-color: ${props => props.backcolor};
  position: sticky;
  bottom: 0;
  left: 0;
  z-index: 9999;
`;

const AppBottomBar = ({
  backColor = 'white',
  currentScreen,
}: AppBottomBarProps) => {
  const { theme } = useAppContext();
  const { go } = useNavigation();
  const { t } = useTranslation();

  let activeColorBackground = 'white';
  let activeColorContent = 'white';
  let inactiveColorBackground = 'white';
  let inactiveColorContent = 'white';
  // let contentColor: string = 'white';

  if (theme?.bottomBar?.coloreSfondo) {
    backColor = theme?.bottomBar?.coloreSfondo;
  }

  // if (theme?.bottomBar?.coloreFronte) {
  //   contentColor = theme?.bottomBar?.coloreFronte as string;
  // }

  if (theme?.bottonePrimario?.coloreSfondo) {
    inactiveColorBackground = theme?.bottonePrimario?.coloreSfondo;
  }

  if (theme?.bottonePrimario?.coloreFronte) {
    inactiveColorContent = theme?.bottonePrimario?.coloreFronte;
  }

  if (theme?.bottonePrimarioSelezionato?.coloreSfondo) {
    activeColorBackground = theme?.bottonePrimarioSelezionato?.coloreSfondo;
  }

  if (theme?.bottonePrimarioSelezionato?.coloreFronte) {
    activeColorContent = theme?.bottonePrimarioSelezionato?.coloreFronte;
  }

  return (
    <>
      <StyledBottomBar backcolor={backColor} className={classes.bottom_bar_container} >
      <div className={classes.buffer_container}></div>
      <div className={classes.contents_container}>
        <div className={classes.button_container}>
          <IconTextButton
            icon={
              <Icon.Home strokeWidth={1.5} width={24} height={24} fill={currentScreen == 'home' ? activeColorBackground : inactiveColorBackground} stroke={currentScreen == 'home' ? activeColorBackground : inactiveColorBackground} />
            }
            contentsColor={currentScreen == 'home' ? activeColorContent : inactiveColorContent}
            buttonMode='outline_borderless'
            no_rounded_borders
            active={currentScreen == 'home'}
            onClick={() => {
              if (currentScreen != 'home') {
                go('/', true) // TODO: percorsi e schermate potrebbero essere un tipo unico.
              }
            }}
            expanded
          />
        </div>
        <div className={classes.button_container}>
          <IconTextButton className={classes.button_shifted}
            icon={<Icon.Compass height={32} strokeWidth={1.5} width={32} />}
            padding={{ left: 12, right: 16, vertical: 8 }}
            textProps={{
              text_key: t('DISCOVER'),
              text_weight: 'semibold'
            }}
            backColor={currentScreen == 'discover' ? activeColorBackground : inactiveColorBackground}
            contentsColor={currentScreen == 'discover' ? activeColorContent : inactiveColorContent}
            bordercolor='transparent'
            active={currentScreen == 'discover'}
            onClick={() => {
              if (currentScreen != 'discover') {
                go('/discover', true)
              }
            }} />
        </div>
        <div className={classes.button_container}>
          <IconTextButton
            icon={
              <Icon.User strokeWidth={1.5} width={24} height={24} fill={currentScreen == 'profile' ? activeColorBackground : inactiveColorBackground} stroke={currentScreen == 'profile' ? activeColorBackground : inactiveColorBackground} /> // ???
            }
            buttonMode='outline_borderless'
            no_rounded_borders
            contentsColor={currentScreen == 'profile' ? activeColorContent : inactiveColorContent}
            active={currentScreen == 'profile'}
            expanded
            onClick={() => {
              go('/profile');
            }}
          />
        </div>
      </div>
      <div className={classes.buffer_container}></div>
      <div style={{position: "fixed"}}></div>
    </StyledBottomBar >
    </>
  );
}

export default AppBottomBar;