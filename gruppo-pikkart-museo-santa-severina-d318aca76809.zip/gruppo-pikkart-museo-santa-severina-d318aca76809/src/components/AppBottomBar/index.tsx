import AppBottomBar, { AppBottomBarProps } from "@/components/AppBottomBar/AppBottomBar";

export default AppBottomBar;
export type { AppBottomBarProps };