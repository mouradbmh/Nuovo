import NavigationTopBar, { NavigationTopBarProps } from "./NavigationTopBar";

export default NavigationTopBar;
export type { NavigationTopBarProps };