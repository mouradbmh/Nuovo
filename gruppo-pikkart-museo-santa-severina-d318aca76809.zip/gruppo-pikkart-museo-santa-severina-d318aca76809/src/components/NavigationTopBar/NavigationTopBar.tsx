import { styled } from 'styled-components';
import classes from '@/components/NavigationTopBar/navigationTopBar.module.css'
import TextComponent from '@/components/TextComponent';

export interface NavigationTopBarProps {
  className?: string;
  backColor?: string;
  textColor?: string;
  title_key: string;
  button_left?: JSX.Element;
  button_right?: JSX.Element;
  shadow?: boolean
};

const StyledBar = styled.div<{ color?: string, backcolor?: string }>`
  ${props => props.backcolor !== undefined ? `background-color: ${props.backcolor};` : ''}
  ${props => props.color !== undefined ? `color: ${props.color};` : ''}
`;

const NavigationTopBar = ({
  className,
  backColor,
  textColor,
  title_key,
  button_left,
  button_right,
  shadow = false
}: NavigationTopBarProps) => {
  return (
    <StyledBar className={[className, classes.top_bar_container].join(' ')} color={textColor} backcolor={backColor}>
      <div className={classes.icon_container_left}>
        {
          button_left !== undefined ? (
            button_left
          ) : (<></>)
        }
      </div>
      <div className={classes.title_container}>
        <TextComponent text_key={title_key} color={textColor} text_size='large' shadow={shadow}/>
      </div>
      <div className={classes.icon_container_right}>
        {
          button_right !== undefined ? (
            button_right
          ) : (<></>)
        }
      </div>
    </StyledBar>
  )
}

export default NavigationTopBar;