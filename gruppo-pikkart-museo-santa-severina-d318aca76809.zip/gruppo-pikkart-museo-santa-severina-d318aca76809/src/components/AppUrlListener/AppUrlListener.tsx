// import { App, URLOpenListenerEvent } from "@capacitor/app";
// import { useEffect } from "react";
// import { useNavigate } from "react-router-dom";

// const AppUrlListener: React.FC<any> = () => {
//   const navigate = useNavigate();
//   useEffect(() => {
//     void App.addListener('appUrlOpen', (event: URLOpenListenerEvent) => {
//       // Example url: https://beerswift.app/tabs/tab2
//       // slug = /tabs/tab2
//       const slug = event.url.split('.it').pop();
//       // alert(slug);
//       if (slug) {
//         console.log('slug', slug)
//         // navigate(slug);
//       }
//       // If no match, do nothing - let regular routing
//       // logic take over
//     });
//   }, [navigate]);

//   return null;
// };

// export default AppUrlListener;