import classes from '@/components/TimeSelector/timeSelector.module.css';
import { ChevronDown, Clock } from 'react-feather';
import TextSubtext from '@/components/TextSubtext';
import { styled } from 'styled-components';

type TimeSelectorProps = {
    text_key: string;
    time: string;
    backColor?: string;
    color?: string;
    onClick: () => void;
};

const StyledTimeSelector = styled.button<{ backcolor: string, color: string }>`
  background-color: ${props => props.backcolor};
  color: ${props => props.color};
`;

const TimeSelector = ({
    text_key,
    time,
    backColor = "var(--emerald-700)",
    color = "white",
    onClick,
}: TimeSelectorProps) => {
    return (
        <div className={classes.container}>
            <div className={classes.label}>
                <Clock size={24} strokeWidth={1.5} color='var(--zinc-900)' />
                <TextSubtext
                    textProps={{
                        text_key: text_key,
                        text_size: "regular",
                        color: "var(--zinc-900)",
                    }}
                />
            </div>
            <div className={classes.time_selector_container}>
                <StyledTimeSelector color={color} backcolor={backColor} className={classes.time_selector} onClick={onClick}>
                    <div className={classes.time_selector_content}>
                        <TextSubtext
                            textProps={{
                                text_key: time,
                            }}
                        />
                        <ChevronDown size={16} />
                    </div>
                </StyledTimeSelector>
            </div>
        </div>
    );
};

export default TimeSelector;
