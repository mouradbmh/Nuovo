import HomeTopBar, { HomeTopBarProps } from "@/components/HomeTopBar/HomeTopBar";

export default HomeTopBar;
export type { HomeTopBarProps as AppTopBarProps };