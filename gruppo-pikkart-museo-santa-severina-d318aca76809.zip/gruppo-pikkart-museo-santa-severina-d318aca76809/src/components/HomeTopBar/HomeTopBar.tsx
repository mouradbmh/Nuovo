import classes from '@/components/HomeTopBar/homeTopBar.module.css'
import IconTextButton from '@/components/IconTextButton';
import * as Icon from 'react-feather';
import styled from 'styled-components';
import { useAppContext } from '@/hooks/useAppContext';
import TextSubtext from '../TextSubtext';
import { useTranslation } from 'react-i18next';
import { useNavigation } from '@/hooks/useNavigation';
import { useHome } from '@/hooks/useHome';
import SvgRenderer from '../SvgRenderer';

export interface HomeTopBarProps {
  title_key?: string;
  subtitle_key?: string;
  backColor?: string,
}

const StyledTopBar = styled.div<{ backcolor: string }>`
  background-color: ${props => props.backcolor};
  position: sticky;
  top: 0;
  z-index: 9999;
`;

const HomeTopBar = ({
  title_key,
  subtitle_key,
  backColor
}: HomeTopBarProps) => {
  const { config, theme } = useAppContext();
  const { t } = useTranslation();
  const { go } = useNavigation();
  const { ArActive } = useHome()

  if (title_key == undefined) {
    title_key = config?.nome as string;
  }
  if (subtitle_key == undefined) {
    subtitle_key = config?.messaggioHome as string;
  }
  if (backColor == undefined) {
    backColor = theme?.home?.header?.coloreSfondo ? theme?.home?.header?.coloreSfondo : 'unset';
  }

  const frontColor = theme?.home?.header?.coloreFronte ? theme?.home?.header?.coloreFronte : undefined;

  // useEffect(() => {
  //   alert(ArActive)
  // }, []);

  // console.log(config)
  return (
    <>
      <StyledTopBar backcolor={backColor}>
        <div className={classes.top_bar_container}>
          <div className={classes.text_container}>
            <div className={classes.logo_container}>
              {config?.urlLogo ?
                <SvgRenderer svgUrl={config?.urlLogo ?? ''} height={54}/>
                //<img src={config?.urlLogo} width={100} height={54}></img>
                :
                <TextSubtext
                  textProps={{ className: classes.top_bar_title, text_key: config?.nome as string, color: frontColor, text_size: 'large', text_line: 'normal', text_weight: 'bold' }}
                  subtextProps={{ text_key: config?.payoff as string, color: frontColor, text_size: 'small', text_line: 'normal' }}
                />
              }
            </div>
          </div>
          {ArActive && <div className={classes.button_container}>
            <IconTextButton
              icon={
                <Icon.Smartphone strokeWidth={1.5} width={24} height={24} fill={frontColor} stroke={backColor} />
              }
              textProps={{
                text_key: t('AR'),
                text_weight: 'semibold'

              }}
              onClick={() => go("/ar")}
              padding={{ vertical: 8, horizontal: 12 }}
              buttonMode='outline_borderless'
              shadow={true}
              backColor={theme?.bottoneSecondario?.coloreSfondo ? theme?.bottoneSecondario?.coloreSfondo : undefined}
              contentsColor={theme?.bottoneSecondario?.coloreFronte ? theme?.bottoneSecondario?.coloreFronte : undefined}
              bordercolor={theme?.bottoneSecondario?.coloreBordo ? theme?.bottoneSecondario?.coloreBordo : undefined}
            />
          </div>}
        </div>
      </StyledTopBar>
    </>
  );
}

export default HomeTopBar;