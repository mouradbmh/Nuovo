import OnboardingButton, { OnboardingButtonProps } from "@/components/OnboardingButton/OnboardingButton";

export default OnboardingButton;
export type { OnboardingButtonProps };