import TextSubtext from "../TextSubtext";
import classes from '@/components/OnboardingButton/onboardingButton.module.css';
import { MouseEventHandler } from "react";
import * as Icon from 'react-feather';

// interface Colors {
//   backColor: string
//   borderColor: string;
//   textColor: string;
//   subtextColor: string;
// }

export interface OnboardingButtonProps {
  // baseColors?: Colors;
  // clickedColors?: Colors;
  ButtonIcon: Icon.Icon;
  text_key: string;
  subtext_key: string;
  pressed: boolean;
  onClick: MouseEventHandler<HTMLButtonElement>;
}

// const StyledButton = styled.button<{ backColor: string, borderColor: string }>`
//   background-color: ${props => props.backColor};
//   border: solid 1px ${props => props.borderColor};
// `;

const OnboardingButton = ({
  // baseColors,
  // clickedColors,
  ButtonIcon,
  text_key,
  subtext_key,
  pressed = false,
  onClick,
}: OnboardingButtonProps) => {
  return (
    <button className={pressed ? [classes.large_button, classes.pressed].join(' ') : classes.large_button} onClick={(e) => {
      onClick(e);
    }}>
      <div className={classes.row_container}>
        <ButtonIcon className={classes.icon} strokeWidth={2} width={80} height={80} />
        <TextSubtext className={classes.text_container}
          textProps={{
            className: classes.text,
            text_key: text_key,
            text_size: 'large',
            text_line: 'normal',
            text_weight: 'bold',
          }}
          subtextProps={{
            className: classes.subtext,
            text_key: subtext_key,
            text_size: 'small',
            text_line: 'normal',
          }} />
      </div>
    </button>
  );
}

export default OnboardingButton;