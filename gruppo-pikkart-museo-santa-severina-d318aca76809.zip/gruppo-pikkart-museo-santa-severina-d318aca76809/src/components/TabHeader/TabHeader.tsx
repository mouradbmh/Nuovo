import { styled } from "styled-components";
import TextSubtext from "../TextSubtext";

export type TabHeaderProps = {
    inactivebackColor?: string,
    activeBackColor?: string,
    inactiveTextColor?: string,
    activeTextColor?: string,
    title_key?: string,
    active?: boolean,
    onClick?: () => void,
};

const StyledTab = styled.div<{ backcolor?: string, color?: string, bordercolor?: string }>`
  ${props => props.backcolor !== undefined ? `background-color: ${props.backcolor};` : ''}
  ${props => props.color !== undefined ? `color: ${props.color};` : ''}
  ${props => props.bordercolor !== undefined ? `border-bottom: 1px solid ${props.bordercolor};` : ''}
  padding: 16px 0;
  text-align: center;
  flex: 1 1 0;
  cursor: pointer;
`;

const TabHeader = ({
    inactivebackColor = "transparent",
    activeBackColor = "transparent",
    inactiveTextColor = "var(--zinc-500)",
    activeTextColor = "var(--emerald-700)",
    title_key = "Tab",
    active = false,
    onClick,
}: TabHeaderProps) => {
    const backColor = active ? activeBackColor : inactivebackColor;
    const color = active ? activeTextColor : inactiveTextColor;
    const borderColor = active ? activeTextColor : "transparent";

    return (
        <StyledTab backcolor={backColor} color={color} bordercolor={borderColor} onClick={onClick}>
            <TextSubtext 
                textProps={{
                    text_key: title_key,
                    text_size: "regular",
                    color: color,
                }}
            />
        </StyledTab>
    );
};

export default TabHeader;
