import TabHeader from "@/components/TabHeader/TabHeader";
import { TabHeaderProps } from "@/components/TabHeader/TabHeader";

export default TabHeader;
export type { TabHeaderProps };
