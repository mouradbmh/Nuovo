import Carousel from "@/components/Carousel/Carousel";
import { CarouselProps } from "@/components/Carousel//Carousel";

export default Carousel;
export type { CarouselProps };