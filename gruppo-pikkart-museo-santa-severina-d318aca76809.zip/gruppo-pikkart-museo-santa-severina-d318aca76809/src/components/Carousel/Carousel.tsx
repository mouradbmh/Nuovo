// Import Swiper React components
import { Swiper, SwiperClass, SwiperSlide } from 'swiper/react';

// Import Swiper styles
import 'swiper/css';
import 'swiper/css/pagination';
import 'swiper/css/zoom'

// import required modules
import { Pagination, Zoom } from 'swiper/modules';

import classes from '@/components/Carousel/carousel.module.css';
import '@/components/Carousel/carouselPagination.css'
import CarouselCard, { CarouselCardProps } from '@/components/CarouselCard';
import styled from 'styled-components';
import CarouselTitleBar, { CarouselTitleBarProps } from '@/components/CarouselTitleBar';
import { DetailsContentsType } from '../DetailsProvider/DetailsProvider';
import { useNavigation } from '@/hooks/useNavigation';
import { useCallback, useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useDataRequest } from '@ai4/data-request';
import { useAppContext } from '@/hooks/useAppContext';
import { useAuth } from '@/hooks/useAuth';
import playIcon from '@/assets/play.svg';
import HrLine from '../HrLine';
import LazyImage from '../LazyImage';

export interface CarouselProps {
  titleBar?: CarouselTitleBarProps;
  slides?: (CarouselCardProps & { id?: string, contentType?: string, url3d?: string, code?: string })[];
  slidesPerView?: number | 'auto';
  slidesInCard?: number;
  gap?: number;
  showButtons?: boolean;
  overlayButtons?: boolean;
  background?: string;
  paddingType?: 'all' | 'vertical' | 'horizontal' | 'none';
  onSlideChange?: (swiper: SwiperClass) => void;
  onSlidePress?: (swiper: SwiperClass) => void;
  selectedSlide?: string;
  zoom?: boolean;
  initialSlide?: number;
  hr?: boolean
  swipeToSlide?: number
  playVideo?: boolean;
}

const StyledCarousel = styled.div<{ backcolor: string }>`
  background-color: ${props => props.backcolor};
`;


/**
 * Carousel component.
 */
const Carousel = ({ // TODO: aggiungere parametro onSlideChange a Carousel e Swiper, per capire se si è arrivati in fondo.
  titleBar,
  slides,
  slidesPerView = 'auto',
  slidesInCard = 1,
  gap = 16,
  showButtons = false,
  overlayButtons = false,
  background = 'unset',
  paddingType = 'all',
  onSlideChange,
  onSlidePress,
  selectedSlide,
  initialSlide,
  hr,
  swipeToSlide,
  playVideo = false
}: CarouselProps) => {
  const [swiper, setSwiper] = useState<SwiperClass>();

  const divClasses = paddingType == 'none' ? [classes.carousel] : [classes.carousel, classes['carousel_padded_' + paddingType]];
  if (background != 'unset') {
    divClasses.push(classes['carousel_background_' + background]);
  }

  const { i18n } = useTranslation();

  const { isLoggedIn } = useAuth()

  const { useRestRequest } = useDataRequest();

  const { theme } = useAppContext();

  const [addRecent] = useRestRequest({
    path: 'rest/v1/app/contenuti-visti',
    headers: {
      'Content-Type': 'application/json',
      'Content-Language': i18n.language.split('-')[0]
    },
    method: 'POST',
    jwt: true,
    onError(err) {
      console.log('recentError', err)
    },
    onSuccess(data) {
      console.log('recentOK', data)
    },
  })


  const getType = useCallback((type: string | undefined) => {
    switch (type) {

      case 'Notizia':
      case 'NotiziaTraduzione':
        return DetailsContentsType.NEWS;

      case 'Evento':
      case 'EventoTraduzione':
        return DetailsContentsType.EVENT;

      case 'Esperienza':
      case 'EsperienzaTraduzione':
        return DetailsContentsType.EXPERIENCE;

      case 'PuntoDiInteresse':
      case 'PuntoDiInteresseTraduzione':
        return DetailsContentsType.POINT_OF_INTEREST;

      case 'Itinerario':
      case 'ItinerarioTraduzione':
        return DetailsContentsType.ITINERARY;

      case 'ProdottoTipico':
      case 'ProdottoTipicoTraduzione':
        return DetailsContentsType.TYPICAL_PRODUCT;

      case 'AttivitaCommerciale':
      case 'AttivitaCommercialeTraduzione':
        return DetailsContentsType.COMMERCIAL_ACTIVITY;

      case 'ContenutoInformativo':
      case 'ContenutoInformativoTraduzione':
        return DetailsContentsType.INFORMATIVE_CONTENT;

      case 'EsperienzaAR':
      case 'EsperienzaARTraduzione':
        return DetailsContentsType.AR_ELEMENT;

      case 'MatterportSpace':
      case 'TourVirtuale':
      case 'Video360':
      case 'Elemento3D':
        return DetailsContentsType.IMMERSIVE_CONTENT;

      default:
        return -1;
    }
  }, []);


  const getEntity = useCallback((type: string | undefined) => {
    switch (type) {

      case 'Notizia':
      case 'NotiziaTraduzione':
        return 'Notizia';

      case 'Evento':
      case 'EventoTraduzione':
        return 'Evento';

      case 'Esperienza':
      case 'EsperienzaTraduzione':
        return 'Esperienza';

      case 'PuntoDiInteresse':
      case 'PuntoDiInteresseTraduzione':
        return 'PuntoDiInteresse';

      case 'Itinerario':
      case 'ItinerarioTraduzione':
        return 'Itinerario';

      case 'ProdottoTipico':
      case 'ProdottoTipicoTraduzione':
        return 'ProdottoTipico';

      case 'AttivitaCommerciale':
      case 'AttivitaCommercialeTraduzione':
        return 'AttivitaCommerciale';

      case 'ContenutoInformativo':
      case 'ContenutoInformativoTraduzione':
        return 'ContenutoInformativo';

      case 'EsperienzaAR':
      case 'EsperienzaARTraduzione':
        return 'EsperienzaAR'

      case 'MatterportSpace':
      case 'TourVirtuale':
      case 'Video360':
      case 'Elemento3D':
        return 'PlayerVideo'

      case 'Luogo':
        return 'Luogo';

      default:
        return '';
    }
  }, []);

  const { go } = useNavigation()

  useEffect(() => {
    // console.log('selected',selectedSlide)
    if (selectedSlide !== '' && selectedSlide !== undefined) {
      const cardIdx = slides?.findIndex(el => el.id === selectedSlide)
      if (cardIdx) {
        if (cardIdx === 0) {
          swiper?.slideTo(0)
        } else {
          swiper?.slideTo(cardIdx)
        }
      }
    }
  }, [selectedSlide, swiper, slides])

  useEffect(() => {
    if (swipeToSlide && swiper) {
      swiper.slideTo(swipeToSlide)
    }
  }, [swipeToSlide, swiper])

  return (
    <StyledCarousel backcolor={background}>
      <div className={divClasses.length > 0 ? divClasses.join(' ') : undefined}>
        {titleBar && <CarouselTitleBar {...titleBar} />}
        {hr && <HrLine />}
        <Swiper
          className={classes.swiper}
          zoom={true}
          slidesPerView={slidesPerView}
          spaceBetween={gap}
          pagination={showButtons ? {
            el: '.' + classes.custom_pagination,
            clickable: true,
          } : undefined}
          observeSlideChildren
          modules={[Pagination, Zoom]}
          onSlideChange={onSlideChange}
          onSwiper={setSwiper}
          onClick={onSlidePress}
          initialSlide={initialSlide ?? 0}
        >
          {slides?.map((_, index) => {
            const cardSlides: (CarouselCardProps & { id?: string, contentType?: string, url3d?: string, code?: string })[] = [];
            if (index % slidesInCard == 0) {
              cardSlides.push(...slides.slice(index, index + slidesInCard))
            } else {
              return;
            }

            return (
              <SwiperSlide key={cardSlides.map(s => s.id).join('-')} className={classes.swiper_slide}>
                {
                  slidesInCard > 1 ? (<div className={classes.composite_card}>
                    {
                      cardSlides.map((slide, index) => {
                        if (slide?.id !== undefined && slide.id !== '' && getType(slide?.contentType).toString() !== '-1') {
                          return (
                            <div className={["swiper-zoom-container", classes.alignStart, classes.textAlignStart].join(' ')} key={slide.id} onClick={() => {
                              if (isLoggedIn) {
                                const req = {
                                  data: {
                                    nomeEntita: getEntity(slide?.contentType),
                                    CodiceLingua: i18n.language,
                                    contenutoUniqueId: slide.id,
                                    zoom: slide.zoom
                                  }
                                }
                                void addRecent(req)
                              }
                              go('/details/?id=' + slide.id! + '&type=' + getType(slide.contentType).toString())
                            }}>
                              <CarouselCard {...slide} key={slide.id} playVideo={playVideo} inFocus={swiper?.activeIndex === index} />
                              {getEntity(slide?.contentType) === 'PlayerVideo' && <LazyImage src={playIcon} />}
                            </div>
                          );
                        } else {
                          return <CarouselCard {...slide} key={slide.id} playVideo={playVideo} inFocus={swiper?.activeIndex === index} />
                        }
                      })
                    }
                  </div>) : (
                    <>
                      {
                        cardSlides.map((slide, index) => {
                          console.log(getType(slide?.contentType).toString())
                          if (slide.id !== undefined && slide.id !== '' && getType(slide?.contentType).toString() !== '-1') {
                            return (
                              <div key={slide.id} onClick={() => {
                                if (isLoggedIn) {
                                  const req = {
                                    data: {
                                      nomeEntita: getEntity(slide?.contentType),
                                      CodiceLingua: i18n.language,
                                      contenutoUniqueId: slide.id
                                    }
                                  }
                                  console.log('new recent', req)
                                  void addRecent(req)
                                }
                                if (slide.contentType === 'MatterportSpace' || slide.contentType === 'TourVirtuale') {
                                  go('/details/?id=' + slide.code! + '&type=' + getType(slide.contentType).toString() + '&experience=' + slide.contentType)
                                } else if (slide.contentType === 'Video360' || slide.contentType === 'Elemento3D') {
                                  go('/details/?id=' + slide.videoUrl! + '&type=' + getType(slide.contentType).toString() + '&experience=' + slide.contentType + '&preview=' + (slide.imgUrl ?? ''))
                                } else {
                                  go('/details/?id=' + slide.id! + '&type=' + getType(slide.contentType).toString())
                                }
                              }
                              }
                                style={{
                                  borderWidth: 2,
                                  borderColor: slide.id === selectedSlide ? (theme?.tabSelezionato?.coloreFronte ?? 'black') : 'transparent',
                                  borderStyle: 'solid',
                                  padding: 5,
                                  borderRadius: 10
                                }}
                              >
                                <CarouselCard {...slide} key={slide.id} playVideo={playVideo} inFocus={swiper?.activeIndex === index}>
                                  {getEntity(slide?.contentType) === 'PlayerVideo' && <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}><LazyImage src={playIcon} style={{ display: 'flex' }} /></div>}
                                </CarouselCard>
                              </div>
                            );
                          } else {
                            return <CarouselCard {...slide} key={slide.id} playVideo={playVideo} inFocus={swiper?.activeIndex === index} />
                          }
                        })
                      }
                    </>
                  )
                }
              </SwiperSlide>
            )
          })}
        </Swiper>
        {
          showButtons ? (
            <div className={overlayButtons ? [classes.custom_pagination, classes.overlay].join(' ') : classes.custom_pagination}></div> // FIXME: spostarla nel contenitore del testo se si vuole usare il gap della colonna flex.
          ) : (<></>)
        }
      </div>
    </StyledCarousel>
  );
};

export default Carousel;

