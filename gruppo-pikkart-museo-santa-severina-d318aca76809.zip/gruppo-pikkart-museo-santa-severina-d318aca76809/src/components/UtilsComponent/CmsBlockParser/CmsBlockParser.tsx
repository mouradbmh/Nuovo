
import { DetailsContentsType } from "@/components/DetailsProvider/DetailsProvider";
import parse, { domToReact, HTMLReactParserOptions } from "html-react-parser";
import { useCallback } from "react";




// import classes from "./CmsBlockParser.module.css";
import { Link } from "react-router-dom";



export interface CmsBlockParserProps {

  content: string,

}



const CmsBlockParser = ({ content }: CmsBlockParserProps) => {

  const getType = useCallback((type: string | undefined) => {
    switch (type) {

      case 'Notizia':
      case 'NotiziaTraduzione':
        return DetailsContentsType.NEWS;

      case 'Evento':
      case 'EventoTraduzione':
        return DetailsContentsType.EVENT;

      case 'Esperienza':
      case 'EsperienzaTraduzione':
      case 'esperienze':
        return DetailsContentsType.EXPERIENCE;

      case 'PuntoDiInteresse':
      case 'PuntoDiInteresseTraduzione':
      case 'punti-di-interesse':
        return DetailsContentsType.POINT_OF_INTEREST;

      case 'Itinerario':
      case 'ItinerarioTraduzione':
        return DetailsContentsType.ITINERARY;

      case 'ProdottoTipico':
      case 'ProdottoTipicoTraduzione':
        return DetailsContentsType.TYPICAL_PRODUCT;

      case 'AttivitaCommerciale':
      case 'AttivitaCommercialeTraduzione':
        return DetailsContentsType.COMMERCIAL_ACTIVITY;

      case 'ContenutoInformativo':
      case 'ContenutoInformativoTraduzione':
        return DetailsContentsType.INFORMATIVE_CONTENT;

      case 'EsperienzaAR':
      case 'EsperienzaARTraduzione':
        return DetailsContentsType.AR_ELEMENT;

      case 'MatterportSpace':
      case 'TourVirtuale':
      case 'Video360':
      case 'Elemento3D':
        return DetailsContentsType.IMMERSIVE_CONTENT;

      default:
        return -1;
    }
  }, []);

  const options: HTMLReactParserOptions = {

    // eslint-disable-next-line @typescript-eslint/ban-ts-comment

    // @ts-ignore

    replace: ({ attribs, children, name, parentNode }) => {

      if (attribs === null || attribs === undefined) {

        return;

      }

      // if (name === "div") {

      //   if (attribs.class === 'center spaced') {

      //     return (<div className={classes.containerImageMidiCopy}>{domToReact(children, options)}</div>)

      //   }

      //   return (<div className={attribs.class}>{domToReact(children, options)}</div>)

      // }


      // ALTRI PARSER --------------------------------------------------

      // if (name === "p") { //Parser del paragrafo

      //   return (<p className={classes.CmsBlockPageParserText}>{domToReact(children, options)}</p>)

      // }

      if (name === "a") { //PArser dei link
        if(attribs.href.startsWith('../../')){
          console.log(attribs.href.slice(0,6))

          const hrefArray = attribs.href.split('/');

          return(

            <Link to={'/details/?id=' + hrefArray[3] + '&type=' + getType(hrefArray[2].toString())} target="_blank">

              {domToReact(children, options)}

            </Link>
          );
        } else {
          return (


            <Link to={attribs.href} target="_blank">

              {domToReact(children, options)}

            </Link>


        );
        }



      }

      //----------------------------------------------------------------

    }

  };



  // if (loading) {

  //   return <div id={identifier} className={classes.CmsBlockPageParserContainer}>

  //     <div className={classes.LoadingWheelContainer}>

  //       <CircularProgress />

  //     </div>

  //   </div>;

  // }



  return <div >{parse(content, options)}</div>;

}



export default CmsBlockParser;

