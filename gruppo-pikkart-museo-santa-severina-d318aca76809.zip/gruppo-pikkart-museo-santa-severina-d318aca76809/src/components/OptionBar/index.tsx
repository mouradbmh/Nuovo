import OptionBar from "@/components/OptionBar/OptionBar";
import { OptionBarProps } from "@/components/OptionBar/OptionBar";


export default OptionBar;
export type { OptionBarProps };