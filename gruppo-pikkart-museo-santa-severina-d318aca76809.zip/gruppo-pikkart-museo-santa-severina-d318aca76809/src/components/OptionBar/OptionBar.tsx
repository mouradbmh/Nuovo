import classes from "@/components/OptionBar/optionBar.module.css";
import IconTextButton from "@/components/IconTextButton";
import TextSubtext from "@/components/TextSubtext";
import { styled } from "styled-components";

export type OptionBarProps = {
    iconLeft?: JSX.Element,
    iconRight?: JSX.Element,
    textRight_key?: string,
    textLeft_subtext_key?: string,
    titleWeight?: 'regular' | 'medium' | 'semibold' | 'bold',
    textLeft_key?: string,
    color?: string,
    backColor?: string,
    onHoverColor?: string,
    hidden?: boolean,
    disabled?: boolean,
    disabledColor?: string,
    onClick?: () => void,
};

const StyledDiv = styled.div<{ backcolor?: string, hovercolor?: string, hidden?: boolean, disabled?: boolean}>`
  ${props => props.backcolor !== undefined ? `background-color: ${props.backcolor};` : ''}
  ${props => props.hidden ? `display: none;` : ''}
  ${props => props.disabled ? `pointer-events: none;` : ''}
  &:hover {
    cursor: pointer;
    ${props => props.backcolor !== undefined ? `background-color: ${props.hovercolor};` : ''}
  }
`;

const OptionBar = ({
    iconLeft,
    iconRight,
    textRight_key,
    textLeft_subtext_key,
    titleWeight = "regular",
    textLeft_key = "Option",
    color = "var(--zinc-900)",
    onHoverColor = "var(--zinc-100)",
    backColor = "transparent",
    hidden = false,
    disabled = false,
    disabledColor = "var(--zinc-400)",
    onClick,
}: OptionBarProps) => {
    return (
        <StyledDiv hidden={hidden} disabled={disabled} backcolor={backColor} hovercolor={onHoverColor} className={classes.row_container} onClick={onClick}>
            <div className={classes.option_container}>
                {
                    iconLeft && <IconTextButton
                        backColor="transparent"
                        contentsColor={disabled ? disabledColor : color}
                        buttonMode="outline_borderless"
                        icon={iconLeft}
                        onClick={() => { }}
                    />
                }
                <TextSubtext
                    textProps={{
                        text_key: textLeft_key,
                        text_size: "regular",
                        text_weight: titleWeight,
                        color: disabled ? disabledColor : color,
                        className: classes.option_text,
                    }}
                    subtextProps={{
                        text_key: textLeft_subtext_key ? textLeft_subtext_key : "",
                        text_size: "small",
                        color: disabled ? disabledColor : "var(--zinc-500)",
                        className: classes.option_subtext,
                    }}
                />
            </div>
            {
                iconRight && <IconTextButton
                    backColor="transparent"
                    contentsColor={disabled ? disabledColor : color}
                    buttonMode="outline_borderless"
                    icon={iconRight}
                />
            }
            {
                textRight_key && <TextSubtext
                    textProps={{
                        text_key: textRight_key,
                        text_size: "regular",
                        color: disabled ? disabledColor : color,
                    }}
                />
            }
        </StyledDiv>
    );
};

export default OptionBar;
