import classes from '@/components/LocationComponent/locationComponent.module.css';
import * as Icon from 'react-feather';
import TextSubtext from "../TextSubtext";
import { useProfile } from "@/hooks/useProfile";
import { useKey } from '@/hooks/useKeyContext';

export interface LocationComponentProps {
  text_key: string;
  subtext_key: string;
  tenantId: string;
  authDomain: string;
}

const LocationComponent = ({
  text_key,
  subtext_key,
  tenantId,
  authDomain
}: LocationComponentProps) => {
  const { setLocation, nextScreen } = useProfile();
  const { setKey, setKeyLoc, setAuthDomain } = useKey()

  return (
    <div className={classes.row_container} onClick={() => {
      console.log('selected', text_key, tenantId, authDomain)
      setLocation(text_key);
      localStorage.setItem('xApiKey', tenantId);
      setKey(tenantId)
      setKeyLoc(text_key);
      setAuthDomain(authDomain)
      nextScreen();
    }}>
      <Icon.MapPin strokeWidth={1.5} width={24} height={24} />
      <TextSubtext
        textProps={{
          text_key: text_key,
          text_line: 'tight'
        }}
        subtextProps={{
          className: classes.subtext,
          text_key: subtext_key,
          text_size: 'small',
          text_line: 'tight'
        }} />
    </div>
  );
};

export default LocationComponent;