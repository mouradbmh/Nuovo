import LocationComponent , { LocationComponentProps } from "@/components/LocationComponent/LocationComponent";

export default LocationComponent;
export type { LocationComponentProps };