import { ReactNode, createContext, useState } from "react";
import { useNavigate } from "react-router-dom";

export type NavigationContextType = {
    isGoingBack: boolean;
    goBack: () => void;
    go: (path: string, backTransition?: boolean) => void;
};

export const NavigationContext = createContext<NavigationContextType>({} as NavigationContextType);

type Props = {
    children: JSX.Element | ReactNode;
};

const NavigationProvider = ({ children }: Props) => {
    const navigate = useNavigate();
    const [ isGoingBack, setIsGoingBack ] = useState<boolean>(false);

    const goBack = () => {
        setIsGoingBack(true);
        navigate(-1);
    };

    const go = (path: string, backTransition?: boolean) => {
        setIsGoingBack(backTransition || false);
        navigate(path);
    }

    return (
        <NavigationContext.Provider value={{ isGoingBack, goBack, go }}>
            {children}
        </NavigationContext.Provider>
    );
};

export default NavigationProvider;