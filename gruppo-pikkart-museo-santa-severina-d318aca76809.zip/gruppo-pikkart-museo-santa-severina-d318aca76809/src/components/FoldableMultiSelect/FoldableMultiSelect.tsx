import { ChevronUp, ChevronRight, Circle, CheckCircle } from "react-feather";
import OptionBar from "@/components/OptionBar";
import Separator from "@/components/Separator";
import { useState } from "react";

type SelectionProp = {
    textLeft_key: string,
    onClick?: () => void,
};

type FoldableMultiSelectProps = {
    textLeft_key: string,
    textLeft_subtext_key?: string,
    options?: SelectionProp[],
};

const FoldableMultiSelect = ({ textLeft_key, textLeft_subtext_key, options }: FoldableMultiSelectProps) => {
    const [open, setOpen] = useState<boolean>(false);

    return (
        <div>
            <OptionBar
                textLeft_key={textLeft_key}
                titleWeight="regular"
                textLeft_subtext_key={textLeft_subtext_key}
                onClick={() => setOpen(!open)}
                iconRight={open ? <ChevronUp height="24" strokeWidth={1.5} width="24" /> :
                    <ChevronRight height="24" strokeWidth={1.5} width="24" />}
            />
            {open &&
                options?.map((option, index) => {
                    return (
                        <OptionBar
                            key={index}
                            {...option}
                            iconLeft={option.textLeft_key === textLeft_subtext_key ? <CheckCircle size={16} /> : <Circle size={16} />}
                        />
                    );
                })
            }
            {open && (
                <Separator />
            )}
        </div>
    );
};

export default FoldableMultiSelect;
