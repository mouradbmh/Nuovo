import FoldableMultiSelect from "@/components/FoldableMultiSelect/FoldableMultiSelect";

export default FoldableMultiSelect;
