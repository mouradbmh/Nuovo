import classes from '@/components/Spacer/spacer.module.css';

const Spacer = () => {
    return (
        <div className={classes.spacer}></div>
    )
  }
  
  export default Spacer;