import Spacer from "@/components/Spacer/Spacer";

export default Spacer;