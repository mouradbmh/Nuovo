import DatePickerPane, { DatePickerPaneProps } from "@/components/DatePickerPane/DatePickerPane";

export default DatePickerPane;
export type { DatePickerPaneProps };