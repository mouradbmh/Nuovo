import { Dispatch, SetStateAction, useRef, useState } from "react";
// eslint-disable-next-line @typescript-eslint/ban-ts-comment
// @ts-ignore
import { Value } from "react-calendar/dist/cjs/shared/types";
import SlidingPane from "@/components/SlidingPaneComponent";

import classes from "@/components/DatePickerPane/datePicker.module.css";
import CustomCalendar from "@/components/CustomCalendar";
import IconTextButton from "@/components/IconTextButton";
import { useTranslation } from "react-i18next";
import { useSearch } from "@/hooks/useSearch";

export interface DatePickerPaneProps {
  val: Value;
  setVal: Dispatch<SetStateAction<Value>>;
  paneNum: number;
  openPane: number;
  setOpenPane: Dispatch<SetStateAction<number>>;
}

const DatePickerPane = ({
  val,
  setVal,
  paneNum,
  openPane,
  setOpenPane,
}: DatePickerPaneProps) => {
  const [key, setKey] = useState(1); // Workaround per il calendario che non si aggiorna se resettato durante la selezione del range.
  const { t } = useTranslation();
  const updated = useRef(false);

  const { updateSubfilterStates, updateSubfilterConfirmation } = useSearch();

  const tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 1);

  const datesString = () => {
    {
      let dates = val as Array<Date | null>;
      if (dates != null && dates[0]) {
        return `${dates[0]?.toLocaleDateString() ?? ' '} -> ${dates[1]?.toLocaleDateString() ?? ' '}`;
      } else {
        let date = val as Date;
        if (date != null) {
          return `${date?.toLocaleDateString()} ?? ' '} -> `;
        }
      }
      return 'Seleziona periodo';
    }
  }

  return (
    <SlidingPane
      className={classes.date_sliding_pane}
      title_key={t('date_picker_title')}
      confirmButtonText_key={datesString()}
      paneNum={paneNum}
      openPane={openPane}
      setOpenPane={setOpenPane}
      disableConfirmButtonCondition={(val as Array<Date>)?.[1] == null}
      onResetClick={() => {
        setVal(null);
        setKey(k => k + 1);
        updateSubfilterStates();
      }}
      onConfirmClick={updateSubfilterConfirmation}
      onRequestClose={() => {
        if (updated.current) {
          updated.current = false;
          updateSubfilterConfirmation();
        }
      }}>
      <div className={classes.datepicker_container}>
        <div className={classes.pane_button_container}>
          <IconTextButton
            textProps={{
              text_key: t('today')
            }}
            buttonMode='outline'
            padding={{ all: 8 }}
            onClick={() => setVal([new Date(), new Date()])} />
          <IconTextButton
            textProps={{
              text_key: t('tomorrow')
            }}
            buttonMode='outline'
            padding={{ all: 8 }}
            onClick={() => setVal([tomorrow, tomorrow])} />
        </div>
        <div className={classes.calendar_wrapper}>
          <CustomCalendar
            key={key}
            value={val}
            onChange={v => {
              setVal(v);
              updated.current = true;
            }}
            selectRange allowPartialRange
            minDate={new Date()}
            minDetail='month'
            maxDetail='month'
            prev2Label={null}
            next2Label={null}
            className={classes.calendar}
          />
        </div>
      </div>
    </SlidingPane>
  )
};

export default DatePickerPane;