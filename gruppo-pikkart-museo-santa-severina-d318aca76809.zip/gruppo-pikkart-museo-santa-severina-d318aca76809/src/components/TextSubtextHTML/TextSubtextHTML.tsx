import TextComponent, { TextProps } from '@/components/TextComponent';
import { styled } from 'styled-components';

import classes from '@/components/TextSubtextHTML/textSubTextHTML.module.css';
import CmsBlockParser from '../UtilsComponent/CmsBlockParser/CmsBlockParser';

export interface TextSubtextHTMLProps {
  className?: string
  /**
   * The background color for the container.
   */
  backColor?: string,
  /**
   * Parameters for the primary text.
   */
  textProps: TextProps;
  /**
   * HTML contents for the secondary text.
   */
  subTextHTML?: string;
  /**
   * Optional gap between the texts.
   */
  gap?: number;
}

const StyledDiv = styled.div<{ backcolor?: string, gap: number }>`
  ${props => props.backcolor !== undefined ? `background-color: ${props.backcolor};` : ''}
  gap: ${props => props.gap + 'px'};
`;

const TextSubtextHTML = ({
  className,
  backColor,
  textProps,
  subTextHTML,
  gap = 0,
}: TextSubtextHTMLProps) => {

  return (
    <StyledDiv className={className !== undefined ? [className, classes.texts_container].join(' ') : classes.texts_container} backcolor={backColor} gap={gap}>
      <TextComponent {...textProps} />
      {
        // subTextHTML && <div dangerouslySetInnerHTML={{__html: subTextHTML}}></div>
        subTextHTML && <CmsBlockParser content={subTextHTML}/>
      }
    </StyledDiv>
  )
}

export default TextSubtextHTML;