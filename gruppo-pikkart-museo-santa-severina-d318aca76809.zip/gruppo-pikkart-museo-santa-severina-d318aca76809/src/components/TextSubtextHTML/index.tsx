import TextSubtextHTML, { TextSubtextHTMLProps } from '@/components/TextSubtextHTML/TextSubtextHTML';

export default TextSubtextHTML;
export type { TextSubtextHTMLProps };