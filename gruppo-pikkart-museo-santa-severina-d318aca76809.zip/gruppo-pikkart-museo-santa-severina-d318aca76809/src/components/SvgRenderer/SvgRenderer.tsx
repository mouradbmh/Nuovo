import { useEffect, useState } from 'react';
import parse, { domToReact, HTMLReactParserOptions } from "html-react-parser";

type SvgRenderer = {
  svgUrl: string;
  width?: number;
  height?: number;
  stroke?: string;
}

const SvgRenderer = ({ svgUrl, width, height, stroke }: SvgRenderer) => {
  const [svgContent, setSvgContent] = useState('');

  useEffect(() => {
    fetch(svgUrl)
      .then(response => response.text())
      .then(svgData => {
        // if(svgData.search(/class/gi) !== -1){
        //   svgData = svgData.replace(/class/gi, 'className')
        // }
        // if(svgData.search('xmlns:xlink') !== -1){
        //   svgData = svgData.replace(/xmlns:xlink/gi, 'xmlnsXlink')
        // }
        setSvgContent(svgData);
        //console.log(svgData)
      })
      .catch(error => {
        console.error('Si è verificato un errore nel recupero dell\'SVG:', error);
      });
  }, [svgUrl]);

  const options: HTMLReactParserOptions = {

    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-ignore
    replace: ({ attribs, children, name, parentNode }) => {

      if (attribs === null || attribs === undefined) {
        return;
      }

      if (name === "path") {
        const attributes = attribs
        //console.log('child', attributes)
        const cls = attributes.class as string
        delete attributes['class']

        return <path {...attributes} className={cls} />
      }

      if (name === "g") {
        const attributes = attribs

        return <g {...attributes}>
          {domToReact(children, options)}
        </g>
      }

      if (name === "svg") { //Parser del tag svg
        // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment
        const attributes = attribs

        console.log('attb', attributes)
        delete attributes['style']


        console.log(attributes)
        return <svg {...attributes} width={width ? width?.toString() + 'px' : null} height={height ? height.toString() + 'px' : null} stroke={stroke}>
          {domToReact(children, options)}
        </svg>
      }

      if (name === "path") { //Parser del tag svg
        // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment
        const attributes = attribs;
        return <path {...attributes}>
          {domToReact(children, options)}
        </path>
      }
    }

  };

  if (svgContent === '') {
    return <></>;
  }

  // console.log(svgContent)
  return (
    parse(svgContent, options)
  );
}

export default SvgRenderer;