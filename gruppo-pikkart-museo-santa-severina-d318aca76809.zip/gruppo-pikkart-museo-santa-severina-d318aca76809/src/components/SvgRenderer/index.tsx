import SvgRenderer from "@/components/SvgRenderer/SvgRenderer";

export default SvgRenderer;