import TextComponent, { TextSizesProps } from '@/components/TextComponent';

import classes from '@/components/CarouselCard/carouselCard.module.css'
import CardImageContainer from '@/components/CardImageContainer';
import IconTextButton from '@/components/IconTextButton';
import { useAppContext } from '@/hooks/useAppContext';
import CardVideoContainer from '../CardVideoContainer';

export type CardType = 'mini' | 'smaller' | 'small' | 'medium' | 'large' | 'larger' | 'largetall' | 'largesquare' | 'fullwidth';

export interface CarouselCardProps {

  id?: string;

  cardType: CardType;

  /**
   * Defines whether the card should have background or not.
   */
  cardStyled?: boolean;
  /**
   * Text displayed on the image to the left.
   */
  eventText?: string;
  /**
   * Displays the button on the image to the right.
   */
  hasArButton?: boolean;
  /**
   * Title of the card.
   */
  title?: string;
  titleColor?: string;
  titleWeight?: "medium" | "regular" | "bold" | "semibold" | undefined;
  /**
   * Text below the title for secondary information.
   */
  secondaryInfo?: string;
  secondaryInfoColor?: string;
  /**
   * Description of the card.
   */
  description?: string;
  descriptionColor?: string;
  /**
   * Color palette for all the text elements.
   */
  textColor?: 'light' | 'dark';
  /**
   * Image url.
   */
  imgUrl?: string;
  /**
   * Data for the button at the bottom of the card.
   */
  button?: {
    text: string;
    onClick?: () => void;
  };

  contentType?: string;
  children?: React.ReactNode;

  isVideo?: boolean;
  hasPlayButton?: boolean;
  videoUrl?: string

  urlYoutube?: string;
  zoom?: boolean;
  playVideo?: boolean;
  inFocus?: boolean
}

const row_limit = 2;

const text_sizes_map: Map<CarouselCardProps['cardType'], {
  title: TextSizesProps,
  secondaryText: TextSizesProps,
  description: TextSizesProps
}> = new Map(
  [
    ['mini', {
      title: {
        text_size: 'small',
        text_line: 'normal',
        text_weight: 'bold'
      },
      secondaryText: {
        text_size: 'tiny',
        text_line: 'normal',
        text_weight: 'regular'
      },
      description: {
        text_size: 'tiny',
        text_line: 'normal',
        text_weight: 'regular'
      },
    }],
    ['smaller', {
      title: {
        text_size: 'tiny',
        text_line: 'tight',
        text_weight: 'medium'
      },
      secondaryText: {
        text_size: 'tiny',
        text_line: 'tight',
        text_weight: 'regular'
      },
      description: {
        text_size: 'tiny',
        text_line: 'tight',
        text_weight: 'regular'
      },
    }],
    ['small', {
      title: {
        text_size: 'small',
        text_line: 'tight',
        text_weight: 'semibold'
      },
      secondaryText: {
        text_size: 'tiny',
        text_line: 'normal',
        text_weight: 'regular'
      },
      description: {
        text_size: 'tiny',
        text_line: 'normal',
        text_weight: 'regular'
      },
    }],
    ['medium', {
      title: {
        text_size: 'regular',
        text_line: 'none',
        text_weight: 'bold'
      },
      secondaryText: {
        text_size: 'tiny',
        text_line: 'normal',
        text_weight: 'regular'
      },
      description: {
        text_size: 'tiny',
        text_line: 'normal',
        text_weight: 'regular'
      },
    }],
    ['large', {
      title: {
        text_size: 'regular',
        text_line: 'normal',
        text_weight: 'bold'
      },
      secondaryText: {
        text_size: 'tiny',
        text_line: 'normal',
        text_weight: 'regular'
      },
      description: {
        text_size: 'tiny',
        text_line: 'normal',
        text_weight: 'regular'
      },
    }],
    ['larger', {
      title: {
        text_size: 'regular',
        text_line: 'normal',
        text_weight: 'bold'
      },
      secondaryText: {
        text_size: 'tiny',
        text_line: 'normal',
        text_weight: 'regular'
      },
      description: {
        text_size: 'tiny',
        text_line: 'normal',
        text_weight: 'regular'
      },
    }],
    ['largetall', {
      title: {
        text_size: 'small',
        text_line: 'tight',
        text_weight: 'semibold'
      },
      secondaryText: {
        text_size: 'tiny',
        text_line: 'normal',
        text_weight: 'regular'
      },
      description: {
        text_size: 'tiny',
        text_line: 'normal',
        text_weight: 'regular'
      },
    }],
    ['largesquare', {
      title: {
        text_size: 'title3',
        text_line: 'normal',
        text_weight: 'bold'
      },
      secondaryText: {
        text_size: 'small',
        text_line: 'normal',
        text_weight: 'regular'
      },
      description: {
        text_size: 'small',
        text_line: 'normal',
        text_weight: 'regular'
      },
    }],
  ]
)

/**
 * Carousel component.
 */
const CarouselCard = ({
  cardType,
  cardStyled = false,
  eventText,
  title,
  titleColor = 'black',
  titleWeight,
  secondaryInfo,
  secondaryInfoColor = 'black',
  description,
  descriptionColor = 'black',
  textColor = 'dark',
  button,
  hasArButton = false,
  imgUrl,
  children,
  hasPlayButton = false,
  isVideo = false,
  videoUrl,
  urlYoutube,
  zoom,
  playVideo,
  inFocus = false
}: CarouselCardProps) => {
  const { theme } = useAppContext();

  const divClasses = [classes['card_container_' + cardType]];
  if (cardStyled) {
    divClasses.push(classes['card_container_' + ((textColor == 'light') ? 'dark' : 'light')]);
  }

  const contentClasses = [classes.card_contents_container];
  if (cardStyled) {
    contentClasses.push(classes.card_contents_padded);
  }

  const text_sizes = text_sizes_map.get(cardType);

  // console.log(isVideo, "isVideo", playVideo, "playVideo")

  return (
    <div className={divClasses.join(' ')}>

      {isVideo && playVideo ? <CardVideoContainer cardType={cardType} eventText={eventText} hasArButton={hasArButton} playVideo={playVideo} urlPreview={imgUrl ?? ''} url={videoUrl} autoplay={inFocus}/> : <CardImageContainer zoom={zoom} cardType={cardType} eventText={eventText} hasArButton={hasArButton} hasPlayButton={hasPlayButton} url={imgUrl} urlYoutube={urlYoutube}>{children}</CardImageContainer>}

      <div className={contentClasses.join(' ')}>
        <div className={classes.card_contents_container_inner}>
          {
            title !== undefined ? (
              <TextComponent className={cardType == 'largesquare' ? [classes.card_text_top, classes.square_card_title].join(' ') : classes.card_text_top}
                color={titleColor} text_key={title}
                text_size={text_sizes?.title.text_size}
                text_weight={titleWeight ? titleWeight : text_sizes?.title.text_weight} text_line={text_sizes?.title.text_line} row_limit={row_limit} />
            ) : (<></>)
          }
          {
            secondaryInfo !== undefined ? (
              <TextComponent className={classes.card_text_middle} color={secondaryInfoColor} text_size={text_sizes?.secondaryText.text_size} text_line={text_sizes?.secondaryText.text_line} text_weight={text_sizes?.secondaryText.text_weight} text_key={secondaryInfo} row_limit={row_limit} />
            ) : (<></>)
          }
        </div>
        {
          description !== undefined ? (
            <TextComponent className={[classes.card_text_bottom, classes.text_row_limit].join(' ')} color={descriptionColor} text_size={text_sizes?.description.text_size} text_line={text_sizes?.description.text_line} text_weight={text_sizes?.description.text_weight} text_key={description} row_limit={row_limit} />
          ) : (<></>)
        }
        {
          button !== undefined ? (
            <IconTextButton className={classes.card_button} onClick={button.onClick}
              textProps={{
                text_key: button.text,
                text_weight: 'semibold'
              }}
              backColor={theme?.bottonePrimario?.coloreBordo ?? undefined}
              contentsColor={theme?.bottonePrimario?.coloreFronte ?? undefined}
              padding={{ vertical: 8, horizontal: 16 }} />
          ) : (<></>)
        }
      </div>
    </div>
  );
};

export default CarouselCard;