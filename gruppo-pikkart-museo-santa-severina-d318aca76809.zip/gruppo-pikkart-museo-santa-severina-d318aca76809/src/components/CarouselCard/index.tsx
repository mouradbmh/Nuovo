import CarouselCard from "@/components/CarouselCard/CarouselCard";
import { CarouselCardProps } from "@/components/CarouselCard/CarouselCard";

export default CarouselCard;
export type { CarouselCardProps };