import classes from '@/components/TextComponent/text.module.css';
import styled from 'styled-components';

export interface TextSizesProps {
  text_size?: 'title1' | 'title2' | 'title3' | 'title4' | 'large' | 'regular' | 'small' | 'tiny';
  text_line?: 'none' | 'tight' | 'normal';
  text_weight?: 'regular' | 'medium' | 'semibold' | 'bold';
}

export interface TextContentProps {
  text_key: string;
  className?: string;
  color?: string;
  text_size?: 'title1' | 'title2' | 'title3' | 'title4' | 'large' | 'regular' | 'small' | 'tiny';
  text_line?: 'none' | 'tight' | 'normal';
  text_weight?: 'regular' | 'medium' | 'semibold' | 'bold';
  row_limit?: number;
  onHoverColor?: string;
  onClick?: () => void;
  shadow?: boolean
}

export type TextProps = TextContentProps & TextSizesProps;

const StyledText = styled.span<{ color?: string, row_limit?: number, hovercolor?: string, shadow?: boolean }>`
  ${props => props.color !== undefined ? `color: ${props.color};` : '' }
  ${props => props.row_limit !== undefined ? `display: -webkit-box;
  -webkit-line-clamp: ${props.row_limit};
  -webkit-box-orient: vertical;
  overflow: hidden;` : ''}
  ${props => props.hovercolor ? `&:hover { color: ${props.hovercolor}; }` : ''}
  ${props => props.shadow ? `text-shadow: 0 0 3px black, 0 0 5px black;` : ''}
  
`;

/**
 * Primary UI component for user interaction
 */
const TextComponent = ({
  text_key,
  className,
  text_size = 'regular',
  text_line = 'none',
  text_weight = 'regular',
  color,
  row_limit,
  onHoverColor: hoverColor,
  onClick,
  shadow = false
}: TextProps) => {
  let cl = [classes.text, classes['text_' + text_size], classes['text_weight_' + text_weight]];
  if (text_line !== 'none') {
    cl.push(classes['line_' + text_line])
  }
  if (className !== undefined) {
    cl.push(className)
  }

  return (
    <StyledText onClick={onClick} className={cl.join(' ')} color={color} row_limit={row_limit} hovercolor={hoverColor} shadow={shadow}>{text_key}</StyledText>
  );
};

export default TextComponent;
