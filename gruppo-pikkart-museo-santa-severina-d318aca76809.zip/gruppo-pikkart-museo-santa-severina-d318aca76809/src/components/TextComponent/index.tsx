import TextComponent from "@/components/TextComponent/TextComponent";
import { TextSizesProps, TextContentProps, TextProps } from "@/components/TextComponent/TextComponent";

export default TextComponent;
export type { TextSizesProps, TextContentProps, TextProps };
