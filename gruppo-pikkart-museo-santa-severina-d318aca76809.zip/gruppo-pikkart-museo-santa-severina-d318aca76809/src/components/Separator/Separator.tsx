import { styled } from "styled-components";

type SeparatorProps = {
    color?: string;
    height?: string;
    width?: string;
};

const StyledSeparator = styled.div<{ color: string, height: string, width: string }>`
    background-color: ${props => props.color};
    height: ${props => props.height};
    width: ${props => props.width};
`;

const Separator = ({
    color = "var(--sky-lighter)",
    height = "1px",
    width = "100%",
}: SeparatorProps) => {
    return (
        <StyledSeparator color={color} height={height} width={width} />
    );
}

export default Separator;
