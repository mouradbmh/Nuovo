import Separator from '@/components/Separator/Separator';

export default Separator;