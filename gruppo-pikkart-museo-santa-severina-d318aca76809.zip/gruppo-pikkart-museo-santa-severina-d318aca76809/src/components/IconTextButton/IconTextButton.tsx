import { CSSProperties } from 'react';
import classes from '@/components/IconTextButton/iconTextButton.module.css';
import TextComponent, { TextProps } from '@/components/TextComponent';
import styled from 'styled-components';

export interface IconTextButtonProps {
  /**
   * Class(es) applied to the outer container of the component.
   */
  className?: string,
  /**
   * Defines the appearance of the button.
   */
  buttonMode?: "normal" | "outline" | "outline_borderless"; // TODO: remove
  /**
   * Removes the rounding from the border.
   */
  no_rounded_borders?: boolean;
  /**
   * Padding values for the button.
   */
  padding?: {
    all?: number | string,
    vertical?: number | string,
    horizontal?: number | string,
    top?: number | string,
    right?: number | string,
    bottom?: number | string,
    left?: number | string
  }
  /**
   * Background color of the button.
   */
  backColor?: string,
  /**
   * Color of the contents in the button.
   */
  contentsColor?: string,
  /**
   * Color of the contents in the button when hovered.
   */
  hoverColor?: string,
  /**
   * Background color of the button when hovered.
   */
  hoverBackgroundColor?: string,
  /**
   * Color of the border.
   */
  bordercolor?: string,
  /**
   * Adds shadows around the button.
   */
  shadow?: boolean
  /**
   * Disables button.
   */
  disabled?: boolean;
  /**
   * If set to true, the button will expand to fill its container.
   */
  expanded?: boolean;
  /**
   * Sets the button to always active.
   */
  active?: boolean;
  /**
   * Icon displayed inside the button.
  */
  icon?: JSX.Element;
  /**
   * Parameters for the text in the button. Color is ignored.
   */
  textProps?: TextProps;

  subTextProps?: TextProps;
  /**
   * Inverts the position of text and icon containers.
   */
  invertContents?: boolean;
  /**
   * Sets the gap between icon and text.
   */
  gap?: number;
  onClick?: () => void;
}

const StyledButton = styled.button<{ color?: string, backcolor?: string, hovercolor?: string, hoverbackgroundcolor?: string, bordercolor?: string }>`
  background-color: ${props => props.backcolor};
  color: ${props => props.color};
  border-color: ${props => props.bordercolor};
  &:hover * { color: ${props => props.hovercolor}; }
  &:hover * { background-color: ${props => props.hoverbackgroundcolor}; border-color: ${props => props.hoverbackgroundcolor} }
`;

/**
 * Primary UI component for user interaction
 */
const IconTextButton = ({
  className,
  buttonMode = 'normal',
  no_rounded_borders = false,
  padding,
  shadow = false,
  disabled = false,
  expanded = false,
  active = false,
  icon,
  textProps,
  subTextProps,
  invertContents = false,
  gap = 5,
  contentsColor = 'var(--emerald-700)',
  backColor = 'var(--outline-bg)',
  hoverBackgroundColor,
  hoverColor,
  bordercolor,
  onClick
}: IconTextButtonProps) => {
  const buttonClasses = [classes.button];
  if (buttonMode != 'normal') {
    buttonClasses.push(classes['button_' + buttonMode]);
  }
  if (!no_rounded_borders) {
    buttonClasses.push(classes.button_rounded);
  }
  if (shadow) {
    buttonClasses.push(classes.button_shadows)
  }
  if (expanded) {
    buttonClasses.push(classes.button_expanded)
  }
  if (active) {
    buttonClasses.push(classes.button_active)
  }
  if (className !== undefined) {
    buttonClasses.push(className);
  }

  const containerClasses = [classes.button_inner_container];
  if (invertContents) {
    containerClasses.push(classes.reverse)
  }

  const style: CSSProperties = { gap: gap };
  if (padding !== undefined) {
    if (padding.all !== undefined) {
      style.padding = padding.all
    } else {
      if (padding.vertical !== undefined) {
        style.paddingTop = padding.vertical
        style.paddingBottom = padding.vertical
      } else {
        padding.top !== undefined ? style.paddingTop = padding.vertical : 0;
        padding.bottom !== undefined ? style.paddingBottom = padding.bottom : 0;
      }

      if (padding.horizontal !== undefined) {
        style.paddingRight = padding.horizontal
        style.paddingLeft = padding.horizontal
      } else {
        padding.left !== undefined ? style.paddingRight = padding.right : 0;
        padding.right !== undefined ? style.paddingLeft = padding.left : 0;
      }
    }
  }

  return (
    <StyledButton className={buttonClasses.join(' ')} disabled={disabled} onClick={onClick}
      color={contentsColor} backcolor={backColor}
      hovercolor={hoverColor} hoverbackgroundcolor={hoverBackgroundColor} bordercolor={bordercolor}>
      <div className={containerClasses.join(' ')} style={style}>
        {
          icon !== undefined ? (
            <div className={classes.icon_container}>
              {icon}
            </div>
          ) : (<></>)
        }
        {
          textProps !== undefined ? (
            <div className={classes.text_container}>
              <TextComponent {...textProps} />
            </div>
          ) : (<></>)
        }
      </div>
      {
          subTextProps !== undefined ? (
            <div style={{textAlign: 'start'}}>
              <TextComponent {...subTextProps} />
            </div>
          ) : (<></>)
        }
    </StyledButton>
  );
};

export default IconTextButton;
