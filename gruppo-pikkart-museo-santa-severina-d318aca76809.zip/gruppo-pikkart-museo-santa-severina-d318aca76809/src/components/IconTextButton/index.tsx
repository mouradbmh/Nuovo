import IconTextButton, { IconTextButtonProps } from "@/components/IconTextButton/IconTextButton";

export default IconTextButton;
export type { IconTextButtonProps };