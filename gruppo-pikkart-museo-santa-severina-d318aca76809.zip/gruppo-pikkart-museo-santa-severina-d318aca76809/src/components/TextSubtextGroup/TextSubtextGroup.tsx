import TextComponent, { TextProps } from '@/components/TextComponent';
import { styled } from 'styled-components';

import classes from '@/components/TextSubtext/textSubText.module.css';

export interface TextSubtextGroupProps {
  className?: string
  /**
   * The background color for the container.
   */
  backColor?: string,
  /**
   * Parameters for the primary text.
   */
  textProps: TextProps;
  /**
   * Parameters for the secondary text.
   */
  subtextProps?: TextProps[];
  /**
   * Optional gap between the texts.
   */
  gap?: number;
  subTextGap?: number;
}

const StyledDiv = styled.div<{ backcolor?: string, gap: number }>`
  ${props => props.backcolor !== undefined ? `background-color: ${props.backcolor};` : ''}
  gap: ${props => props.gap + 'px'};
`;

const TextSubtextGroup = ({
  className,
  backColor,
  textProps,
  subtextProps = [],
  gap = 0,
  subTextGap = 0,
}: TextSubtextGroupProps) => {

  if (subtextProps.length === 0) {
    return null
  }
  
  return (
    <StyledDiv className={className !== undefined ? [className, classes.texts_container].join(' ') : classes.texts_container} backcolor={backColor} gap={gap}>
      <TextComponent {...textProps} />
      <StyledDiv className={classes.texts_container} gap={subTextGap}>
        {
          subtextProps.map((props, index) =>
            <TextComponent {...props} key={index} />
          )
        }
      </StyledDiv>
    </StyledDiv>
  )
}

export default TextSubtextGroup;