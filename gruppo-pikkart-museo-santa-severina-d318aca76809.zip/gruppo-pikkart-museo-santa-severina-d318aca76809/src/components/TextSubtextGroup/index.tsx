import TextSubtextGroup, { TextSubtextGroupProps } from '@/components/TextSubtextGroup/TextSubtextGroup';

export default TextSubtextGroup;
export type { TextSubtextGroupProps };