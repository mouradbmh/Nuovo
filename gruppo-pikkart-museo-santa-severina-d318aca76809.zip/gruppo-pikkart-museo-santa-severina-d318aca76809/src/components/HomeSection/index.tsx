import HomeSection from "@/components/HomeSection/HomeSection";

export default HomeSection;
