import { ContenutoHomeDto } from "@/services/openapi";
import Carousel from "@/components/Carousel";
import { CarouselCardProps } from "@/components/CarouselCard";
import { useTranslation } from "react-i18next";
import { ARLayoutTypes, useLayouts } from '@/hooks/useLayout';

const HomeSection = ({ content, cardStyled, vediTuttiText }: { content: ContenutoHomeDto, cardStyled?: boolean, vediTuttiText?: string }) => {
    const { t } = useTranslation();
    const layouts = useLayouts();


    const slidesInCard = layouts.get(content.tipologiaLayout as ARLayoutTypes) === "mini" ? 2 : 1;

    console.log(content)
    return (
        <>
            <Carousel
                slidesInCard={slidesInCard}
                background={content.container?.backColor as string}
                titleBar={vediTuttiText ? {
                    title: {
                        text_key: t(content.nome as string),
                        text_size: 'large',
                        text_weight: 'bold',
                        color: content.container?.coloreTitoloTipologia as string
                    },
                    link: {
                        href: '/discover' + (content.nome ? '?filterUrl=' + encodeURI(content?.uniqueId ?? "") : ''),
                        text_key: vediTuttiText !== undefined ? vediTuttiText : t('view_all'),
                        text_size: 'regular',
                        color: content.container?.coloreVediTutti as string
                    }
                } : {
                    title: {
                        text_key: t(content.nome as string),
                        text_size: 'large',
                        text_weight: 'bold',
                        color: content.container?.coloreTitoloTipologia as string
                    },
                }}
                slides={content?.contenuti?.map((elemento) => {
                    return {
                        cardType: layouts.get(content.tipologiaLayout as ARLayoutTypes),
                        cardStyled: cardStyled !== undefined ? cardStyled : false,
                        contentType: elemento.nomeEntita,
                        title: elemento.titolo,
                        description: elemento.descrizioneBreve,
                        imgUrl: elemento.urlImmagine,
                        titleColor: content.container?.coloreTitoloItem as string,
                        secondaryInfoColor: content.container?.coloreDataItem as string,
                        descriptionColor: content.container?.coloreDescrizioneItem as string,
                        id: elemento.uniqueId
                    } as CarouselCardProps & { id: string, contentType: string }
                })}
            />
            
        </>
    );
}

export default HomeSection;
