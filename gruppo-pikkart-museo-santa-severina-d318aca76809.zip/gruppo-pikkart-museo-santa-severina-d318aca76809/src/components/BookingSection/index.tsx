import BookingSection from "@/components/BookingSection/BookingSection";

export default BookingSection;
