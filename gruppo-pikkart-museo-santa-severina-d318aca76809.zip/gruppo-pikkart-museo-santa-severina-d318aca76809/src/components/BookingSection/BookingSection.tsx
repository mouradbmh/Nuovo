import { styled } from 'styled-components';

type BookingSectionProps = {
    layout?: "horizontal" | "vertical";
    children: React.ReactNode;
    gap?: number;
    padding?: {
        all?: number | string,
        vertical?: number | string,
        horizontal?: number | string,
    }
};

const StyledDiv = styled.div<{
    layout: "horizontal" | "vertical",
    gap: number,
    padding: {
        all?: number | string,
        vertical?: number | string,
        horizontal?: number | string,
    }
}>`
    display: flex;
    flex-direction: ${props => props.layout === "horizontal" ? "row" : "column"};
    gap: ${props => props.gap}px;
    ${props => props.padding.all ? `padding: ${props.padding.all}px;` : `padding: ${props.padding.vertical}px ${props.padding.horizontal}px;`}
    > * {
        flex: 1;
    }
`;

const BookingSection = ({
    layout = "horizontal",
    children,
    gap = 16,
    padding = { vertical: 16, horizontal: 24 },
}: BookingSectionProps) => {
    return (
        <StyledDiv layout={layout} gap={gap} padding={padding}>
            {children}
        </StyledDiv>
    );
};

export default BookingSection;
