import { motion } from 'framer-motion';
import { useNavigation } from '@/hooks/useNavigation';
import { TransitionType, Transitions } from '@/components/ScreenTransition/';
import classes from '@/components/ScreenTransition/screenTransition.module.css';

const ScreenTransition = ({ transition, children }: { transition?: TransitionType, children: React.ReactNode }) => {
    const { isGoingBack } = useNavigation();

    const transitionAnimation = transition !== undefined ? transition : (isGoingBack ? "pop" : "push");

    const variants = Transitions[transitionAnimation];

    return (
        <motion.div
            initial='initial'
            animate="enter"
            exit="exit"
            variants={variants}
            className={classes.page_container}
        >
            {children}
        </motion.div>
    );
}

export default ScreenTransition;