export type TransitionType = "push" | "pop";

export type TransitionConfiguration = {
    initial: any,
    enter: any,
    exit: any
}

export type TransitionsType = {
    [key in TransitionType]: TransitionConfiguration;
};

export const Transitions: TransitionsType = {
    push: {
        initial: {
            opacity: 0,
            x: "100%",
            transition: { ease: 'easeInOut', duration: 0.3 }
        },
        enter: {
            opacity: 1,
            x: "0%",
            transition: { ease: 'easeInOut', duration: 0.3 }
        },
        exit: {
            opacity: 0,
            x: "-100%",
            transition: { ease: 'easeInOut', duration: 0.3 }
        }
    },
    pop: {
        initial: {
            opacity: 0,
            x: "-100%",
            transition: { ease: 'easeInOut', duration: 0.3 }
        },
        enter: {
            opacity: 1,
            x: "0%",
            transition: { ease: 'easeInOut', duration: 0.3 }
        },
        exit: {
            opacity: 0,
            x: "100%",
            transition: { ease: 'easeInOut', duration: 0.3 }
        }
    }
};