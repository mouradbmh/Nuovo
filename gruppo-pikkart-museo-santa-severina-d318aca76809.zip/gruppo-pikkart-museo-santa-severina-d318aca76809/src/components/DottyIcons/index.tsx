import * as DottyIcons from '@/components/DottyIcons/DottyIcons';

export default DottyIcons;