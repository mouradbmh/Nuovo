import classes from "@/components/EditUserBar/editUserBar.module.css";
import TextSubtext from "@/components/TextSubtext";
import { useState } from "react";
import IconTextButton from "../IconTextButton";
import InputComponent from "../InputComponent";

type EditUserBarProps = {
    label_key?: string,
    value?: string,
    setOnEdit: (value: string) => void,
};

const EditUserBar = ({
    label_key = "Option",
    value = "-",
    setOnEdit,
}: EditUserBarProps) => {
    const [currentValue, setCurrentValue] = useState<string>(value);
    const [isOnEdit, setIsOnEdit] = useState<boolean>(false);

    const row_container = [classes.row_container];
    if (isOnEdit) {
        row_container.push(classes.row_container_edit);
    }

    return (
        <div className={row_container.join(' ')} onClick={() => !isOnEdit && setIsOnEdit(true) }>
            <div className={classes.option_container}>
                <TextSubtext
                    textProps={{
                        text_key: label_key,
                        text_size: "regular",
                        text_weight: "regular",
                        color: "var(--zinc-900)",
                        className: classes.option_text
                    }}
                />
            </div>
            {
                isOnEdit ? (
                    <div className={classes.input_container}>
                        <InputComponent
                            inputType="text"
                            inputName="editUser"
                            inputProps={{
                                text_key: currentValue,
                                text_size: 'regular',
                            }}
                            setOnChange={setCurrentValue}
                        />
                        <IconTextButton
                            className={classes.button}
                            buttonMode="normal"
                            textProps={{
                                text_key: "Save",
                                text_size: "regular",
                                text_weight: "regular",
                                color: "var(--zinc-900)",
                            }}
                            backColor="var(--zinc-100)"
                            padding={{
                                all: 15
                            }}
                            onClick={() => {
                                setOnEdit(currentValue);
                                setIsOnEdit(false);
                            }}
                        />
                    </div>
                ) : (
                    <TextSubtext
                        textProps={{
                            text_key: currentValue,
                            text_size: "regular",
                        }}
                    />
                )
            }

        </div>
    );
};

export default EditUserBar;
