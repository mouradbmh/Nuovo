import EditUserBar from "@/components/EditUserBar/EditUserBar";

export default EditUserBar;
