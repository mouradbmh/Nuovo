import ContentGallery from "@/components/ContentGallery/ContentGallery";

export default ContentGallery;