import { useState } from 'react';
import Carousel from "@/components/Carousel";
import GalleryView from '../GalleryView/GalleryView';

export type ContentGalleryProps = {
  contents: {
    id: string;
    imgUrl: string;
    hasPlayButton: boolean;
    videoUrl?: string;
    type?: string;
    ytUrl?: string;
  }[]
};

const ContentGallery = ({ contents }: ContentGalleryProps) => {

  const [showPrev, setShowPrev] = useState(false);
  const [activeIndex, setActiveIndex] = useState(0);
  // const {stopPlayback} = useAppContext()

  return (
    <div>
      <div onClick={() => setShowPrev(true)}>
        <Carousel
          slidesPerView={1}
          swipeToSlide={activeIndex}
          slides={contents.map(content => {
            //console.log('contenuto', content)
            return {
              cardType: 'fullwidth',
              id: content.id,
              imgUrl: content.imgUrl,
              hasPlayButton: content.hasPlayButton,
              isVideo: content.hasPlayButton,
              videoUrl: content.videoUrl,
              // playVideo: false
            }
          })}
          onSlideChange={swiper => {setActiveIndex(swiper.activeIndex)}}
          paddingType='none'
          showButtons
          overlayButtons

        // selectedSlide="2"

        />
      </div>

      <GalleryView activeSlide={activeIndex} setActiveSlide={setActiveIndex} isOpen={showPrev} setIsOpen={() => {
        setShowPrev(!showPrev)
      }}
        immagini={
          contents.filter(el => !el.hasPlayButton).map(el => {
            return {
              fileUrl: el.imgUrl
            }
          })
        }
        video={
          contents.filter(el => el.hasPlayButton).map(el => {
            return {
              fileUrl: el.videoUrl!,
              previewFileUrl: el.imgUrl,
              tipologia: el.type!,
              urlYoutube: el.ytUrl
            }
          })
        } />
    </div>
  );
};

export default ContentGallery;