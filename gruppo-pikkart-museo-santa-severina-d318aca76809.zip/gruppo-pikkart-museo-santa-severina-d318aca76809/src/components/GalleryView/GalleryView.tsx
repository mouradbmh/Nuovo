// import React, { useState } from 'react'
import classes from './GalleryView.module.css';
import NavigationTopBar from '../NavigationTopBar';
import IconTextButton from '../IconTextButton';
import { ChevronLeft, X } from 'react-feather';
import { Dispatch, SetStateAction, useEffect, useState } from 'react';
import Carousel from '../Carousel';
import { CarouselCardProps } from '../CarouselCard';

export type GalleryViewProps = {
    isOpen: boolean
    setIsOpen: () => void
    img?: string
    activeSlide?: number
    setActiveSlide: Dispatch<SetStateAction<number>>
    immagini: {
        fileUrl: string;
        traduzioni?: {
            titolo: string;
            descrizione: string;
        }[];
    }[]
    video: {
        previewFileUrl: string;
        fileUrl: string;
        urlYoutube?: string;
        traduzioni?: {
            titolo: string;
            descrizione: string;
        }[];
        tipologia: string;
    }[];
}


const GalleryView = ({ isOpen, setIsOpen, immagini, video, activeSlide, setActiveSlide }: GalleryViewProps) => {

    const [indexCarousel, setIndexCarousel] = useState(0);

    //useEffect()


    //TODO: CORRETTO???
    useEffect(() => {
        if (isOpen) {
            document.body.style.overflow = "hidden";
        } else {
            document.body.style.overflow = "auto";
        }
        setIndexCarousel(0)
    }, [isOpen])

    useEffect(() => {
        console.log(indexCarousel, "index")

    }, [indexCarousel])

    useEffect(() => {
        console.log('activeSlide',activeSlide)
    },[activeSlide])

    const imageOf = (indexCarousel + 1).toString() + " di " + (immagini.length + video.length).toString();

    if (isOpen) {
        return (
            <div className={classes.main_container}>
                <NavigationTopBar className={classes.overlapping_topbar}
                    button_left={<IconTextButton
                        backColor="transparent"
                        contentsColor="white"
                        buttonMode="outline_borderless"
                        icon={<ChevronLeft height="24" strokeWidth={1.5} width="24" onClick={setIsOpen} />} />}
                    title_key={imageOf}
                    textColor="white"
                    button_right={<IconTextButton
                        backColor="transparent"
                        contentsColor="white"
                        buttonMode="outline_borderless"
                        icon={<X height="24" strokeWidth={1.5} width="24" onClick={setIsOpen

                        } />} />} />

                <div className={classes.carouselContainer}>
                    <Carousel
                        //selectedSlide={activeSlide ? activeSlide.toString() : undefined}
                        initialSlide={activeSlide}
                        slidesPerView={1}
                        slides={[
                            ...(video.map<CarouselCardProps & { id: string }>((v, index) => {
                                if (v.tipologia === "YOUTUBE") {
                                    return {
                                        cardType: 'fullwidth',
                                        // hasPlayButton: true,
                                        eventText: v.tipologia,
                                        id: 'video_' + index.toString(),
                                        imgUrl: v.previewFileUrl,
                                        urlYoutube: v.urlYoutube
                                        // videoUrl: v.fileUrl,
                                        // isVideo: true
                                    }
                                } else
                                    return {
                                        cardType: 'fullwidth',
                                        // hasPlayButton: true,
                                        eventText: v.tipologia,
                                        id: 'video_' + index.toString(),
                                        imgUrl: v.previewFileUrl,
                                        videoUrl: v.fileUrl,
                                        isVideo: true

                                    }
                            })),
                            ...(immagini.map<CarouselCardProps>((i, index) => {
                                return {
                                    cardType: 'fullwidth',
                                    id: 'img_' + index.toString(),
                                    imgUrl: i.fileUrl,
                                    zoom: true
                                }
                            })),

                        ]}
                        paddingType='none'
                        showButtons
                        overlayButtons
                        onSlideChange={(swiper) => {setIndexCarousel(swiper.activeIndex); setActiveSlide(swiper.activeIndex)}}
                        playVideo={true}
                    // selectedSlide="2"

                    />
                </div>

            </div>
        );
    } else return <></>
}

export default GalleryView
