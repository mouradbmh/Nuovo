import { Dispatch, ReactNode, SetStateAction, createContext, useState } from "react";

export type LoaderContextType = {
    visible: boolean,
    setVisible: Dispatch<SetStateAction<boolean>>,
    percentage: string | undefined,
    setPercentage: Dispatch<SetStateAction<string | undefined>>
    message: string | undefined,
    setMessage: Dispatch<SetStateAction<string | undefined>>
};

export const LoaderContext = createContext<LoaderContextType>({} as LoaderContextType)

type Props = {
    children: JSX.Element | ReactNode;
};

const LoaderProvider = ({ children }: Props) => {
    const [visible, setVisible] = useState(false)
    const [percentage, setPercentage] = useState<string>()
    const [message, setMessage] = useState<string>()

    const value : LoaderContextType = {
        visible,
        percentage,
        setPercentage,
        setVisible,
        message,
        setMessage
    }

    return (
        <LoaderContext.Provider value={value}>
            {children}
        </LoaderContext.Provider>
    );
};

export default LoaderProvider;