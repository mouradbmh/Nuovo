import { Routes, Route, useLocation } from "react-router-dom";
import ProtectedRoute, { ProtectedRouteProps } from "@/components/Routing/ProtectedRoute";
import HomeScreen from "@/screens/Home";
import { useProfile } from "@/hooks/useProfile";
// import { useAuth } from "@/hooks/useAuth";
import { ProfileSetupScreen } from "@/screens/ProfileSetup";
import { LoginScreen } from "@/screens/Login";
import ProfileScreen from "@/screens/Profile";
import DiscoverScreen from "@/screens/Discover";
import DetailsScreen from "@/screens/Details";
import ArScreen from "@/screens/AR";
import { useKey } from "@/hooks/useKeyContext";
import { useLayoutEffect } from "react";
import { getJSON } from "@/utils/getJSON";
import { ComuneDto } from "@/services/openapi/models/ComuneDto";

const Routing = () => {
  // const { isLoggedIn } = useAuth();
  const { ready, profileId } = useProfile();
  const location = useLocation();

  const { setLocation } = useProfile();
  const { setKey, setKeyLoc, setAuthDomain } = useKey()

  // const loginProtectedRouteProps: Omit<ProtectedRouteProps, 'component'> = {
  //     isAuthenticated: isLoggedIn && profileId !== undefined,
  //     authenticationPath: "/login",
  // };

  useLayoutEffect(() => {
    const init = async () => {
      const comuneConfig = await getJSON('./comune.json') as ComuneDto;
      setLocation(comuneConfig.text_key);
      localStorage.setItem('xApiKey', comuneConfig.tenantId);
      localStorage.setItem('i18nextLng', 'it-IT');
      setKey(comuneConfig.tenantId)
      setKeyLoc(comuneConfig.text_key);
      setAuthDomain(comuneConfig.authDomain)
    }

    void init();
  }, []);

  const profileProtectedRouteProps: Omit<ProtectedRouteProps, 'component'> = {
    isAuthenticated: profileId !== undefined,
    authenticationPath: "/setup",
  };

  return (
    ready && (
      <Routes location={location} key={location.key} >
        <Route path="/" element={<ProtectedRoute {...profileProtectedRouteProps} component={<HomeScreen />} />} />
        {/* <Route path="/setup" element={<ProfileSetupScreen />} /> */}
        <Route path="/setup" element={<ProtectedRoute {...profileProtectedRouteProps} skipOnboarding={true} component={<ProfileSetupScreen />} />} />
        <Route path="/login" element={<ProtectedRoute {...profileProtectedRouteProps} component={<LoginScreen />} />} />
        <Route path="/profile" element={<ProtectedRoute {...profileProtectedRouteProps} component={<ProfileScreen />} />} />
        <Route path="/discover" element={<ProtectedRoute {...profileProtectedRouteProps} component={<DiscoverScreen />} />} />
        <Route path="/details" element={<ProtectedRoute {...profileProtectedRouteProps} component={<DetailsScreen />} />} />
        <Route path="/ar" element={<ProtectedRoute {...profileProtectedRouteProps} component={<ArScreen />} />} />
      </Routes>
    )
  );
};

export default Routing;