import { Navigate } from "react-router-dom";

export type ProtectedRouteProps = {
    isAuthenticated: boolean;
    authenticationPath: string;
    component: JSX.Element;
    skipOnboarding?: boolean;
};

const ProtectedRoute = (props: ProtectedRouteProps): JSX.Element => {
    if (props.isAuthenticated || props.skipOnboarding === true) {
        return props.component;
    } else {
        return <Navigate to={props.authenticationPath} />;
    }
};

export default ProtectedRoute;