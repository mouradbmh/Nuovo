import classes from "@/components/VisitorPreview/visitorPreview.module.css";
import TextSubtext from "@/components/TextSubtext";
import { Edit } from "react-feather";
import { styled } from "styled-components";

export type VisitorData = {
    name: string;
    surname: string;
    telephone: string;
    birhtdate: string;
}

type VisitorPreviewProps = {
    visitor: VisitorData;
    color?: string;
    onClickEdit: () => void;
};

const StyledButton = styled.button<{ backcolor: string, color: string }>`
    background-color: ${props => props.backcolor};
    color: ${props => props.color};
    border-radius: 48px;
    border: 1px solid ${props => props.backcolor};
    padding: 8px 8px 8px 16px;
    display: flex;
    flex-direction: row;
    align-items: center;
    gap: 8px;
    cursor: pointer;
`;

const VisitorPreview = ({
    visitor,
    color = "var(--emerald-700)",
    onClickEdit,
}: VisitorPreviewProps) => {
    return (
        <div className={classes.container}>
            <TextSubtext
                textProps={{
                    text_key: visitor.name,
                    text_size: "regular",
                    color: "var(--zinc-900)",
                }}
            />
            <TextSubtext
                textProps={{
                    text_key: visitor.surname,
                    text_size: "regular",
                    color: "var(--zinc-900)",
                }}
            />
            <TextSubtext
                textProps={{
                    text_key: visitor.telephone,
                    text_size: "regular",
                    color: "var(--zinc-900)",
                }}
            />
            <StyledButton color="white" backcolor={color} className={classes.edit_button} onClick={onClickEdit}>
                <TextSubtext
                    textProps={{
                        text_key: "Modifica",
                        text_size: "regular",
                        text_weight: "medium",
                    }}
                />
                <Edit size={16} />
            </StyledButton>
        </div>
    );
};

export default VisitorPreview;
