import VisitorPreview from "@/components/VisitorPreview/VisitorPreview";
import { VisitorData } from "@/components/VisitorPreview/VisitorPreview";

export default VisitorPreview;
export type { VisitorData };
