import { MapPin } from "react-feather";
import InputComponent from "@/components/InputComponent";
import LocationList from "@/components/LocationList";
import classes from "@/components/SearchLocation/searchLocation.module.css";
import { useState } from "react";
import { LocationComponentProps } from "@/components/LocationComponent";
import { useTranslation } from "react-i18next";

const SearchLocation = ({ locations }: { locations: LocationComponentProps[] }) => {
    const [locationQuery, setLocationQuery] = useState<string>('');
    const { t } = useTranslation();
    
    const filteredLocations = locations.filter((loc) => {
        // console.log('loc',loc)
        return loc.text_key.toLowerCase().includes(locationQuery.toLowerCase());
    });

    return (
        <>
            <div className={classes.location_search_container}>
                <InputComponent
                    inputName='searchTown'
                    icon={<MapPin height={24} strokeWidth={1.5} width={24} />}
                    inputProps={{
                        text_key: '',
                        text_size: 'regular'
                    }}
                    inputType="text"
                    placeholderText_key={t("search_town")}
                    setOnChange={setLocationQuery}
                />
            </div>
            <div className={classes.location_list_container}>
                <LocationList
                    locations={filteredLocations}
                />
            </div>
        </>
    );
};

export default SearchLocation;
