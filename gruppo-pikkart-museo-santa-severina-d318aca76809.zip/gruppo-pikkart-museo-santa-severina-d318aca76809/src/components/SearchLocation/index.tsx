import SearchLocation from "@/components/SearchLocation/SearchLocation";

export default SearchLocation;