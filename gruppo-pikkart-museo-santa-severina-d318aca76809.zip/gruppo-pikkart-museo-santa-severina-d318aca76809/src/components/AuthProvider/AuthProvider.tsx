import { useAppContext } from "@/hooks/useAppContext";
import { UserDetailsDto } from "@/services/openapi";
import { useAuthRequest, useAuthToken, useDataRequest } from "@ai4/data-request";
import { Dispatch, ReactNode, SetStateAction, createContext, useCallback, useEffect, useMemo, useState } from "react";
import i18n, { t } from "i18next";
import { useKey } from "@/hooks/useKeyContext";
import axios from "axios";
import { ChangePwr } from "@/screens/Profile/ChangePassword/ChangePassword";
import { App, URLOpenListenerEvent } from "@capacitor/app";

export type AuthContextType = {
  user?: UserDetailsDto;
  loading: boolean;
  error?: any;
  isLoggedIn: boolean;
  login: (email: string, password: string) => void;
  logout: () => void;
  signup: (user: UserDetailsDto) => void;
  update: (modifiedUser: changeInfo) => void
  loginLoading: boolean,
  loginData: AuthResponse,
  register: (firstName: string, lastName: string, email: string, userName: string, password: string, confirmPassword: string, phoneNumber: string) => Promise<boolean>;
  registerLoading: boolean;
  registerError: string | undefined;
  resetPw: (data: ChangePwr) => Promise<boolean>;
  requestReset: () => Promise<void>;
  pwrLoading: boolean;
  pwrErr: string | undefined;
  pwrMsg: string | undefined;
  regMsg: string | undefined;
  resetLoginMessages: () => void;
  resetPwrMessages: () => void;
  setRegErr: Dispatch<SetStateAction<string | undefined>>;
};

export type AI4Token = {
  token: string;
  refreshToken: string;
  expiresIn: number;
  refreshTokenExpiryTime: string
}

export type AuthResponse = {
  success: boolean;
  message: string;
  ai4_cloud_tokens?: AI4Token
}

export type changeInfo = {
  token?: string;
  nome?: string;
  cognome?: string
}

export const AuthContext = createContext<AuthContextType>({} as AuthContextType);

export interface ICallBackToken {
  token: string;
  refreshToken: string;
  expiresIn: number;
  refreshTokenExpiryTime: string;
}

type Props = {
  children: JSX.Element | ReactNode;
}

const AuthProvider = ({ children }: Props) => {
  const [user, setUser] = useState<UserDetailsDto>();
  //const [authUrl, setAuthUrl] = useState<string | null>()
  const [isLoggedIn, setIsLoggedIn] = useState<boolean>(false);
  const url = useMemo(() => new URLSearchParams(window.location.search), [])

  // const [loading, setLoading] = useState<boolean>(false);
  // const [error, _] = useState<any>();

  const { set, get, forget } = useAuthToken();
  const { config } = useAppContext()
  const { key, authDomain } = useKey()
  const [regLoading, setRegLoading] = useState<boolean>(false)
  const [regErr, setRegErr] = useState<string>()
  const [regMsg, setRegMsg] = useState<string>()
  const [pwrLoading, setPwrLoading] = useState<boolean>(false)
  const [pwrErr, setPwrErr] = useState<string>()
  const [pwrMsg, setPwrMsg] = useState<string>()

  // const TMP_TOKEN = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJodHRwOi8vc2NoZW1hcy54bWxzb2FwLm9yZy93cy8yMDA1LzA1L2lkZW50aXR5L2NsYWltcy9uYW1laWRlbnRpZmllciI6IjRjYzljMTZiLTI0YzctNDUzMC04NjI2LTIwOTFlNDMwYjVhNCIsImh0dHA6Ly9zY2hlbWFzLnhtbHNvYXAub3JnL3dzLzIwMDUvMDUvaWRlbnRpdHkvY2xhaW1zL2VtYWlsYWRkcmVzcyI6Im0uYmVydHVjY2lvbGlAbHVuYXBhcnRuZXIuaXQiLCJmdWxsTmFtZSI6Ik1pY2hlbGUgQmVydG9sdWNjaSIsImh0dHA6Ly9zY2hlbWFzLnhtbHNvYXAub3JnL3dzLzIwMDUvMDUvaWRlbnRpdHkvY2xhaW1zL25hbWUiOiJNaWNoZWxlIiwiaHR0cDovL3NjaGVtYXMueG1sc29hcC5vcmcvd3MvMjAwNS8wNS9pZGVudGl0eS9jbGFpbXMvc3VybmFtZSI6IkJlcnRvbHVjY2kiLCJpcEFkZHJlc3MiOiI5MS44MS41Ni4xNTgiLCJ0ZW5hbnQiOiJ3b3JkcHJlc3N0ZXN0MS1sb2NhbDIzIiwiaW1hZ2VfdXJsIjoiIiwiaHR0cDovL3NjaGVtYXMueG1sc29hcC5vcmcvd3MvMjAwNS8wNS9pZGVudGl0eS9jbGFpbXMvbW9iaWxlcGhvbmUiOiIiLCJ1c2VybmFtZSI6Im1pY2hlbGUuYmVydHVjY2lvbGkiLCJleHAiOjE2OTUzMDg2MTN9.By_JCWVZWzcJXLUUtpSeu-wWTOTE54NqCIEUV2nT6hE";
  // const TMP_REFRESH_TOKEN = "2prAD6LO6feE3bJ1qJILh9G3MWfkfxaFPUaoiDtVHds=";

  const { useRestRequest } = useDataRequest();

  const [getUserData, { /*data,*/ loading, error }] = useRestRequest({
    path: 'api/{ver}/personal/profile',
    headers: {
      'Content-Type': 'application/json',
      'Content-Language': i18n.language.split('-')[0]
    },
    method: 'GET',
    jwt: true,
  });

  // const [updateUserData] = useRestRequest({
  //     path: 'api/{ver}/personal/profile',
  //     headers: {
  //         'Content-Type': 'application/json',
  //         'Content-Language': i18n.language.split('-')[0]
  //     },
  //     method: 'PUT',
  //     jwt: true
  // });

  const [loginUser, { data: loginData, loading: loginLoading }] = useAuthRequest({
    action: 'login',
    domain: 'auth',
    paths: {
      tokens: 'wp-json/wp/v2/api/tokens/get',
      refreshToken: 'wp-json/wp/v2/api/tokens/refresh',
    }
  })

  const [refresh] = useAuthRequest({
    action: 'refreshToken',
    domain: 'auth',
    paths: {
      tokens: 'wp-json/wp/v2/api/tokens/get',
      refreshToken: 'wp-json/wp/v2/api/tokens/refresh',
    }
  })

  const baseAuth = axios.create({
    baseURL: authDomain,
  })

  const validateUserData = useCallback(() => {
    void getUserData().then((res) => {
      const response = res as UserDetailsDto;

      if (!response) {
        setUser(undefined);
        setIsLoggedIn(false);
        return;
      }
      console.log('user', response)
      setUser(response);
      setIsLoggedIn(true);
    }).catch(err => {
      console.warn('Validate error:', err)
      void refresh().then(res => console.log(res))
        .catch(err => console.warn(err))
    })
  }, [getUserData, refresh]);

  const setCredentials = useCallback(async (token: string, refreshToken: string, fromStorage?: boolean) => {
    set({ token, refreshToken })
    if (!fromStorage) {
      localStorage.setItem(key + '.token', token)
      localStorage.setItem(key + '.refreshToken', refreshToken)
    }
    validateUserData()
  }, [key, set, validateUserData])

  useEffect(() => {
    const token = get();
    if (!token) {
      setUser(undefined);
      setIsLoggedIn(false);
      return;
    }
    void validateUserData();
  }, [getUserData, get, validateUserData]);

  useEffect(() => {
    const auth = new URLSearchParams(url).get('auth')
    console.log('auth', auth)
    if (auth) {
      const credentials = atob(auth);
      console.log('cred', credentials);
      const credentialJson = JSON.parse(credentials) as Array<ICallBackToken>;
      console.log('params credentials', credentialJson)
      void setCredentials(credentialJson[0].token, credentialJson[0].refreshToken)
    } else {
      const token = localStorage.getItem(key + '.token')
      const refresh = localStorage.getItem(key + '.refreshToken')
      if (token !== '' && token !== null && refresh !== '' && refresh !== null) {
        void setCredentials(token, refresh, true)
      }
    }
  }, [key, set, setCredentials, url, validateUserData])

  useEffect(() => {
    const handleUrlOpen = (event: URLOpenListenerEvent) => {
      const url = event.url;
      console.log('url', url);

      // Handle universal link 'https://comune.gassino.to.it/'
      if (url.startsWith('https://comune.gassino.to.it/')) {
        // Split the URL at 'to.it' and get the last part
        const slug = url.split('to.it').pop();

        if (slug) {
          // alert(slug);
          // If you want to navigate, call the navigate function here
          // navigate(slug);
        }
      } else {
        const deeplinkUrl = url;
        const authParam = "auth=";
        const authIndex = deeplinkUrl.indexOf(authParam);
        if (authIndex !== -1) {
          // Extract the substring starting from the end of "auth="
          const authCode = deeplinkUrl.substring(authIndex + authParam.length);
          const credentials = atob(authCode);
          console.log('cred', credentials);
          const credentialJson = JSON.parse(credentials) as Array<ICallBackToken>;
          console.log('params credentials', credentialJson)
          void setCredentials(credentialJson[0].token, credentialJson[0].refreshToken)
        } else {
          console.log("auth parameter not found");
        }
        // alert(`deepLinkPath ${url}`);
      }
    }

    // Subscribe to the 'appUrlOpen' event with the defined handler
    const unsubscribe = App.addListener('appUrlOpen', handleUrlOpen);

    // Cleanup function to unsubscribe when the component unmounts
    return () => {
      void unsubscribe;
    };
  }, [setCredentials]);

  const login = useCallback(async (username: string, password: string) => {
    //console.log(config?.urlApplicazioneWeb)
    if (config?.urlApplicazioneWeb) {
      const body = {
        username,
        password
      }

      const response = await loginUser({
        data: body,
      }) as AuthResponse
      //console.log('login', response)
      if (response.success) {
        void setCredentials(response.ai4_cloud_tokens?.token ?? '', response.ai4_cloud_tokens?.refreshToken ?? '')
      }
    }

  }, [config?.urlApplicazioneWeb, loginUser, setCredentials])

  const register = useCallback(async (firstName: string, lastName: string, email: string, userName: string, password: string, confirmPassword: string, phoneNumber: string) => {
    // void registerUser({
    //     data: {
    //         firstName,
    //         lastName,
    //         email,
    //         username: userName,
    //         password,
    //         confirmPassword,
    //         phoneNumber
    //     }
    // })

    setRegErr(undefined),
      setRegMsg(undefined)
    setRegLoading(true)
    const authHeader = 'Basic ' + (config?.applicationAuth ?? '')
    console.log('auth', authHeader)
    const res = await baseAuth.post('/wp-json/wp/v2/users', {
      first_name: firstName,
      last_name: lastName,
      email,
      username: userName,
      password,
      confirmPassword,
      phoneNumber,
      roles: 'subscriber'
    }, {
      headers: {
        "Authorization": authHeader,
        "Content-Type": 'application/json'
      }
    }).then((res) => {
      if (res.status !== 200 && res.status !== 201) {
        setRegErr(res.data.message as string)
        console.log(res.data)
        return false
      } else {
        setRegMsg(t('reg_ok'))
        return true
      }

    }).catch(err => {
      console.log(err)
      setRegErr(err.response.data.message as string)
      return false
    })
    setRegLoading(false)
    return res
  }, [baseAuth, config?.applicationAuth])

  const requestReset = useCallback(async () => {
    setPwrErr(undefined)
    setPwrErr(undefined)
    setPwrLoading(true)
    await baseAuth.post('/wp-json/bdpwr/v1/reset-password', { email: user?.email }, {

    }).then(res => {
      console.log(res)
      setPwrMsg('Codice di verifica inviato')
    })
      .catch(() => {
        setPwrErr("Errore nell'invio del codice")
      })
    setPwrLoading(false)
  }, [baseAuth, user?.email])

  // const validateCode = useCallback(async (code: string) => {
  //     await baseAuth.post('/wp-json/bdpwr/v1/validate-code',{
  //         email: user?.email,
  //         code
  //     },{})
  //     .then(res => console.log(res))
  //     .catch(err => console.log(err))
  // },[baseAuth, user?.email])

  const resetPw = useCallback(async (req: ChangePwr) => {
    setPwrErr(undefined)
    setPwrErr(undefined)
    setPwrLoading(true)
    let res = await baseAuth.post('/wp-json/bdpwr/v1/validate-code', {
      email: req.email,
      code: req.code
    }).then(res => {
      console.log(res.data)
      return true
    }).catch(err => {
      console.log(err)
      setPwrErr('Codice non valido')
      return false
    })
    console.log(res)
    if (res) {
      await baseAuth.post('/wp-json/bdpwr/v1/set-password', req)
        .then(() => {
          setPwrMsg('Password modificata con successo')
        })
        .catch(() => {
          setPwrErr("Errore nell'operazione")
          res = false
        })
    }
    setPwrLoading(false)
    return res
  }, [baseAuth])

  const logout = useCallback(() => {
    setUser(undefined);
    setIsLoggedIn(false);
    forget();
    localStorage.removeItem(key + '.refreshToken')
    localStorage.removeItem(key + '.token')
  }, [forget, key]);

  const signup = (user: UserDetailsDto) => {
    // TODO: implement signup
    setUser(user);
    setIsLoggedIn(true);
  };

  const update = useCallback(async (modifiedUser: changeInfo) => {
    const data: changeInfo = {
      cognome: modifiedUser.cognome ?? (user?.lastName ?? ''),
      token: localStorage.getItem(key + '.token')!,
      nome: modifiedUser.nome ?? (user?.firstName ?? '')
    };
    await baseAuth.post('/wp-json/wp/v2/api/user/update', data, {
      headers: {
        "Cache-Control": "no-cache"
      }
    })
      .then((res) => {
        console.log(res)

      }).catch(err => {
        console.log(err)
      })
    void validateUserData()
  }, [baseAuth, key, user?.firstName, user?.lastName, validateUserData])

  const resetLoginMessages = useCallback(() => {
    setRegErr(undefined)
    setRegMsg(undefined)
  }, [])

  const resetPwrMessages = useCallback(() => {
    setPwrErr(undefined)
    setPwrMsg(undefined)
  }, [])

  const value: AuthContextType = useMemo(
    () => ({
      user,
      loading,
      error,
      isLoggedIn,
      login,
      logout,
      signup,
      update,
      loginLoading,
      loginData: loginData as AuthResponse,
      register,
      registerError: regErr,
      registerLoading: regLoading,
      resetPw,
      requestReset,
      pwrErr,
      pwrLoading,
      pwrMsg,
      regMsg,
      resetLoginMessages,
      resetPwrMessages,
      setRegErr
    }),
    [user, loading, error, isLoggedIn, login, logout, update, loginLoading, loginData, register, regErr, regLoading, resetPw, requestReset, pwrErr, pwrLoading, pwrMsg, regMsg, resetLoginMessages, resetPwrMessages]
  );

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};

export default AuthProvider;