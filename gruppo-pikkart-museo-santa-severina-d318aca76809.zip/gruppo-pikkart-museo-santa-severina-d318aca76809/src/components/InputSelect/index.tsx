import InputSelect from "@/components/InputSelect/InputSelect";

export default InputSelect;
