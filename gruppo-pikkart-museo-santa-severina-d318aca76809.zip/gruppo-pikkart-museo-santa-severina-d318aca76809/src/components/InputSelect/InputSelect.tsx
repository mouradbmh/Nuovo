import classes from "@/components/InputSelect/inputSelect.module.css";
import TextSubtext from "@/components/TextSubtext";
import Select from "react-select";
import { ChevronDown } from "react-feather";

type InputSelectProps = {
    label?: string;
    placeholder?: string;
    options: { value: string; label: string }[];
    onChange?: (value: any) => void;
    value?: string
};

const InputSelect = ({
    label,
    placeholder,
    options,
    onChange,
    value
}: InputSelectProps) => {
    const customStyles = {
        option: (defaultStyles: any, state: any) => ({
            ...defaultStyles,
            backgroundColor: state.isFocused ? "var(--sky-light)" : "var(--sky)",
            color: state.isFocused ? "var(--zinc-900)" : "var(--zinc-900)",
            fontFamily: "Inter",
            fontSize: "16px",
            fontWeight: "400",
        }),
        control: (defaultStyles: any) => ({
            ...defaultStyles,
            borderRadius: "8px",
            padding: "5px 12px 5px 8px",
            border: "1px solid var(--sky-light)",
            boxShadow: "none",
        }),
        singleValue: (defaultStyles: any) => ({
            ...defaultStyles, 
            color: "black",
            fontFamily: "Inter",
            fontSize: "16px",
            fontWeight: "400",
        }),
        indicatorSeparator: (defaultStyles: any) => ({ ...defaultStyles, display: "none" }),
    };

    return (
        <div className={classes.container}>
            {label && <TextSubtext
                textProps={{
                    text_key: "Orario",
                    text_size: "regular",
                    color: "var(--zinc-900)",
                }}
                className={classes.label}
            />}
            <Select
                options={options}
                className={classes.select}
                styles={customStyles}
                value={value ? options.find(el => el.value === value): undefined}
                placeholder={TextSubtext({
                    textProps: {
                        text_key: placeholder ? placeholder : "Select",
                        text_size: "regular",
                        color: "var(--ink-lighter)",
                    },
                })}
                onChange={onChange}
                components={{DropdownIndicator}}
            />
        </div>
    );
};

const DropdownIndicator = () => {
    return (
        <div style={{display: "flex", alignItems: "center"}}>
            <ChevronDown size={24} strokeWidth={1.5} color='var(--zinc-900)' />
        </div>
    );
}

export default InputSelect;
