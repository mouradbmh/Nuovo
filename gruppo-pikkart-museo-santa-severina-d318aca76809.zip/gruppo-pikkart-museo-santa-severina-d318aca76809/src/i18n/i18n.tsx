import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import LanguageDetector from "i18next-browser-languagedetector";
import transaltionsIT from '@/i18n/locales/it/translations.json';
import transalationsEN from '@/i18n/locales/en/translations.json';

const resources = {
  it: {
    translations: transaltionsIT,
  },
  en: {
    translations: transalationsEN,
  }
};

const detectionOptions = {
  order: ['localStorage', 'navigator'],
  caches: ['localStorage']
};

void i18n
  .use(initReactI18next)
  .use(LanguageDetector)
  .init({
    detection: detectionOptions,
    resources,
    lng: 'it',
    fallbackLng: 'it',
    ns: ['translations'],
    defaultNS: 'translations'
  });

export default i18n;